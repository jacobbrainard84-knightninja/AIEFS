# Researcher040282 — self-directed AIEFS research

Supporting Researcher001 and AuditorSeat002 with source-faithful research,
independent specifications, red-team controls and scoped Lean work.
Prepared is not uploaded; submitter-local tests are not independent approval.

## Latest completed local cycle —009

**Known self-supplied-manifest lead advanced with an actual imported-validator
witness and tested new-file caller-anchor admission companion. Not installed.**

[Standalone009 report](2026-09-04_researcher040282_009_anchored-cohort-admission.md).
Optional evidence: `researcher040282-cycle009-anchored-cohort-admission.zip`.
Owner handoff: `cycle_009/HANDOFF.md`.
Tested main: `eb3933c196ee19e80e1621ae80d89ca72e6d9485`.

Fresh inbox already reports another contributor's copied-function complete-schema
acceptance. Credit that work;009 does not claim novelty or rerun its downstream
calculations.009 independently generates a complete minimum-consumed-schema toy
cohort and imports the actual unchanged candidate/package, using discover_inputs/
validate_run rather than copied/mocked functions. All12 public sources unchanged.

- Original4/9intended failing methods,0errors, normal/-O:7unanchored acceptances
  among18cases **relative to proposed external-anchor admission policy**. Existing
  validate_run has no expected-anchor parameter; do not imply otherwise.
- New explicit caller-anchor guard9/9pass;7root rejects BEFORE delegation,
  3test-owned synthetic positives/8existing child-hash-schema rejects preserved.
-8/8wrong models detected, including after-only ordering and input mutation.
  4malformed caller configurations rejected separately, never credited as semantic
  detections. No setup exceptions accepted as successful negatives.
-9critical inline files extracted;12Python+2metadata dependencies freshly fetched;
  full runner actually repeated, science/6workers/12detailed records match.

The independently chosen root is a CALLER TRUST ASSUMPTION. Self-consistency,
claimed identity or self-derived digest cannot issue authority. Committed ART-2217
manifest positive is METADATA ONLY; no genuine five-file S01 positive was executed.
All positive validation tests use explicit TEST-owned synthetic roots. Fixture
2600NPZ keys were independently inspected; validate_run itself ONLY hashes NPZ.
No real trajectories, engine, baseline gate, CLI/main/run_analysis/bundle writer,
production certificate, source/frozen/registry/lock edit or new Lean compilation.
Guard not wired into current CLI/pipeline; no atomic/TOCTOU security claim.

## State, evidence, dates and review

- `STATE.json`:009 locally complete; next010 returns to a load-bearing history/
  delay/phase-step semantics prerequisite. No unattended process/upload.
- `CLAIM_LEDGER.csv`:114unique rows; prior113 and94formal labels preserved.
  Completed004108 /005109 /006111 /007112 /008113 are protected scopes.
- `EVIDENCE_INDEX.json`: every current claim citation unpacked.
- `HISTORICAL_ARCHIVE_LOG_MAP.csv`: historical logs → unchanged unpacked paths.
- `cycle_009/packet_validation.json`: owned packet/inline/repro/privacy consistency,
  not science reexecution, genuine-S01 test or independent guard approval.
- Prepared2026-09-04 Atlantic/Reykjavik; prior owner/repository November labels
  remain separate, not inferred execution chronology.006 administrative provenance
  notice and all earlier scientific code/reports/archives/logs preserved.

Fresh inbox908639412c5560cc2c308b089ade0679c846b15c,10selected notes/reproducers.
Targeted R040282 intake/R001 notes/general TRIAGE unchanged since008; three new
colleague files discovered in tree. General triage's structural-only wording is
not latest evidence of contributor activity. Their copied downstream results were
not independently rerun/approved here; no incoming reproducer executed. Limited
public PR/branch read is not private coordination assurance or a new upload receipt.

R001 prior94declaration compilations/standard footprints and B-F6/B-F7 mechanism
reproductions do not approve our controls/library fidelity/new005–009proposals.
009 guard/policy remain without independent-seat review or owner integration.
All16acquisition branch records minimal; incoming encoded source statically
pattern-inspected, not executed. Historical public Git fixture's two intentionally
synthetic addresses distinguished. Deleted legacy Lua audit remains absent.

## Reproduction

009note includes9complete critical files, independent deterministic fixture/
immutable admission scenarios, protocol and actual outputs. Python/NumPy/pandas
available, no installation. Fetcher14reviewed public dependencies, no code execution
or raw author metadata. Loader imports reviewed actual source, so not arbitrary-
code security. Synthetic NPZ is9,129,447B here; temporary bundles removed after
runs, generator/observations retained. Receipt:
`cycle_009/standalone_reproduction.json`; log:
`cycle_009/standalone/reproduction.log`.

## Prior contributions, preserved (not rerun in009)

-001 guarded-map paper/exact groundwork;00222guarded-map declarations;00344new
  proposal/gate/conditional OFF/ON declarations;00422EMA+6drive declarations.
  Shared/fixed-input component facts, not coupled locking. Completed108row snapshot.
-005 bridge companion22methods/65finite cases normally/-O/extracted rerun;
  ART-0050 unchanged/unreplayed;004addendum/privacy/log navigation preserved.
-006 qualified held-event review:3072small/2350translated/60nominal/12other robust
  cases;605gray excluded;8mutants and selectedevent/AUC/DID checks. Not freeze or
  population inference; actual extracted reproduction retained.
-007 known B-F6 componentwise-NaN proposal: original4fail/0errors, corrected targets
  11pass;2592pairs220original false accepts versus0corrected;8mutants each mode.
  ART-0702 frozen engine unchanged; no full equivalence/real-array census.
-008 known B-F7 oracle unique-key proposal: original5fail/0errors, candidate12pass,
  1600pairs244original false accepts versus0candidate mismatches;10invalid keys/
  8mutants each mode;8inline/12fresh-source full rerun. Not installed or full study
  certificate; logical empty/failed matches/ignored metadata explicitly scoped.

## Next bounded cycle —010, not started

Fresh-check actual history/delay/phase-step semantics and current reference-library
status. Use an independently indexed buffer model and wrong-index/update-order
controls; then select one smallest load-bearing formal lemma. No duplicate rate-law
sweep/docs work, new broad inventory, real campaign, frozen edit or unattended work.
See `RESEARCH_QUEUE.md`; owner handles review/upload/any integration decision.
