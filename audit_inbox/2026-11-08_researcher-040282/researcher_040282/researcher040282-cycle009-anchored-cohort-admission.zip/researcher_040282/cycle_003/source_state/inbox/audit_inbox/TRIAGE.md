# Audit-inbox triage ledger

This is the triage record that `audit_inbox/README.md` promises.

**Status vocabulary:** UNREAD, IN_REVIEW, CONFIRMED, PARTLY_CONFIRMED, INCORRECT, STALE, DUPLICATE, PRESERVE_AS_HISTORY, PROMOTED, REJECTED.

- **CONFIRMED** means Researcher 001 re-checked the point against the repo at the stated commits. It does **not** mean the point has been promoted to the registry, errata or code. Only **PROMOTED** means that, and promotion happens only through a reviewed branch and a PR that the owner merges.
- **independent_check** says what was actually re-run or read. A point that was not re-run says so.

**Rules for this ledger:**

- Researcher 001 and Auditor Seat 002 maintain it. Contributors must not edit it.
- Add rows. Do not delete them. To change a verdict, update `status` and add to `notes`.
- **Commits:**
  - main `395ea53` (= `395ea535d939c594c51c85169859f09f65f360b5`)
  - audit-inbox reviewed at `f5c4b2c` and re-checked at `51884c3`
  - research/freezing `f444401`
- **Re-checks:** done by Researcher 001 on 2026-10-31, around 12:00–13:00 America/Toronto (EDT, UTC-4).

## (a) Researcher 026 review: `audit_inbox/2026-10-31_researcher026_full-state-review.md`

`submitted_by` for all rows in this section: Researcher 026 (Arena), relayed by the owner, transcribed by Researcher 001. Part 1 points are `R026-S*` and Part 2 points are `R026-I*`.

| item_id | source_path | source_commit | submitted_by | scope | status | triaged_by | independent_check | canonical_destination | superseded_by | notes |
|---|---|---|---|---|---|---|---|---|---|---|
| R026-S1 | audit_inbox/2026-10-31_researcher026_full-state-review.md (Part 1 §1) | main 395ea53 | R026 | main green / suite counts | PARTLY_CONFIRMED | R001 | `git ls-remote`: main tip = 395ea53. `git ls-files`: 3,004 tracked files. Tree about 1.3 GB. `check_modes --strict` PASS. R001's E15 audits ran the CI and red-team suites earlier. | none (status only) | | Not re-run this pass: modular tests 40/2 (pytest not installed on the box), v4.1 13/13, Lean builds. These count as reported only. |
| R026-S2 | … Part 1 §2 | ruleset 26247678 | R026 | main ruleset | CONFIRMED | R001 | `gh api …/rulesets/26247678` (read-only): `required_approving_review_count=0`, `strict_required_status_checks_policy=false`, 11 required contexts (8 repo + 3 Lean). `gh pr list`: PRs #3/#4/#5 have 0 requested reviewers and none is a draft. | owner decision | | **Owner:** turn on strict/up-to-date checks, or require a manual update from main + inventory regeneration before each merge. |
| R026-S3 | … Part 1 §3 | f444401, a614451, 3645770 | R026 | PRs #3/#4/#5 readiness | CONFIRMED | R001 | **PR #3** (`git show f444401`): `registry/claims.csv:71-74` holds LEAN-FREEZE-CORE / RES-FREEZE-GATED / RES-FREEZE-NUM / RES-FREEZE-NOVELTY. Cor 4 uses the state-free `ℓ_f^0` (`research/freezing/REPORT.md:221-226`). The novelty is rescoped (`REPORT.md:16`). **PR #5:** the 4-file conflict with comparator v4 was confirmed by R001's merge simulation (AUDIT_E15_3645770, verdict CLEAN). **PR #4:** R001 audit, SOUND WITH NOTES. | STATE.md branch table | | **Owner:** decide whether to mark PR #5 as draft, and the merge order #4 → comparator v4/E14 → #5. |
| R026-S4 | … Part 1 §4 | 14072c3, ad1470a, f495d1c, 7c3bbba | R026 | checker-fix branches | PARTLY_CONFIRMED | R001 | Tips confirmed by `git ls-remote`. `fix/check-manifest-missing-verifier` (a428c32) and `fix/manifest-nonempty` (92993eb) are not in main. `SHA256SUMS files` is **not** among the ruleset's required contexts. | STATE.md branch table | | Review omits that R001's audit of 14072c3 is **FIXES REQUIRED**: the verifier runs without `python -I`, so a planted `hashlib.py` next to it defeats the hash check. The lint-claims conflict list was not re-checked. `fix/lint-claims-combined` does not exist yet. |
| R026-S5 | … Part 1 §5 | f0aadce | R026 | comparator v4 | PARTLY_CONFIRMED | R001 | Tip confirmed. R001's comparator-v4 audit gives **FIXES REQUIRED**: the CSV seed column is compared as a float, and the tolerance tests are no-ops (they pass with the feature removed). | STATE.md | | Gap list consistent with branch; "closes genuine v3 gaps" holds only after the fixes. |
| R026-S6 | … Part 1 §6 | main 395ea53 | R026 | studies.csv entrypoints | CONFIRMED | R001 | On main: 11 tokens in 5 `registry/studies.csv` rows do not resolve to files. `CURRENT_STATUS.md:46` cites 3 absent tangent/cocycle scripts. No CI check of `canonical_entrypoints`. | OPEN_QUESTIONS.md (item 13); future registry PR | | The suggested aliases (falsification_updated, intertwining_controller_analysis) are leads and have not been checked against the code. |
| R026-S7 | … Part 1 §7 | main 395ea53 | R026 | modular platform | CONFIRMED | R001 | From `AIEF_Experiments/aief_modular_platform_v1_analysis_v4/`: `describe AIEF_1_4_S01` prints `SPECIFICATION ERROR: … 'aief_experiment_engine_v1' is not available`, and `dry-run` exits 2. With `PYTHONPATH=<repo root>` it works (`spec_sha256 177e0a61…`). `README_modular.md:11-12` documents the failing path. | OPEN_QUESTIONS.md (item 12) | | Not re-run: tests 40 passed / 2 skipped. |
| R026-S8 | … Part 1 §8 | main 395ea53 | R026 | v4.1 analysis | CONFIRMED | R001 | `AIEF_1_4_Twindow_sensitivity_analysis_v4_1.py`: `:591` implements 1e-6 × smallest saved-grid step, while the strings at `:210` and `:1307` say `1e-6*dt`. `runs/b57562a8ee77/` has no v4.1 output. | OPEN_QUESTIONS.md (item 12) | | Interval-censored wording not re-read. |
| R026-S9 | … Part 1 §9 | 2af3859 | R026 | Arena branch / AUD-RATELAW | IN_REVIEW | R001 | Counts confirmed: 180 behind / 12 unique (`rev-list --left-right`), 149 added files. `audits/literature/ROUND_10_FINDINGS.md` exists. AUD-RATELAW is `registry/claims.csv:50` on main. | OPEN_QUESTIONS.md (item 16) | | The science point is **not adjudicated**. The reviewer argues for a terminology fix, not a downgrade, because h ∈ ker A_J with s_i = s_J gives δB' = (1−γdt)s_J δh. Needs independent adjudication. Do not merge the Arena tree. |
| R026-S10 | … Part 1 §10 | main 395ea53 | R026 | stale main docs | CONFIRMED | R001 | On main: `README.md:55` ("multiplicative normalisation"), `README.md:57` (Lean = 2×3 identity), `lean/AIEFProofsKn/README.md:33` ("pending"), `CURRENT_STATUS.md` header "Last Verified 2026-10-23" and `:46`. `ast.parse` of every tracked `.py`: 233 valid, 1 invalid (`test_01.py`, whose first line is a shell command). | future docs-cleanup PR | | **Owner:** remove `test_01.py` (its first line holds a local path, so do not quote it). |
| R026-S11 | … Part 1 §11 | main 395ea53 | R026 | size / CI scalability | CONFIRMED | R001 | `git ls-files` counts: npz 2006, csv 339, py 234, pdf 21, zip 6, tar 1. CSVs over 50 MiB: 3. `check_modes.py:102-120` buffers all `git cat-file --batch` output; peak child RSS on main was **2.38 GiB**. | OPEN_QUESTIONS.md (item 15) | | Not re-checked: 30 text files over 10 MiB. Exit 137 not reproduced; it depends on the memory limit. |
| R026-S12 | … Part 1 §12 | various | R026 | branch cleanup | CONFIRMED | R001 | In main: `merge-prep/arena-reconciled` 9d46d9b and `research/lean-kn` 5c62d64. Not in main: `fix/corr-0995-scope` b77ce5f. There are 8 `salvage/*` branches and 24 heads in total. | owner decision | | Whether a branch is "obsolete" is a judgement. **Owner:** decide on deletion/archiving. |
| R026-S13 | … Part 1 "Recommended order" | — | R026 | integration order 1–14 | IN_REVIEW | R001 | Consistent with S2–S12. | owner decision | | Recommendation, not a finding. |
| R026-I1 | … Part 2 §1 | f5c4b2c / 51884c3 | R026 | branch shape | CONFIRMED | R001 | Merge base a991b46; main 56 ahead; 7 unique commits at f5c4b2c (8 at 51884c3); 172 files added, all under `audit_inbox/`. The branch tree still has the meteorite `.tar` at its old path, and the same blob is on main at `data/external/superconductivity_in_meteorites/`. | none | | Line counts differ slightly at 51884c3 (21,472 insertions, against 21,469 in the review). |
| R026-I2 | … Part 2 §2 | f5c4b2c | R026 | "single source of truth" | CONFIRMED | R001 | Read in `briefing/README.md:7`. | briefing/README.md | | Fixed in this push: authority order added. |
| R026-I3 | … Part 2 §3 | f5c4b2c | R026 | missing TRIAGE.md | CONFIRMED | R001 | File was absent at 51884c3. | audit_inbox/TRIAGE.md | | Fixed: this file. |
| R026-I4 | … Part 2 §4 | f5c4b2c | R026 | no intake enforcement | CONFIRMED | R001 | The only workflow on the branch is `.github/workflows/lean.yml`. | briefing/INTAKE_GUARD_PROPOSAL.md | | **Owner:** choose between the two options. No workflow was added. |
| R026-I5 | … Part 2 §5 | f5c4b2c | R026 | executable salvage | CONFIRMED | R001 | `git ls-files -s`: 12 files had mode `100755`. | salvage/README.md, briefing rule 13, MANIFEST.csv | | Fixed: all files now `100644`, with the old mode in `former_git_mode`. "No malicious code" was not re-read line by line. |
| R026-I6 | … Part 2 §6 | f5c4b2c | R026 | STATE.md freezing contradiction | CONFIRMED | R001 | `git show f444401` has the 4 rows, Cor 4 `ℓ_f^0` and the novelty rescope, yet STATE.md (then `:33-35`, now `:35-37`) said "not yet pushed". | briefing/STATE.md | | Fixed. |
| R026-I7 | … Part 2 §7 | f5c4b2c | R026 | stale branch table | PARTLY_CONFIRMED | R001 | Stale at f5c4b2c. 51884c3 had already updated E15 to 3645770 and comparator to f0aadce. lint-claims was still 588d5ee; the current tip is ad1470a. | briefing/STATE.md | | Fixed: tips refreshed with a retrieval timestamp and a not-live warning. No generated JSON snapshot, which would need a tool and is left to the owner. |
| R026-I8 | … Part 2 §8 | f5c4b2c | R026 | 0.4543 threshold scope | CONFIRMED | R001 | `research/freezing/REPORT.md@f444401:114` says "Ungated ON threshold: R_c = 0.454286". The gate factor λ_e ∈ (0,1] multiplies the update (`:108`), and the gated-OFF certificate is Thm 3 (`:193`). | briefing/STATE.md | | Fixed. |
| R026-I9 | … Part 2 §9 | f5c4b2c | R026 | "all numerics one parameter set" | CONFIRMED | R001 | The statement is too broad as written. Named ablations such as `no_mu` and delay removal, and exogenous-R freezing checks, exist on main / research/freezing. | briefing/STATE.md | | Fixed with scoped wording. The listed examples were not each re-verified. |
| R026-I10 | … Part 2 §10 | f5c4b2c | R026 | Lean coefficient field | PARTLY_CONFIRMED | R001 | The K_n headline theorems are over ℚ (`IncMatrixRank.lean:201-230`, `KernelDimFormula.lean:60-62`), and the char-2 failure is exhibited for K_3 over `ZMod 2` (`CompleteGraphKn.lean:246-252`). **But** the general connected non-bipartite lemmas are proved over any field with `NeZero (2:K)` (`IncMatrixRank.lean:147,168,177`), so "over ℚ" understates them. | briefing/NORTH_STAR.md | | Fixed with precise wording. |
| R026-I11 | … Part 2 §11 | f5c4b2c | R026 | theorem dependency chain | CONFIRMED | R001 | Suggestion; read against NORTH_STAR.md:68-77. | briefing/NORTH_STAR.md | | Adopted. |
| R026-I12 | … Part 2 §12 | f5c4b2c | R026 | OPEN_QUESTIONS gaps | CONFIRMED | R001 | See S6–S8 and S11. | briefing/OPEN_QUESTIONS.md | | Adopted as items 12–16. |
| R026-I13 | … Part 2 §13 | f5c4b2c | R026 | salvage mechanics | CONFIRMED | R001 | INDEX lists 164 files with no missing or extra entries and all sizes match; with INDEX.md the total is 165; 12 files were executable. | salvage/2026-10-31/MANIFEST.csv | | Fixed: SHA-256 manifest added. Not re-checked: "unreachable from other branches" and `bash -n`. |
| R026-I14 | … Part 2 §14 | f5c4b2c | R026 | high-value inbox material | IN_REVIEW | R001 | Locations confirmed. The b2a95 cross-platform review is `salvage/2026-10-31/review_6b49a7b/REVIEW.md`; the NaN-fix erratum is under `nanfix/`. | per-item triage (rows SALV-*) | | Those sections are marked `UNREAD` in MANIFEST.csv. |
| R026-I15 | … Part 2 §15 | f5c4b2c | R026 | archival-only material | CONFIRMED | R001 | Section descriptions in INDEX.md. | rows SALV-* | | Marked PRESERVE_AS_HISTORY. |
| R026-I16 | … Part 2 §16 | f5c4b2c / 51884c3 | R026 | merge would fail inventory | CONFIRMED | R001 | Synthetic `merge --no-commit` of 51884c3 into 395ea53 in a scratch worktree, then aborted: `check_current_inventory` gives "172 error(s) -> FAIL". | none | | Do not merge audit-inbox wholesale; promote selectively. |
| R026-I17 | … Part 2 §17 | main 395ea53 | R026 | check_modes memory | PARTLY_CONFIRMED | R001 | Same as S11: whole-output buffering confirmed; 2.38 GiB peak RSS on main. | OPEN_QUESTIONS.md (item 15) | | The exit-137 kill was not reproduced on this box. |

## (b) Inbox submissions

| item_id | source_path | source_commit | submitted_by | scope | status | triaged_by | independent_check | canonical_destination | superseded_by | notes |
|---|---|---|---|---|---|---|---|---|---|---|
| SUB-2026-10-31-01 | audit_inbox/2026-10-31_grok-bot_merged-branch-salvage.md | f5c4b2c (added) | Grok Bot (executor subagent for the owner) | PR-comment salvage from 5 merged branches | IN_REVIEW | R001 | `lean/AIEFProofsKn/README.md:33` "pending" confirmed on main. R026-I14 independently reports the 5 tips as ancestors of main and the meteorite move as byte-identical (the blob identity was confirmed in R026-I1). | future docs-cleanup PR | | The two copied PR comments have not been re-compared with GitHub. |
| SUB-2026-10-31-02 | audit_inbox/2026-10-31_researcher026_full-state-review.md | this push | Researcher 026 (Arena), relayed by the owner | full GitHub state + audit-inbox | IN_REVIEW | R001 | Per-finding rows R026-S1…S13 and R026-I1…I17 above. | see rows | | Transcription with minor condensation, not verbatim. |

## (c) Salvage archive `audit_inbox/salvage/2026-10-31/` (one row per INDEX.md section)

Per-file hashes and modes are in `salvage/2026-10-31/MANIFEST.csv`. **Never execute in place**; see `salvage/README.md`.

`submitted_by` for all rows: workspace salvage, 2026-10-31. `source_commit` for all rows: 6453922 (added). `triaged_by` for all rows: R001.

| item_id | source_path | source_commit | submitted_by | scope | status | triaged_by | independent_check | canonical_destination | superseded_by | notes |
|---|---|---|---|---|---|---|---|---|---|---|
| SALV-01 | salvage/2026-10-31/_uncommitted_diffs/ | 6453922 | salvage | 5 diffs of deleted dirty worktrees | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | none | | Diffs against superseded commits (R026-I15). |
| SALV-02 | salvage/2026-10-31/audit_pp1/ | 6453922 | salvage | post-push audit, v4→v4.1 diff (9) | UNREAD | R001 | count/size/sha256 only | | | v4.1 tolerance history (R026-I14). Triage per item. |
| SALV-03 | salvage/2026-10-31/audit_project_map/ | 6453922 | salvage | project claims map (31) | UNREAD | R001 | count/size/sha256 only | | | High value per R026-I14 (0.995-correlation rejection, dependence between freezing windows). |
| SALV-04 | salvage/2026-10-31/audit_r001_branches/ | 6453922 | salvage | R001 branch audit notes, CI helpers (17) | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | | | 2 scripts were executable. |
| SALV-05 | salvage/2026-10-31/autonomy_setup/ | 6453922 | salvage | autonomy setup sims (4) | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | | | 1 script was executable. |
| SALV-06 | salvage/2026-10-31/corr_0995_fix/ | 6453922 | salvage | corr-0995 scope fix (2) | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | | fix/corr-0995-scope (b77ce5f) | |
| SALV-07 | salvage/2026-10-31/lean_fix/ | 6453922 | salvage | Lean recovery, negative tests (38) | UNREAD | R001 | count/size/sha256 only | | | Lean negative tests are high value (R026-I14). The copied old Lean trees are history only. |
| SALV-08 | salvage/2026-10-31/merge_check/ | 6453922 | salvage | old merge-prep checks (8) | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | | | R026-I15 |
| SALV-09 | salvage/2026-10-31/merge_recheck/ | 6453922 | salvage | old merge rechecks (10) | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | | | R026-I15 |
| SALV-10 | salvage/2026-10-31/nanfix/ | 6453922 | salvage | b2a95 NaN-fix v2, diff, erratum (3) | UNREAD | R001 | count/size/sha256 only | | | Check against `AI Agent Audits/evidence/reproductions/` on main. |
| SALV-11 | salvage/2026-10-31/post_push_1/ | 6453922 | salvage | post-push note (1) | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | | | |
| SALV-12 | salvage/2026-10-31/push_pp1/ | 6453922 | salvage | push note (1) | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | | | |
| SALV-13 | salvage/2026-10-31/push_r5/ | 6453922 | salvage | round-5 push note (1) | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | | | |
| SALV-14 | salvage/2026-10-31/push_review/ | 6453922 | salvage | push review notes (3) | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | | | |
| SALV-15 | salvage/2026-10-31/repo_cleanup/ | 6453922 | salvage | repository-cleanup patch (1) | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | | | R026-I15. Do not apply. |
| SALV-16 | salvage/2026-10-31/review_6b49a7b/ | 6453922 | salvage | review of 6b49a7b, b2a95 reproduction hazards (16) | UNREAD | R001 | count/size/sha256 only | | | High value (R026-I14). 8 scripts were executable; one line is redacted. |
| SALV-17 | salvage/2026-10-31/upload_stage/ | 6453922 | salvage | upload manifests (2) | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | | | Obsolete paths (R026-I15). |
| SALV-18 | salvage/2026-10-31/v2/ | 6453922 | salvage | v2 note (1) | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | | | |
| SALV-19 | salvage/2026-10-31/v4/ | 6453922 | salvage | v4 Lean summaries, modified repo copies (11) | PRESERVE_AS_HISTORY | R001 | count/size/sha256 only | | | Nested old repo copies are not canonical (R026-I13). 1 script was executable. |
