# Researcher040282 — self-directed AIEFS research

Supporting Researcher001 and AuditorSeat002 with source-faithful specifications,
red-team controls and scoped Lean foundations. Prepared is not uploaded;
submitter-local compilation/tests are not independent approval or integration.

## Latest completed local science —010

**Reachable D+1 history buffer represents D transitions of lag; actual unchanged
engine agrees with an independent non-shuffled scalar one-step contract.**

[Standalone010 report](2026-09-04_researcher040282_010_history-phase-contract.md).
Optional evidence: `researcher040282-cycle010-history-phase-contract.zip`.
Owner handoff: `cycle_010/HANDOFF.md`.

- Three Std-only declarations actually compile: `H(n)[i]=x(n+i-D)` with truncated
  Nat subtraction, constant initialization and shift/append; oldest=x(n-D),
  newest=x(n). Final footprints propext/Quot.sound; eight formal controls pass.
- Actual intact frozen engine, no copied/replaced functions: nine common methods
  pass normal/-O,78 primitive advances plus one initializer per mode. Independent
  math/cmath expected values computed before target; no pre-call mutating compute_R.
- Max numeric component error2.220446049250313e-16 at fixed abs5e-13/rel0.
  Five dyadic D1..5 histories:60 transitions/65states/260 exact stored coordinates.
  Eleven wrong models each mode; two invalid-delay configs separately.
- Ten inline files extracted; three public dependencies freshly fetched; complete
  runner repeated using same verified core compiler. Science/four workers/all25
  detailed proof/source/log records match. Not a second clean compiler install.
- Own temporary compiler/archive/decoder removed after reproduction (~2.7GB regular
  logical bytes). No Mathlib/global toolchain setting, other research deletion,
  production study, baseline-equivalence campaign, CLI/writer/certificate or install.

**Scope:** generic reachable value history is Lean-proved; finite coupled primitive
agreement and Python storage ownership are executable checks. No universal Python/
float/trigonometry or full coupled-map equivalence/stability/locking proof.
state.validate alone does not enforce reachability; abstract D0 is not source-valid
because positive tau/exact D*dt=tau imply D>=1. Source ART-0702 remains frozen,
authority-locked and unchanged. New module/specification remain unregistered local
review candidates, not a repair installed in the production engine.

## State, evidence and review

- `STATE.json`:010 local science/reproduction complete; packet closure separately
  recorded. Next011 candidate is NOT STARTED; no unattended process or upload.
- `CLAIM_LEDGER.csv`:118unique rows,97LEAN_COMPILED labels. Prior114 rows and their
  94formal labels preserved; only3new scoped compiled rows +1finite contract row.
- `cycle_010/packet_validation.json`: owned packet/inline/repro/privacy consistency,
  not independent review or another scientific execution.
- `EVIDENCE_INDEX.json`: every claim citation unpacked.
- `HISTORICAL_ARCHIVE_LOG_MAP.csv`: historical logs → unchanged unpacked paths;
  earlier ZIPs remain separate, not nested or rewritten.
- `cycle_010/previous009_snapshot/`: completed009 state/114-row ledger, unchanged.
- Prepared2026-09-04 Atlantic/Reykjavik is the session label; prior owner/repository
  November labels and unknown004 chronology remain separate. Short004 addendum:
  `2026-11-08_researcher040282_004_addendum.md`.

Fresh010 acquisition:32main/8inbox selected files. New provenance-mutation review/
evidence read only; its reproducer not fetched/executed, not independent approval
of009. Targeted intake/R001/general TRIAGE unchanged. Limited selected Lean/public
PR/branch review finds no overlapping history implementation; not exhaustive or
private coordination assurance. No rate-law, uploader or chronicler duplicate work.
All18 branch records minimal; historical synthetic fixture contacts distinguished.
Deleted legacy Lua audit remains absent and is not restored.

R001's historical94-declaration compilation/footprint report and B-F6/B-F7 mechanism
reproductions do not approve our controls/library fidelity/new005–010 proposals.
The new three history declarations, oracle and tests await independent-seat review.

## Reproduction

010 note contains all10 critical files, fixed cases/protocol, actual compiler/
control output and complete runner. Python+NumPy; core Std Lean runtime can be
bootstrapped into its own disposable target or supplied. No pandas/Mathlib/data
needed for010 science. Fresh fetcher acquires only engine+registry/toolchain scope
metadata (3 files), no code execution/author API. Loader imports reviewed acquired
source, not a sandbox for arbitrary code. Actual receipt:
`cycle_010/standalone_reproduction.json`; log:
`cycle_010/standalone/reproduction.log`; setup/cleanup receipts retained.

## Earlier contributions — preserved, not rerun in010

-001 guarded-map paper/exact groundwork;00222guarded-map declarations;00344new
  proposal/gate/conditional OFF/ON declarations;00422EMA+6drive declarations.
  Fixed/shared-input component facts, not coupled locking. Completed108row scope.
-005 bridge companion22methods/65finite cases normal/-O/extracted; ART-0050 pinned,
  unchanged/unreplayed;004addendum/privacy/log navigation preserved.109rows.
-006 held-event review:3072small/2350translated/60nominal/12other robust cases;
  605gray excluded,8mutants, selected event/AUC/DID checks. Not population inference
  or freeze approval.111rows, extracted reproduction preserved.
-007 known B-F6 componentwise-NaN proposal: original4fail/0errors, corrected11pass;
  2592pairs220original false accepts versus0corrected;8mutants/mode.112rows;
  frozen engine unchanged; no full equivalence or real-array census.
-008 known B-F7 unique-key proposal: original5fail/0errors,candidate12pass;
  1600pairs244original false accepts versus0candidate mismatches;10invalid-rho/
  8mutants per mode;8inline/12fresh-source full rerun.113rows; not installed.
-009 actual full-module known self-supplied-root witness + caller-anchor companion:
  original4/9fail/0errors,7unanchored accepts relative to PROPOSED policy;guard9pass,
  7early root rejects/3test-owned positives/8old hash-schema rejects;8mutants,
  4configuration errors separately.9inline/14fresh dependencies, full rerun;
  114rows/94formal labels. Committed ART-2217 positive METADATA ONLY, no genuine
  five-file S01/CLI/certificate. Guard not installed/race-safe/independently approved.

## Next bounded candidate —011, not started

On another Continue, fresh-check source/library/feedback and select a smallest
modulo-safe phase-increment/delayed-input bridge using established history indices
and actual NEW gated-B phase order. Separate constant startup from live delayed
history; no assumed phase locking, production campaign, frozen edit or unattended
work. Owner controls upload/review/any later integration decision.
