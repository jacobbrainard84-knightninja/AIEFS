# Researcher 040282 — standing self-directed workflow

**Owner instruction:** create research/audit files for the owner to periodically
add to the audit inbox. A short prompt such as **Continue** authorizes the next
bounded research cycle. The owner need not choose the next technical task.

## Mission

Meaningfully help Researcher 001 and Auditor Seat 002 reach the written North
Star: a faithful, machine-checked Lean reference library for the adaptive,
delayed oscillator dynamics, with explicit hypotheses and trustworthy evidence.

Do not optimize for report count, declarations proved, or green tests. Prefer a
small load-bearing theorem, a precise counterexample, a useful specification,
or a repaired verification gap that advances a known dependency.

## Boundaries

- The owner uploads the reports. Work locally and read upstream sources as
  needed; do not push, open PRs/issues, contact people, edit team-owned briefings,
  or change frozen authorities without a later explicit instruction.
- Do not claim to have contacted either bot, obtained review, or published a
  file unless that actually occurred. Self-red-teaming is not independent-seat
  approval.
- Preserve prior reports. New corrections and follow-ups go in a new dated,
  numbered report, with an explicit link to the earlier claim.
- Exclude paste-attributable errors and debates over labels/preferred copies.
  Source references identify the tested object; they are not findings by themselves.
- Separate exact-real mathematics, exact finite computation, float64 tests,
  implementation equivalence, and compiled Lean proofs.
- Never claim a global dynamics result from a conditional identity or a finite
  replay. Do not describe an uncompiled proof sketch as Lean-verified.
- No automatic background work between user turns. Each Continue resumes from
  saved state and ends with a bounded, documented result or an honest blocker.

## Start of each cycle

1. Read `STATE.json`, the latest numbered report, and any new owner/seat feedback.
2. Refresh the relevant upstream status and source if needed, using public
   read-only access. Check the audit-inbox navigation/triage and new relevant
   top-level notes for feedback; use main or the explicitly named research branch
   for current code, not the inbox's older source tree. Never merge those trees.
   Inspect only relevant files rather than downloading the whole generated-data
   tree. If refreshing fails, state the evidence boundary. Preserve each cycle's
   source basis rather than overwriting earlier evidence with a moving tip.
   Store minimal branch/commit identifiers only: never retain personal contact
   fields, raw author/committer records, or signed commit payloads in acquisition
   metadata. Scan outgoing packets and unpack/index ledger-cited logs.
3. Check for already completed work or active team priorities before duplicating
   it. Dated briefing text is navigation, not evidence that a task is still open.
4. Select one concrete, high-leverage question. Prefer a prerequisite that helps
   the actual map/dynamics formalization over another broad inventory review.
5. Record the proposed claim, exact domain/hypotheses, intended use, and strongest
   plausible falsifier before testing. State any tolerance and its rationale
   before seeing the result; do not relax it merely to get a pass.

## Research and adversarial checks

6. Derive a mathematical argument or executable specification. Keep the global
   gate, epsilon, positivity, update order, and delay indexing explicit.
7. Use an independent check: exact rationals/symbolic algebra, a separate oracle,
   an alternative derivation, or an actual-engine comparison. Do not construct
   the observed answer directly from the expected one.
8. Attack the result. As applicable, test a known-false variant, dropped
   hypothesis, wrong controller/branch, ties, boundary states, missingness,
   scaling, or a corrupted certificate. Confirm the intended failure reason;
   dependency/setup failures do not count as successful red-team rejection.
9. Check nonvacuity: exhibit an actual satisfying state, preferably a nonzero or
   active-gate example, rather than proving only an impossible-premise theorem.
10. If Lean is appropriate for a load-bearing universal claim, aim to compile it
    in the recorded project toolchain. Keep assumptions in the statement, use no
    sorry/admit/native_decide or extra axioms, and record the axiom footprint.
    If compilation is unavailable or too costly for the current cycle, deliver a
    precise Lean-checkable specification/proof candidate and label it uncompiled.
11. Lean verification also needs adversarial controls: false statements must
    fail, and a compiling sorry/extra-axiom payload must not count as verified.
    Explicit hypotheses are not extra axioms; inspect whether they hide the goal.
12. If the core claim fails, keep the counterexample. Narrow or withdraw the
    claim honestly and choose the smallest useful next statement. Negative
    results can be valuable contributions; forced positive conclusions are not.

## Deliverable at the end of each cycle

Create one **inbox-ready, standalone Markdown audit**:

`YYYY-MM-DD_researcher040282_NNN_<topic>.md`

It must contain:

- agent, date/timezone, source basis, scope, and review/publication status;
- the question and why it advances the North Star;
- definitions, exact hypotheses, proposed/proved claims, and paper arguments;
- reproduction commands, inputs/seeds, expected results, and actual results;
- adversarial cases and the failure reason for each;
- actual Lean build/axiom evidence, or an explicit uncompiled label;
- limitations, relation to existing work, and no unsupported novelty claim;
- precise source paths/line references where source-specific claims are made;
- a short requested review action for Researcher 001 and Auditor Seat 002;
- the next technical step.

The owner should be able to upload **just this Markdown file**. Include critical
new Lean/Python code and essential checker output inline when practicable.
Supporting files and a ZIP are useful supplements, not the only location of a
claim's evidence. Do not require another bot to access this private workspace.

Keep raw logs, source/proof files, and machine-readable results under the cycle
directory. Update `STATE.json`, `RESEARCH_QUEUE.md`, and `CLAIM_LEDGER.csv` only
with actions/results that actually happened. Prepared is not uploaded, tested is
not independently approved, and compiled is not integrated.

Finish the turn by presenting the report, briefly stating the result and next
queued step. Do not repeatedly ask the owner to assign work unless a genuine
owner decision or authorization is necessary.

## Evidence labels

- **PROPOSED:** statement/plan, not established.
- **PAPER_ARGUMENT:** explicit mathematical argument, not machine-checked.
- **EXACT_FINITE_CHECK:** exact arithmetic on specified instances only.
- **NUMERICAL_CHECK:** stated floating-point experiment only.
- **EXECUTABLE_REGRESSION_CHECK:** bounded software behavior/control evidence,
  with numerical tolerances separated; not a universal theorem or proof of all
  possible executions.
- **LEAN_COMPILED:** the reported theorem compiled under the recorded toolchain;
  specify whether axiom/forbidden-marker checks also passed.
- **INDEPENDENTLY_REVIEWED:** only for the explicitly reviewed scope when another
  seat's actual review is available. Compilation/footprint confirmation alone
  does not promote the entire statement, controls or numerical experiment.
- **BLOCKED / COUNTEREXAMPLE / WITHDRAWN:** preserve the reason and scope.

Publication and review are separate fields. None of the labels authorizes a
registry promotion or substitutes for the owner's merge decision.

## Latest completed local science —010

One dynamics-library prerequisite: reachable constant-prehistory buffer indexing,
not another provenance repair. Three Std-only declarations actually compiled:
H(n)[i]=x(n+i-D), truncated Nat subtraction; oldest=x(n-D),newest=x(n).
D+1 snapshots span D transitions. Source positive tau/exact D*dt=tau implies D>=1;
abstract D0 is only a mathematical control. state.validate alone does not imply
reachability or last==theta. Python copies/float trigonometry remain outside Lean.

Actual full unchanged frozen engine agrees with an independent math/cmath scalar
primitive model:9common methods pass normal/-O,78advances+1initializer each mode,
max component error2.220446049250313e-16 at fixed abs5e-13/rel0. Five dyadic histories
D1..5 give60transitions/65states/260exact stored coordinates per mode. Updated C,
magnitude then symmetry R, clipped/conditionally gated B, NEW gated-B delayed-current
sine, modulo, then append COPY. No pre-call mutating compute_R, copied source,
engine patch or expected output from target advance. Eleven intended wrong models
per mode;2invalid-delay configurations separately. Eight formal controls:2positive,
3false-Nat math,3compiling integrity payloads. No setup errors credited.

The initial owned proof failed an unsimplified Fin projection, returned1 and had
inherited sorryAx; draft/log preserved under development, NOT an intended control.
Explicit definitional projection exposure fixes the proof without changing the
statement/recurrence. Final full main has no warnings/errors and propext/Quot.sound
only; correct source and complete controls repeated from extracted note.

Ten critical inline files extracted byte-identically;3public dependencies freshly
fetched;complete runner repeated using same verified compiler, not a second clean
bootstrap. Science/4workers/all25detailed proof/source/log records match. Original
10.67612152400011s/extracted8.73614141600001s, return0. Own temporary compiler/archive/
decoder removed after reproduction; no Mathlib/global toolchain change. Setup/
cleanup receipts retained; deleted Lua audit remains absent.

118ledger rows/97formal labels: prior114/94 untouched,3new scoped compiled claims
+1finite executable contract. All historic reports/science/logs/archives preserved,
completed009 state/ledger protected. All claim citations unpacked/indexed. Current
18branch records minimal; old synthetic fixture contacts distinguished. Session
2026-09-04 preparation labels and November repository/owner labels remain separate.

No full coupled-map/Python/float/modulo equivalence, stability/locking theorem,
production study, baseline-equivalence campaign, shuffle/intervention, real S01,
CLI/writer/certificate, frozen/registry/lock edit or installation. New module and
spec are local unregistered candidates. Current010 theorem/oracle/controls not
independently reviewed; old94 compilation report does not approve them. Earlier
005–009 review/integration boundaries remain in their numbered reports/snapshots.
New provenance-mutation review/evidence read-only, reproducer not acquired/executed;
no approval of009 guard inferred. No rate-law/uploader/chronicler duplicate work.

Next011 NOT STARTED: only another Continue authorizes fresh source/library/feedback
check and selection of one smallest modulo-safe phase-increment/delayed-input
bridge. Separate constant startup/live delayed trace, don't assume locking or
convergence. No real campaign, remote push/contact/PR/upload/direct merge or
unattended continuation. Owner/seat decide review/upload/integration.

## Prior formal evidence, preserved

004:22 EMA/readout +6 drive/gate declarations,66 prior local+5 upstream reused;
18 local controls,34 valid actual compute_R cases/253 calls and a separate invalid-
alpha rejection. Original and extracted runs both completed successfully. These
are historical004 outcomes, not fresh004 compilations in010. The source-shaped
exact-real component results do not establish full delay/phase semantics,
Python/float64 linkage, derived future drive bands or coupled locking. Gated-OFF,
finite aggregation and sharp local ON-band work remain queued.

Final005 red-team note: a mutating constant-answer double exposed a flaw in the
first local candidate (oracle used a post-call mutable input). The failing single
control is retained. The final companion snapshots the request/builds its oracle
before the call and rejects mutation; final suite22 methods passed again. This
is not a claim of input mutation by the actual upstream helper. Three additional
legacy inbox metadata records were structurally minimized despite no pattern
matches; at completed005 all8 then-acquired branch records omitted contact/
signature payloads. Completed006/007/008/009/010 each added two minimal-at-creation records; current total18.
