# Researcher 040282 — self-directed AIEFS research

Say **Continue** to start the next bounded cycle. I will check saved state,
source coverage and owner/seat feedback, select a useful dependency, preregister
its domain and strongest falsifiers, perform meaningful research, compile Lean
when appropriate, and deliver one standalone audit for owner upload.
No new technical assignment is necessary.

Work is user-triggered, not unattended activity between turns. I do not contact
other agents, push/submit files, alter frozen/team-owned authorities, or promote
registry claims without separate authorization. Self-red-teaming and local
reproduction are not independent-seat approval.

## Persistent records

- `WORKFLOW.md`: procedure, evidence labels, boundaries.
- `STATE.json`: actual last outcome and immediate resumption action.
- `RESEARCH_QUEUE.md`: selected next dependency and revisable later work.
- `CLAIM_LEDGER.csv`: individually scoped statements and evidence/status.

Real proofs, exact finite checks, floating source comparisons, Python semantics,
independent review, integration and publication remain separate statuses.

## Latest local contribution — Cycle 004

**Single upload file:**
`2026-09-04_researcher040282_004_complex-ema.md`

All seven critical source/checker files are inline. Optional support archive:
`researcher040282-cycle004-complex-ema.zip`.

The new complex EMA/readout and drive-bridge modules have **28 compiled
declarations including helpers** (22+6):

- unit-disk preservation for the actual source-shaped complex input/EMA;
- reported R symmetry, diagonal, nonnegative/range and observable-difference bound;
- exact forced differences and geometric initial-memory law only for identical
  prescribed input sequences;
- fixed-input closed form and conditional convergence, not coupled locking;
- normalized-drive and finite positive-row bounds using the prior row definition;
- component-driven applied gate-factor floor on both guard branches.

The five modules were freshly compiled with complete allowed axiom coverage and
no warnings/errors: 28 new declarations plus **66 prior local and five upstream
declarations reused**, with credit kept separate. Allowed footprints are only
`propext`, `Classical.choice`, `Quot.sound`.

All **18 controls** reached intended outcomes: five positive/thirteen negative,
including eight false mathematical payloads failing at `False`, trust/coverage
rejections, exact Gaussian-rational paths/matrix cases and optimization blocking.
The exact finite suite includes 64 shared-input pair cases, 64 fixed-input cases,
16 updates per path, and 120 finite matrix/readout/drive cases.

Separate actual-source experiment: **34 valid controlled-state cases, 253
unpatched compute_R calls** passed against a loop/cmath oracle. Maximum C error
was 0 and maximum R error `2.220446049250313e-16`; fixed absolute allowance
`2e-14`, relative zero. Six wrong translations were detected. One tiny-window
case was correctly rejected by source validation and reported separately,
**not counted as a 35th numerical pass**; the protocol correction is explicit.

All seven critical files were also actually extracted from the standalone
Markdown into a fresh directory. The five modules rebuilt cleanly and all 18
controls plus the 34-case/253-call source experiment, six wrong-model detections
and separate configuration rejection passed again. This is local self-
reproduction, not independent-seat review.
No complete delayed-state model, Python/float64 linkage, actual long-time drive
bands, closed-loop phase locking/stability, gated-OFF composition, or full-network
freezing is established. The uniform range bound alone is too coarse to issue
the default 12-node ON comparison certificate; failure of that lower certificate
is not an OFF proof.

**Status:** local self-red-team; independent review, owner upload, publication and
integration unconfirmed. No remote source write, bot contact or registry edit.

## Reproduction

The audit has extraction and complete public dependency commands. With the
recorded trusted public Lean/Mathlib available, from `cycle_004/`:

```bash
export R040282_MATHLIB=/absolute/path/to/pinned-mathlib4
export R040282_LEAN_BIN=/absolute/path/to/compiler/bin/lean
# Optional: export R040282_CACHE=/owned/scratch/directory
PYTHONOPTIMIZE=0 PYTHONDONTWRITEBYTECODE=1 python check_cycle.py > cycle_checks.log 2>&1
```

The executable needs a sibling `lake`. The checker uses Python's standard
library, verifies the toolchain/pin, freshly compiles all five supplied modules,
and isolates negative-control sources/outputs. Dependency/import/timeouts do
not count as successful mathematical rejection. It is bounded supplied-file
research tooling, not secure arbitrary-code intake or repository CI.

Exact controls without Lean:

```bash
PYTHONOPTIMIZE=0 PYTHONDONTWRITEBYTECODE=1 python check_cycle.py --exact-only
```

Actual-source component comparison needs NumPy/pandas and a reviewed public
engine, but no production trajectory data:

```bash
export R040282_AIEFS_ENGINE=/absolute/path/to/reviewed/aief_experiment_engine_v1.py
PYTHONOPTIMIZE=0 PYTHONDONTWRITEBYTECODE=1 python compare_source.py
```

`build_packet.py` assembles the report from actual sources/results.
`one_file_reproduce.py` extracts the critical inline code and actually runs both
checkers with public dependencies. `build_packet.py --package` creates the ZIP;
`validate_packet.py` checks CRC, member/workspace and inline-code consistency.
The upstream FreezeCore copy is only a reproduction fixture: do not duplicate it
as newly authoritative definitions during integration.

Disposable Lean/Mathlib binaries/cache are excluded from snapshots and were
actually absent on restoration. Saved setup helpers and public metadata restore
them; inspect availability first and never overwrite a prior cycle's evidence.
A successful old log is not a fresh compilation.

## Next selected work

Complete the conditional gated-OFF certificate for the matrix weight map and
formal finite-edge aggregation, after feedback/source refresh. Keep certificate
hypotheses, threshold equality, zero rows, and infinite-tail versus finite-window
claims explicit. The full delayed phase/history transition remains queued too.

## Earlier packets, preserved separately

- **001:** `2026-11-07_researcher040282_gate-foundations.md` and
  `researcher040282-gate-foundations.zip`: paper/exact foundations and 96 isolated
  eta=mu=gamma=0 source/helper comparisons; uncompiled at that delivery.
- **002:** `2026-11-07_researcher040282_002_guarded-capacity-lean.md` and
  `researcher040282-cycle002-guarded-capacity.zip`: 22 compiled finite-map
  declarations, nine controls and actual single-file reproduction.
- **003:** `2026-11-07_researcher040282_003_weight-update-bridge.md` and
  `researcher040282-cycle003-weight-update-bridge.zip`: 44 new proposal/gate/
  conditional OFF/ON declarations, 17 controls, 24 controlled-R source weight
  comparisons and actual one-file reproduction. That experiment bypassed
  compute_R; Cycle 004 now exercises compute_R itself, still not a coupled run.

Historical references in the ledger point to those separate packets. The latest
ZIP is supplementary, not intended to republish every older report/data file.
