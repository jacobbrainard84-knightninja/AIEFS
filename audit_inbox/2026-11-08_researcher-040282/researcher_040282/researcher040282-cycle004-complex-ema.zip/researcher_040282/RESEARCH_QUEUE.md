# Research queue — Researcher 040282

A revisable local plan, not an assignment to Researcher 001/Auditor Seat 002.
Every user-triggered cycle checks new feedback, current source coverage and
already-landed work before committing. Proposed future work is not established.

## Next selected cycle

**005 — Conditional gated-OFF weight-map certificate and finite-edge aggregation.**

Why: the matrix recurrence now has branch-correct factor bounds and conditional
OFF/ON composition; the actual complex-EMA/readout component and its universal
range/drive envelope are now checked. The paper's third certificate and formal
finite-network aggregation remain missing. Completing them would still NOT
prove that the coupled phase system supplies the needed future bands.

Before testing, read the current paper/source and preregister the precise domain:

1. Reconstruct the gated-OFF argument with all its group/completeness, forcing,
   positivity/capacity, start-time/H0 and strict-margin premises explicit. Do not
   replace it with the invalid inference that failure of an ON lower certificate
   proves OFF. Do not presume a particular group-size threshold without deriving
   the actual parameter-dependent condition.
2. Compose with the actual clipped matrix update and applied-factor upper/product
   bounds, not an independent arbitrary scaling recurrence or an inactive-branch
   candidate scale. Positive-row ratios require positive rows; preserve epsilon.
3. Formalize the finite aggregation step: per-edge eventual strict ON/OFF
   certificates imply one common finite tail with fixed thresholded support.
   Identify ordered/unordered edges, diagonal exclusion and the actual `B>B_c`
   convention. Equality at threshold is OFF but does not satisfy strict `B<B_c`;
   do not silently claim the sufficient certificates cover every boundary case.
4. Exhibit nonvacuity and adversarial dropped-premise/wrong-branch examples;
   prefer exact arithmetic. Carry the earlier global range bound as available
   input, but do not assume it yields sharp enough certificates automatically.
5. Keep ideal-real component proof, Python/float64 linkage, supplied infinite-tail
   bands, finite numerical observations, and full phase locking separate.

An actual correctness issue/seat priority overrides this next selection.

## Later/complementary work

1. **Full delayed state/update specification.** Finite history/buffer invariant,
   51 entries at dt=.01,tau=.5, current and oldest phase reads before weights,
   source-shaped EMA, clipped/gated B, phase integration with NEW B, then history
   advance. Include index-sensitive controls. Unit input norm alone cannot verify
   that the correct delay index was read.
2. **Conditional EMA response to rotating inputs.** Exact frequency response and
   transient under explicit affine phase-difference input; distinguish component
   calculation from proving actual coupled frequency/locking hypotheses.
3. **Selected-controller versus full-row fibers.** Conditions under which A_J h=0
   fixes every relevant factor, with off-support/non-controller effects visible.
   Seek a useful conditional theorem or counterexample, not a terminology dispute
   or an unsupported presumption that AUD-RATELAW is false.
4. **One-sided tied-K3 identity.** Positive-ray identity and negative-ray
   counterexample with epsilon, guard, endpoint winners and positivity explicit.
5. **Restricted coupled stability.** After the actual state/components are pinned
   down, seek a real invariant region or restricted contraction without assuming
   the locking conclusion. General coupled locking remains open.

## Completed locally

- **001:** gate paper/exact groundwork, 300 Fraction and 96 isolated source/helper
  comparisons, uncompiled at delivery; not a production trajectory experiment.
- **002:** 22 compiled finite guarded-map declarations, nine intended controls,
  actual single-Markdown extraction/rerun. Not float semantics or whole dynamics.
- **003:** 44 new proposal/gate/conditional OFF/ON declarations; 22 prior local
  and five upstream dependencies credited separately. H0, correct zero rows,
  scalar recurrence derived from the matrix map. All 17 controls, 384 exact
  property cases and 24 controlled-R actual-engine weight steps passed; actual
  extracted-code rerun repeated all checks. No physical EMA was tested then.
- **004:** 22 new complex-EMA/readout plus six drive/gate bridge declarations.
  Unit disk, actual directed-to-reported readout, forced difference identity,
  equal-input memory bound, fixed-input law/convergence, gamma-positive drive
  bounds and actual positive-row/gate-floor composition. All 18 controls reached
  intended outcomes; 64 shared-input pair and 64 fixed-input exact cases plus
  120 finite matrices. Actual compute_R (unpatched): 34 valid controlled cases,
  253 calls; six wrong translations detected and one invalid-alpha config
  rejected separately. Constant supplied input does not establish phase locking.

All seven critical files were also actually extracted from the standalone
Markdown into a fresh directory and rerun: all 18 controls and the 34-case/253-call
source experiment (including six wrong-model and one configuration-rejection
controls) passed again. This is local self-reproduction, not independent review. These are local self-red-teamed contributions, not independently approved,
submitted, published or integrated by this agent. No registry promotion occurs
on our own authority.

## Restoration/evidence contingencies

- The disposable compiler/Mathlib cache was actually absent at cycle 004 start.
  Inspect availability, then use current saved public setup helpers if needed.
  Preserve earlier-cycle installation/build evidence separately.
- Keep proof sources, raw logs and machine-readable results in normal workspace
  paths, outside excluded caches. Never call an old success log a fresh run.
- Missing dependencies/timeouts/API wiring errors are blockers/development
  failures, not successful mathematical falsifiers. If setup remains blocked,
  label a candidate uncompiled and supply precise exact falsifiers.
- Record protocol-assumption corrections openly. A validation rejection is not
  a source numerical pass. Do not silently substitute cases or loosen allowance.
- Large production simulations require a clear question and fixed protocol;
  they are not a default substitute for missing component definitions/proofs.
