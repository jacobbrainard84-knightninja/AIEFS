# Research queue — Researcher 040282

A local, revisable plan; not an assignment to the other seats. Refresh feedback,
current-main status and already-landed work before committing each bounded cycle.

## Next selected cycle — 006

**Review the existing v4.1 candidate, not the known frozen-v4 failure.**

Owner-relayed review priorities superseded the old 005 gated-OFF selection.
Cycle005 has now completed the administrative addendum and ONE bridge self-test
repair proposal. It did not review v4.1 or patch engine/oracle behavior.

Before new tests:

1. Refresh relevant main, registry/status and intake notes read-only. Record the
   exact then-tested commit, not the inbox's older source tree. If the candidate
   has already been fixed/reviewed, do not duplicate it.
2. Preregister the held-event duration/translation convention, saved-grid
   boundary treatment, crossing/follow-up/left-censoring estimands and requested
   labels. Build a small independent oracle, not an expected answer copied from
   the candidate. Include nonboundary positive controls, exact-duration starts,
   shifted blocks, already-true-at-branch cases and insufficient follow-up.
3. Keep empirical fixed-cohort resampling diagnostics separate from population
   rate intervals. Boundary0/40→[0,0],40/40→[1,1] is not a boundary-valid population
   confidence statement. Candidate-v4.1 conclusions are not established by the
   earlier frozen-v4 witness or counts matching a supplied CSV.
4. Do not silently change an estimand to eliminate failures or promote finite
   saved-case agreement into a correctness certificate. Keep one finding per
   proposed repair branch; owner/seat decides registry/erratum handling.

## Separate small repair proposals, after refresh

- **Engine complex-NaN comparator.** Current-main failing-before/passing-after
  tests; component-wise real/imag missingness, preserve finite values and shape/
  dtype policy. Modular comparator already addresses the mechanism. Do not claim
  a real-array finiteness census from a synthetic NaN sentinel. Separate branch.
- **Public oracle duplicate/uniqueness validation.** Current-main failing-before/
  passing-after tests, row-count plus semantic key uniqueness and negative
  changed/missing-row controls. Synthetic3-vs2 evidence is not the real S01
  201-vs200 run. Separate branch from engine and self-test.
- **005 companion independent review.** New-file/erratum only, ART-0050 pinned.
  Our21-method and64-perturbation controls are not independently designed seat
  controls. No direct main or inbox/salvage merge is authorized.

## Lean / scientific gaps remain open

1. **Delay-buffer and phase-step semantics.** Explicit history size/order,
   history[0] oldest read, mean-frequency delay term, updated complex EMA and
   reported magnitude-then-symmetrization, clipped/gated new B for phase update,
   then buffer advance. Include wrong-index/update-order controls. Unit input
   norm or fixed-input EMA alone cannot establish correct delay semantics.
2. **Sharper local row envelope / derived ON bands.** Keep actual q, h=gamma*dt,
   epsilon, positive config.q and feasible H0. The universal coherence range is
   too coarse at baseline; failure of an ON certificate is not an OFF proof.
   Future drive bands must be derived for an actual coupled invariant regime,
   not inserted as the desired conclusion.
3. **Conditional gated-OFF and finite-edge aggregation.** Reconstruct precise
   grouping/capacity/forcing/strict-margin hypotheses; derive applied-factor
   bounds from the actual guarded map. Fix B>B_c convention, diagonal exclusion,
   equality-at-threshold and one common finite tail for finitely many edges.
4. **Selected-controller fibers / AUD-RATELAW.** Full-row-fiber facts do not
   establish selected-controller claims. Keep off-support influence visible.
5. **Restricted coupled stability.** Only after faithful state semantics and
   noncircular invariant hypotheses. Same/fixed INPUT and assumed infinite tails
   are not phase locking or unconditional convergence.

## Completed locally

001 paper/exact groundwork;00222 compiled guarded-map declarations;00344 new
proposal/gate/conditional OFF/ON declarations;00422 EMA+6 drive declarations.
Historical checker/source results are preserved in their reports/logs.
Researcher 001 reports independent compilation/footprints for94 declarations,
not execution of our controls or library-grade statement review.

**005:** completed004 date/state/108-row addendum, separate current109-row ledger;
privacy-minimized three metadata files; unpacked/indexed cited logs; current-main
new-file K3 self-test/erratum proposal. Same 3 contracts fail legacy/pass companion;
22 candidate methods pass normally/-O;64 perturbations plus default agree with
independent Fraction map at fixed allowance. Six inline files extracted, ten
public sources freshly fetched, complete checks repeated. No new Lean, production
bridge replay, engine/oracle patch or v4.1 correctness conclusion.

## No duplicate work / evidence discipline

- Uploader PR10 and checksum PR11 are reported merged by the owner. Do NOT keep
  preparing uploader repairs from stale triage. Current Python CI exists.
- Separate source acquisition IDs from findings; no canonical-copy/version debate.
- Preserve old scientific source and seeds. The 004 date correction is an addendum,
  not invented execution timestamps or an altered scientific result.
- Dates in owner correspondence are handoff labels; session preparation date and
  historical execution chronology must not be silently equated.
- No push, PR, contact, main/briefing edit, automatic inbox upload or unattended
  work is authorized. Owner uploads dated audit-inbox handoffs.
- Check disposable Lean cache before reinstalling. Missing dependencies, timeouts
  and setup failures are blockers, not mathematical negative successes.
- Never replace an old log with a new run under the same name during restoration.

Final005 red-team note: a mutating constant-answer double exposed a flaw in the
first local candidate (oracle used a post-call mutable input). The failing single
control is retained. The final companion snapshots the request/builds its oracle
before the call and rejects mutation; final suite22 methods passed again. This
is not a claim of input mutation by the actual upstream helper. Three additional
legacy inbox metadata records were structurally minimized despite no pattern
matches; all 8 branch records now omit contact/signature payloads.
