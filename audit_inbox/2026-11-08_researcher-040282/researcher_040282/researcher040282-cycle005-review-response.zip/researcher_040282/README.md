# Researcher 040282 — self-directed AIEFS research

Say **Continue** to authorize the next bounded cycle. Read saved state and new
owner/seat feedback, refresh the relevant current main read-only, choose a useful
open dependency, preregister the scope/falsifiers, and deliver an owner-upload
packet. No unattended work, bot contact, push, PR or automatic upload.

## Latest completed local cycle — 005

**Main standalone upload:**
`2026-11-08_researcher040282_005_review-response.md`

**Short004 addendum:**
`2026-11-08_researcher040282_004_addendum.md`

**Supporting bundle:** `researcher040282-cycle005-review-response.zip`

November8 is the owner/seat handoff label, not a reconstructed execution date.
The addendum withdraws004's September4 stamp as chronological production
provenance while preserving its scientific content/seeds and original filename.

### Result

One NEW-FILE/ERRATUM proposal for the known bridge self-test false PASS; no edit
to pinned ART-0050, registry, model or saved replay outputs. Tested main:
`f3e3a57632c613e860a9941f007732cb4c2c91c6`.

- Same three real-operator/fail-closed contracts: legacy **3 failures,0 errors**;
  companion **3 pass**.
- Full companion suite: **22 pass normally and21 pass under Python -O**.
- Actual current-main edge-coordinate operator, compared with an independent
  Fraction-loop map: **64 seeded positive perturbations plus one default**,
  absolute1e-14,relative0. Wrong branch, tie, inactive gate, altered output/winner
  data, a constant answer, dropped guard/epsilon and setup failure controls.
- All **six inline files actually extracted**; ten public upstream dependencies
  freshly fetched; complete runner repeated successfully. Submitter-local
  self-reproduction, not independent-seat approval or a universal float64 proof.
- This tests the pure edge-coordinate audit helper, NOT production `advance_state`
  or a saved real-data bridge replay. The old saved manifest omits --self-test;
  inspected source dispatch isolates that flag. That is bounded static provenance.

The proposed companion replaces only the K3 assurance, not every unrelated block
in the legacy self-test. The old frozen entry point still prints its old PASS;
its implied K3 coverage is withdrawn in the proposed erratum pending review.

### State, privacy and evidence corrections

- Intended completed004 state: **004/108 rows**. Uploaded older root:003/78.
  New live workflow: **005/109** (one new software-regression record).
- `cycle_005/completed_004_snapshot/COMPLETED_004_STATE.json` and
  `CLAIM_LEDGER_COMPLETED_004.csv` preserve the explicit108-row closure view.
- The three reported acquisition JSON files and three additional legacy inbox
  records now omit author/committer/contact AND signed
  commit payloads. No unredacted backup; older local ZIPs scan contact-free.
- `EVIDENCE_INDEX.json`: all current ledger evidence references unpacked.
- `HISTORICAL_ARCHIVE_LOG_MAP.csv`: old ZIP log members mapped to preserved
  unpacked copies. No cited ledger log remains archive-only in this handoff.
- Earlier report/proof/control code is preserved. Historical closure validators
  describe their old root state; they are not assertions about the new 005 root.

## Received external review — deliberately narrow

Actual inbox intake/R001 triage received. Researcher 001 reports independently
compiling **22/44/22+6 =94 declarations**, no warnings/errors, standard axioms.
This confirms only reported compilation/footprint, NOT library-grade statement
fidelity, our controls, numerical suites, saved-data census, or the new 005 repair.
Ledger evidence labels remain submitter claims; review is a separate column.
Prior packet receipt is confirmed; new 005 upload and all library integration
remain unconfirmed. Reviewer/private witness logs are not claimed as local files.

Uploader/checksum fixes are reported merged by the owner; do not keep patching
them. Current main has Python CI. Engine complex-NaN and oracle uniqueness repairs
stay separate. Review current v4.1, not the already-known frozen-v4 failure.

## Reproduction of005

Complete code and public-dependency acquisition are inline in the standalone
report. From this unpacked folder, write new results to a NEW directory:

```sh
python -B cycle_005/proposal/run_checks.py \
  --source cycle_005/source_state/main --output my_new_checks
```

Requires a NumPy/Pandas/SciPy environment. The runner verifies ten unchanged
reviewed upstream modules; expected legacy-red failures are successful overall
ONLY if exactly 3 failures/0 errors occur. Missing dependencies are blockers.
Rerunning our harness does not replace independently designed seat controls.

No new Lean build happened in005. Earlier005-free proof evidence remains under
cycles002–004, with the recorded public toolchain/setup helpers. Check disposable
cache availability before restoring it; an old log is not a fresh compilation.

## Persistent records / next step

`STATE.json`, `WORKFLOW.md`, `RESEARCH_QUEUE.md`, `CLAIM_LEDGER.csv` agree on005
completed,109 rows,006 queued. **006: review existing v4.1 held-event semantics,
estimands and boundary interval wording**, after fresh main/feedback checks.
Keep fixed-cohort resampling separate from population uncertainty.

Lean gaps remain delay-buffer/phase-step semantics, sharper local envelopes/
derived ON bands, gated-OFF and finite aggregation. Same/fixed supplied inputs
and assumed infinite tails do not establish coupled locking.

## Historical contributions

- **001:** paper/exact gate groundwork,300 rational and96 isolated source/helper
  cases; uncompiled at delivery.
- **002:**22 compiled guarded-map declarations,9 local controls and actual
  single-note reproduction.
- **003:**44 new proposal/gate/conditional OFF/ON declarations,17 controls,
  24 controlled-R source weight steps; no physical compute_R tested there.
- **004:**22 EMA/readout +6 drive-bridge declarations;18 controls;34 valid
  actual compute_R cases/253 calls plus separate invalid-alpha rejection.
  Five modules rebuilt in the extracted rerun;28 new,66 prior local and5 upstream
  declarations credited separately. No full delayed-state/float64/locking proof.

Historical reports and original ZIPs remain separate local records; the 005 bundle
unpacks their cited proof/control/source evidence rather than nesting those ZIPs.

Final005 red-team note: a mutating constant-answer double exposed a flaw in the
first local candidate (oracle used a post-call mutable input). The failing single
control is retained. The final companion snapshots the request/builds its oracle
before the call and rejects mutation; final suite22 methods passed again. This
is not a claim of input mutation by the actual upstream helper. Three additional
legacy inbox metadata records were structurally minimized despite no pattern
matches; all 8 branch records now omit contact/signature payloads.
