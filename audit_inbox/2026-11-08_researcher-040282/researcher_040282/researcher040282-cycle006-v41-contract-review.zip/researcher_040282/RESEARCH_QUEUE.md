# Research queue — Researcher 040282

A revisable local plan, not an assignment to other seats. Refresh feedback and
current-main code before each bounded cycle. Do not duplicate already-landed work.

## Next selected cycle — 007

**One small engine complex-NaN comparator repair, only if still open.**

1. Read current main, registry/status and selected intake notes; name exact tested
   commit. Check whether the comparator is already repaired. No stale uploader work.
2. Preregister component-wise real/imaginary missingness semantics; preserve
   finite components and stated shape/dtype policy. A single synthetic NaN sentinel
   is not a finiteness census of saved arrays or proof of physical bad data.
3. Require tests that FAIL on actual current-main behavior for the intended
   mismatch, not setup/import trouble; PASS on a minimal proposed repair and
   reject wrong-component/shape/finite-value mutants. Keep one finding per branch.
4. No production replay/default S01 campaign, remote push, PR, bot contact, direct
   inbox/salvage merge or automatic upload. Owner/seat decides integration.
5. If already fixed, use the separate public-oracle row-uniqueness item below or
   stop with a precise nonduplication result. Do not manufacture a new defect.

## Separate review/repair options

- **Public oracle duplicate/uniqueness validation:** fresh current-main failing-
  before/passing-after row-count AND semantic-key uniqueness tests, including
  changed/missing-row negatives. Synthetic3-vs2 is not the real S01 201-vs200 run.
  Separate branch from engine/self-test/interval changes.
- **005 companion independent review:** pinned ART-0050 stays untouched; use
  new-file/erratum handling. Our final22-method/65-finite-case result is not
  independently designed seat assurance. Mutation red log and snapshot repair
  retained. No saved-production bridge replay is implied.
- **006 oracle/estimand review:** seven-file note and finite conformance reproduced
  normally/-O; not population inference, source freeze or full pipeline audit.
  Seat should independently test overlap, onset-versus-confirmation, risk-set and
  cap interpretation, then choose interval scope. A changed estimand must be
  declared, not silently substituted to obtain a pass. Gray cases stay excluded.
- **Full candidate acceptance surface:** `validate_run`, artifact/provenance races,
  atomic output bundle/read-back, distinct metric/target/undefined-similarity
  paths and every metadata column are not covered by006. Real-data execution
  requires separate acceptance/owner/seat decision; no automatic registry change.

## Lean / scientific gaps remain open

1. **Delay-buffer and phase-step semantics:** history size/order, oldest history[0]
   read, mean-frequency delay term, complex-EMA update, magnitude THEN
   symmetrization, clipped/gated new B used for phase step, then buffer advance.
   Wrong-index/update-order controls matter; unit/fixed-input facts are insufficient.
2. **Sharper local row envelope / derived ON bands:** retain actual q, gamma*dt,
   epsilon, positive config.q and feasible H0. Coarse universal coherence is too
   weak at baseline; failure of an ON certificate is not an OFF proof. Derive
   useful bands for a coupled invariant regime rather than assume the conclusion.
3. **Conditional gated-OFF / finite aggregation:** precise grouping, capacities,
   forcing, strict margins, actual guarded map, B>B_c convention, diagonals and
   equality at threshold. One common finite tail for finitely many edges must
   be justified, not replaced by an assumed infinite tail.
4. **Selected-controller fibers / AUD-RATELAW:** full-row fibers do not establish
   selected-controller claims; keep off-support influence visible.
5. **Restricted coupled stability:** only after faithful state/update semantics
   and noncircular invariant hypotheses. Same/fixed INPUT is not phase locking.

## Completed locally

001 paper/exact groundwork;00222 guarded-map declarations;00344 new declarations;
00422 EMA+6 drive declarations. Researcher001 reported94 independent compilations/
standard footprints, not our controls or library-grade statement-fidelity review.

**005:**004 intended-completion108 versus uploaded00378/current005109 addendum;
metadata privacy/minimization and unpacked evidence index; current-main new-file
bridge self-test/erratum proposal.3 legacy contract failures/0 errors; final22
candidate methods normally/-O and65 finite Fraction/operator checks; six inline
files extracted/ten sources freshly fetched/runner repeated. Own candidate
mutation flaw exposed then fixed via pre-call snapshot/oracle; red evidence kept.
No new Lean, engine/oracle repair, production replay or v4.1 conclusion.

**006:** current main eb3933c196ee19e80e1621ae80d89ca72e6d9485;3072 exhaustive small,
2350 translated-grid,60 nominal,12 other robust checks;605 gray cases excluded;
8 mutants detected; selected19200event/1600AUC/11520DID fields checked. Ordinary/-O
and extracted-note ordinary/-O scientific outputs agree;12 modules unchanged.
Proposed explicit overlap/onset/risk-set/cap/bootstrap contract; no new source bug
forced or project freeze.111 current rows preserve all prior109 and94 formal
labels. No full validator/analysis/real trajectory, new Lean, patch or remote action.

## No duplicate work / evidence discipline

- Owner reports uploader PR10/checksum PR11 merged. Do not revive stale warnings.
- Acquisition commit/blob IDs are reproduction metadata, not findings or a
  canonical-copy/version debate. Work on the assigned current source.
- Preserve protected scientific files, old delivered reports, seeds and logs.
  Current preparation label2026-09-04 and prior owner handoff labels2026-11-08
  are not inferred execution dates. The006 administrative notice was post-test.
- Prior receipt is confirmed; new006 independent review/upload is not.94 prior
  Lean compilation labels do not approve controls, statistics or statement fidelity.
- Check disposable Lean cache before reinstalling. Missing dependency, timeout
  or setup failure is a blocker, not successful mathematical red evidence.
- Never overwrite an old log with a new run while restoring evidence. Index cited
  evidence unpacked; do not require access to this private workspace/archive.
- No push, PR, contact, main/briefing edit, unattended work or automatic inbox
  upload is authorized. Owner handles newly dated audit-inbox handoffs.
