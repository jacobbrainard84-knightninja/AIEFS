# Research queue — Researcher 040282

Priorities are revisited against actual team/source updates and owner feedback
at each user-triggered cycle. This is our working plan, not an assignment to
Researcher 001 or Auditor Seat 002. A queued claim is not an established result.

## Next selected cycle

**003 — Proposal-row and applied gate-factor bridge.**

Why now: the actual finite guarded capacity core is compiled. The inspected
freezing report's Lemma 1(b,c) remains a paper-level prerequisite for linking
an actual gate factor to the existing scalar ON/OFF comparison core. Completing
this local bridge has greater immediate dependency value than another broad
audit or a terminology-only revisit of AUD-RATELAW.

Planned objects and targets (re-preregister exact statements before execution):

1. Define the clipped affine proposal `U_ij=max(0,(1-h)B_ij+h*u_ij)` over a
   finite node type. Separate proposal formation from the guarded gate.
2. Under `B>=0`, row sums of B <= uniform c, and `0<=h<=1`, prove
   `rowSum U i <= (1-h)*c + h*sum_j max(0,u_ij)`.
3. Define applied node/edge factors as **1 on the inactive branch**. Prove
   their lower bounds from proposal-row upper bounds on either branch. Require
   c>0 only where a strictly positive factor floor is needed.
4. Prefer division-free upper bounds such as `appliedNodeFactor_i * row_i <= c`;
   derive a `c/row_i` bound only under `row_i>0`. Test zero rows explicitly.
5. State the start-row invariant and H0 correctly. Derive a trajectory statement
   only after proving the proposal/gate transition and assumptions at each step.
6. If time and scope permit, connect the resulting edge-factor bracket to the
   existing FreezeCore hypotheses. Do not assume the closed-loop coherence bands
   or phase-locking merely to claim they were proved.

Adversarial controls should include a nonzero active step from a feasible state,
zero rows, c=0 where allowed, a dropped previous-row hypothesis, and candidate
versus applied scale confusion. Compile load-bearing universal claims when
feasible; document an exact blocker instead of relabelling sketches as verified.

## Later candidates

1. **Selected-controller fibers versus full-row fibers.** Characterize exactly
   when A_J h=0 preserves the relevant applied factors, including off-support
   leakage and non-controller endpoints. Supply a useful conditional finite
   theorem or a precise counterexample; do not presume AUD-RATELAW false.
2. **One-sided tied-K3 finite identity.** Positive-direction identity and
   negative-direction counterexample, with explicit guard, epsilon, positivity,
   and endpoint-winner inequalities. Finite algebra before generalized derivatives.
3. **EMA invariant and exact locked-input recurrence.** Unit-disk preservation
   for complex EMA and its fixed-input error recurrence. No inferred locking of
   the coupled oscillator system.
4. **Delayed state/update-order specification.** The 51-entry buffer at dt=.01
   and tau=.5; which phase/history state coherence reads; which weights the
   phase update reads; how history advances. Use index-sensitive false variants.
5. **Restricted coupled stability.** Only after finite maps and memory are pinned
   down, seek a restricted invariant-region or contraction result whose
   hypotheses do not assume the locking conclusion.

## Completed locally

- **001 — Gate foundations.** Paper arguments; 300 exact-rational cases and 96
  isolated real-engine/helper comparisons. Counterexamples distinguish guarded
  and unconditional maps and refute inappropriate continuity/nonexpansivity or
  branch-linearity claims. The original packet was not compiled in Lean.
- **002 — Guarded finite-map formal core.** 22 theorems actually compiled with
  complete standard-only axiom footprints. Two positive and seven negative
  controls reached the intended outcomes, including raw-compiling rejected
  proof-hole/extra-axiom payloads. The standalone audit carries all critical
  Lean and checker code inline. No engine-linkage, EMA, delay, locking, selected-
  controller, or stability theorem was inferred from this result.

Both cycles remain local contributions: owner upload, independent review, and
integration are separate and unconfirmed. Do not contact either seat or promote
registry entries on our own authority. Cycle 003 must first check new feedback
and whether someone has already completed its proposed targets.

## Contingencies

- Tool binaries and Mathlib caches may disappear between workspace restorations.
  Inspect them before setup; preserve proof sources, scripts, and logs outside
  excluded cache directories. Reuse cycle_002 setup helpers if needed, with their
  recorded dependency scope, rather than claiming a new proof from an old log.
- If compilation is unavailable in a bounded cycle, deliver exact statements,
  a readable proof candidate, and independent exact controls, labelled uncompiled.
- New large production simulations need a specific question and fixed protocol;
  they are not the default substitute for finite-map formalization.
