"""
Unit & Synthetic Test Suite for Two-Channel Directed Alignment Decomposition
"""

import unittest
import numpy as np
import os
import json

from aief_core import (
    DEFAULT_DT, DEFAULT_ALPHA_EMA, EXCEPTIONAL_SEED,
    compute_transfer_gain_prediction, compute_directed_alignment_decomposition
)
from aief_directed_alignment import generate_synthetic_aligned_replay, run_directed_alignment_audit


class TestDirectedAlignment(unittest.TestCase):

    def test_transfer_gain_formula(self):
        """Test exact calculation of transfer gain prediction G_*."""
        dt, eta, mu, alpha = 0.01, 0.05, 0.02, 0.999428829846
        lambda_star_fixed_left = 0.998738246680
        lambda_star_right_mode = 0.499369154879

        # Fixed-left prediction
        G_star_L = compute_transfer_gain_prediction(lambda_star_fixed_left, alpha=alpha, dt=dt, eta=eta, mu=mu)
        expected_G_star_L = 0.0007 * alpha / (alpha - lambda_star_fixed_left)

        self.assertAlmostEqual(G_star_L, expected_G_star_L, places=12)
        self.assertAlmostEqual(G_star_L, 1.0130571021, places=7)

        # Right-mode prediction
        G_star_R = compute_transfer_gain_prediction(lambda_star_right_mode, alpha=alpha, dt=dt, eta=eta, mu=mu)
        expected_G_star_R = 0.0007 * alpha / (alpha - lambda_star_right_mode)

        self.assertAlmostEqual(G_star_R, expected_G_star_R, places=12)
        self.assertAlmostEqual(G_star_R, 0.0013990334, places=7)

    def test_directed_alignment_decomposition_identity(self):
        """Test exact identity e_n = T_1,n + T_2,n and e_n = 2 * Delta A_n - Delta M_n."""
        rng = np.random.default_rng(999)
        C_a = rng.uniform(-1, 1, 50) + 1j * rng.uniform(-1, 1, 50)
        C_b = rng.uniform(-1, 1, 50) + 1j * rng.uniform(-1, 1, 50)
        dphi_a = rng.uniform(-0.1, 0.1, 50)
        dphi_b = rng.uniform(-0.1, 0.1, 50)

        res = compute_directed_alignment_decomposition(C_a, C_b, dphi_a, dphi_b)

        # e_n identity check: e_n == 2 * Delta A_n - Delta M_n
        e_calc = 2.0 * res["delta_A"] - res["delta_M"]
        np.testing.assert_allclose(res["e_n"], e_calc, atol=1e-15)

        # T1 + T2 identity check: e_n == T1 + T2
        T_sum = res["T_1"] + res["T_2"]
        np.testing.assert_allclose(res["e_n"], T_sum, atol=1e-14)

    def test_synthetic_aligned_audit_workflow(self):
        """Test complete directed alignment audit workflow."""
        data = generate_synthetic_aligned_replay(num_steps=300, dt=DEFAULT_DT, eta=0.05, mu=0.02)
        df_alignment, df_transfer, summary, trajectories = run_directed_alignment_audit(data, eta=0.05, mu=0.02)

        self.assertTrue(summary["cone_invariance_passed"])
        self.assertEqual(len(df_alignment), 2)
        self.assertEqual(len(df_transfer), 2)

        # Verify NPZ trajectory array shapes
        self.assertEqual(len(trajectories["dx_L"]), 300)
        self.assertEqual(len(trajectories["e_L"]), 300)


if __name__ == "__main__":
    unittest.main()
