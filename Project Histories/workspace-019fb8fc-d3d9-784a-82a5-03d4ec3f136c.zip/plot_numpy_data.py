#!/usr/bin/env python3
"""
Universal NumPy (.npy / .npz) Visualizer & Inspector

Designed to run on Linux / Steam Deck.

Usage:
    python3 plot_numpy_data.py <path_to_file.npy_or_npz> [--output_dir <output_dir>]

Examples:
    python3 plot_numpy_data.py data.npy
    python3 plot_numpy_data.py trajectory.npz --output_dir my_plots
"""

import sys
import os
import argparse
import numpy as np
import matplotlib.pyplot as plt


def inspect_and_plot_array(arr: np.ndarray, name: str, output_dir: str):
    """
    Inspect array properties and generate clean visualization plots based on array shape.
    """
    print(f"\n--- Array: '{name}' ---")
    print(f"Shape: {arr.shape}")
    print(f"Dtype: {arr.dtype}")

    # Convert complex arrays to real magnitude for plotting if necessary
    if np.iscomplexobj(arr):
        print("Note: Complex data detected — plotting magnitude |arr|.")
        arr_plot = np.abs(arr)
    else:
        arr_plot = arr.astype(np.float64)

    # Basic stats
    print(f"Min:   {np.nanmin(arr_plot):.6g}")
    print(f"Max:   {np.nanmax(arr_plot):.6g}")
    print(f"Mean:  {np.nanmean(arr_plot):.6g}")
    print(f"Std:   {np.nanstd(arr_plot):.6g}")

    # Determine plot layout based on dimensions
    ndim = arr_plot.ndim

    fig = plt.figure(figsize=(10, 6))

    if ndim == 1:
        # 1D Array: Line plot & Histogram
        plt.subplot(1, 2, 1)
        plt.plot(arr_plot, color='steelblue', linewidth=1.5)
        plt.title(f"{name} — Line Plot (1D)")
        plt.xlabel("Index")
        plt.ylabel("Value")
        plt.grid(True, alpha=0.3)

        plt.subplot(1, 2, 2)
        plt.hist(arr_plot[~np.isnan(arr_plot)], bins=30, color='teal', edgecolor='black', alpha=0.7)
        plt.title(f"{name} — Value Distribution")
        plt.xlabel("Value")
        plt.ylabel("Count")
        plt.grid(True, alpha=0.3)

    elif ndim == 2:
        # 2D Array: Heatmap & First few row/column traces
        plt.subplot(1, 2, 1)
        im = plt.imshow(arr_plot, aspect='auto', cmap='viridis')
        plt.colorbar(im, label="Value")
        plt.title(f"{name} — 2D Heatmap ({arr_plot.shape[0]}x{arr_plot.shape[1]})")
        plt.xlabel("Column Axis")
        plt.ylabel("Row Axis")

        plt.subplot(1, 2, 2)
        # Plot up to first 5 rows/columns as line traces
        max_traces = min(5, arr_plot.shape[0])
        for i in range(max_traces):
            plt.plot(arr_plot[i, :], label=f"Row {i}")
        plt.title(f"{name} — Row Slices (First {max_traces})")
        plt.xlabel("Column Index")
        plt.ylabel("Value")
        plt.legend(loc='upper right')
        plt.grid(True, alpha=0.3)

    elif ndim >= 3:
        # 3D+ Array: Mean projection along first axis & middle slice
        slice_idx = arr_plot.shape[0] // 2
        slice_2d = arr_plot[slice_idx]
        if slice_2d.ndim > 2:
            slice_2d = np.mean(slice_2d, axis=tuple(range(2, slice_2d.ndim)))

        plt.subplot(1, 2, 1)
        im1 = plt.imshow(slice_2d, aspect='auto', cmap='magma')
        plt.colorbar(im1, label="Value")
        plt.title(f"{name} — Slice at Index [{slice_idx}]")
        plt.xlabel("Axis 2")
        plt.ylabel("Axis 1")

        plt.subplot(1, 2, 2)
        mean_proj = np.mean(arr_plot, axis=0)
        if mean_proj.ndim > 2:
            mean_proj = np.mean(mean_proj, axis=tuple(range(2, mean_proj.ndim)))
        im2 = plt.imshow(mean_proj, aspect='auto', cmap='plasma')
        plt.colorbar(im2, label="Mean Value")
        plt.title(f"{name} — Mean Projection Across Axis 0")
        plt.xlabel("Axis 2")
        plt.ylabel("Axis 1")

    plt.tight_layout()

    # Save figure
    safe_name = "".join([c if c.isalnum() else "_" for c in name])
    output_path = os.path.join(output_dir, f"plot_{safe_name}.png")
    plt.savefig(output_path, dpi=150)
    plt.close(fig)
    print(f"Saved plot: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Inspect and plot NumPy (.npy / .npz) data files.")
    parser.add_argument("input_file", type=str, help="Path to .npy or .npz data file")
    parser.add_argument("--output_dir", type=str, default="numpy_plots", help="Directory to save generated plots")

    args = parser.parse_args()

    if not os.path.exists(args.input_file):
        print(f"Error: File '{args.input_file}' not found.", file=sys.stderr)
        sys.exit(1)

    os.makedirs(args.output_dir, exist_ok=True)

    print(f"Loading file: {args.input_file}")

    if args.input_file.endswith(".npz"):
        # Compressed multi-array file
        data = np.load(args.input_file, allow_pickle=False)
        keys = list(data.files)
        print(f"File format: .npz archive containing {len(keys)} arrays: {keys}")

        for key in keys:
            arr = data[key]
            inspect_and_plot_array(arr, key, args.output_dir)

    elif args.input_file.endswith(".npy"):
        # Single array file
        arr = np.load(args.input_file, allow_pickle=False)
        base_name = os.path.splitext(os.path.basename(args.input_file))[0]
        print(f"File format: .npy single array")
        inspect_and_plot_array(arr, base_name, args.output_dir)

    else:
        print("Warning: File extension is not .npy or .npz. Attempting np.load...")
        try:
            loaded = np.load(args.input_file, allow_pickle=False)
            if hasattr(loaded, 'files'):
                for key in loaded.files:
                    inspect_and_plot_array(loaded[key], key, args.output_dir)
            else:
                base_name = os.path.splitext(os.path.basename(args.input_file))[0]
                inspect_and_plot_array(loaded, base_name, args.output_dir)
        except Exception as e:
            print(f"Error loading file: {e}", file=sys.stderr)
            sys.exit(1)

    print(f"\nAll plots saved to directory: '{args.output_dir}/'")


if __name__ == "__main__":
    main()
