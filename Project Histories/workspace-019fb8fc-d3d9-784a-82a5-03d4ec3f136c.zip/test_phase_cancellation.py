"""
Unit Test Suite for Phase-Cancellation Analyzer
"""

import unittest
import numpy as np

from aief_1_4_phase_cancellation_analyzer import (
    analytical_linearized_cancellation,
    compute_phase_cancellation_components,
    run_self_test
)


class TestPhaseCancellation(unittest.TestCase):

    def test_linearized_cancellation(self):
        """Test first order cancellation T1_lin + T2_lin = 0."""
        res = analytical_linearized_cancellation(0.1, 0.08, 0.02, 0.015)
        self.assertTrue(res["cancellation_exact_first_order"])
        self.assertAlmostEqual(res["residual_lin"], 0.0, places=14)

    def test_exact_residual(self):
        """Test exact residual identity e = T1 + T2."""
        C_a = 0.8 + 0.2j
        C_b = 0.75 + 0.18j
        Z_a = np.exp(1j * 0.05)
        Z_b = np.exp(1j * 0.04)
        comp = compute_phase_cancellation_components(C_a, C_b, Z_a, Z_b)
        self.assertAlmostEqual(comp["e"], comp["T1"] + comp["T2"], places=14)

    def test_self_test_runner(self):
        """Verify run_self_test executes cleanly."""
        run_self_test()  # Should not raise exception


if __name__ == "__main__":
    unittest.main()
