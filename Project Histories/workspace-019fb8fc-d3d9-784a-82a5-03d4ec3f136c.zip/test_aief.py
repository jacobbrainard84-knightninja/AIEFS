"""
Comprehensive Unit & Synthetic Test Suite for AIEF-1.4 Models & Audit Tools
"""

import unittest
import numpy as np
import os
import tempfile
import json

from aief_core import (
    DEFAULT_DT, DEFAULT_ALPHA_EMA, DEFAULT_R_EMA, DEFAULT_SAFEGUARD,
    EXCEPTIONAL_SEED, K3_NODES, K3_EDGE_INDICES, K3_EDGE_WINNERS,
    K3_V_VECTOR, K3_U_VECTOR,
    compute_complex_ema, compute_physical_driver_R, compute_forcing_F,
    compute_euler_proposal, apply_global_projection_gate,
    compute_proposal_recurrence_step, evaluate_channel_identities
)
from aief_proposal_bridge import generate_synthetic_replay_data, run_proposal_equalization_audit


class TestAIEFCore(unittest.TestCase):

    def test_k3_vector_orthogonality(self):
        """Test analytic vector properties u^T v = 1."""
        inner_prod = np.dot(K3_U_VECTOR, K3_V_VECTOR)
        self.assertAlmostEqual(inner_prod, 1.0, places=14)

    def test_symmetrization_and_zero_diagonal(self):
        """Test driver R and Euler proposal symmetrization and zero diagonal properties."""
        rng = np.random.default_rng(123)
        C = rng.uniform(-1, 1, (12, 12)) + 1j * rng.uniform(-1, 1, (12, 12))
        R = compute_physical_driver_R(C)
        
        # Symmetry check
        np.testing.assert_allclose(R, R.T, atol=1e-15)
        # Zero diagonal check
        np.testing.assert_allclose(np.diag(R), 0.0, atol=1e-15)

    def test_euler_proposal_nonnegativity(self):
        """Test that Euler proposal satisfies nonnegativity B >= 0."""
        rng = np.random.default_rng(456)
        B = rng.uniform(0.1, 0.5, (12, 12))
        F = rng.uniform(-10.0, 1.0, (12, 12))  # contains strong negative forcing
        P = compute_euler_proposal(B, F, dt=0.01)
        
        self.assertTrue(np.all(P >= 0.0))
        np.testing.assert_allclose(P, P.T, atol=1e-15)
        np.testing.assert_allclose(np.diag(P), 0.0, atol=1e-15)

    def test_global_projection_gate_scaling(self):
        """Test row violation global gate scaling behavior."""
        capacities = np.full(12, 1.0)
        # Construct proposal where row 0 exceeds capacity 1.0
        P = np.zeros((12, 12), dtype=np.float64)
        P[0, 1] = 1.5
        P[1, 0] = 1.5
        
        P_proj, scale, is_gated = apply_global_projection_gate(P, capacities)
        self.assertTrue(is_gated)
        self.assertLess(scale[0], 1.0)
        
        # Check projected row sums do not exceed capacity
        row_sums_proj = np.sum(P_proj, axis=1)
        self.assertTrue(np.all(row_sums_proj <= capacities + 1e-10))

    def test_exact_proposal_recurrence_closure(self):
        """Test exact proposal recurrence identity closure on synthetic trajectory."""
        N = 100
        dt = 0.01
        eta, mu, gamma = 0.5, 0.1, 0.2
        
        # Synthesize exact recurrence
        r_seq = np.sin(np.linspace(0, 10, N))
        d_proj_seq = np.linspace(0.5, 0.1, N)
        d_seq = np.zeros(N)
        d_seq[0] = d_proj_seq[0]
        for n in range(N - 1):
            d_seq[n + 1] = compute_proposal_recurrence_step(d_proj_seq[n], gamma, r_seq[n + 1], eta, mu, dt)
            
        res = evaluate_channel_identities(d_seq, d_proj_seq, r_seq, gamma, eta, mu, dt)
        
        self.assertLess(res["max_err_proposal_recurrence"], 1e-15)
        self.assertLess(res["max_err_step_diff"], 1e-15)

    def test_finite_difference_rate_convergence(self):
        """Verify finite-difference vs analytic decay rate for e^{-r t}."""
        dt = 0.01
        t = np.arange(1000) * dt
        r_true = 0.0571333334
        signal = np.exp(-r_true * t)
        
        # Discrete finite difference derivative
        dsignal_dt = (signal[2:] - signal[:-2]) / (2 * dt)
        r_est = -dsignal_dt / signal[1:-1]
        
        np.testing.assert_allclose(r_est, r_true, rtol=1e-3)


class TestBridgeAudit(unittest.TestCase):

    def test_synthetic_audit_run(self):
        """Test complete bridge audit workflow on synthetic replay data."""
        data = generate_synthetic_replay_data(num_steps=200, dt=DEFAULT_DT)
        df_results, summary = run_proposal_equalization_audit(data)
        
        self.assertEqual(summary["gate_status"], "PASSED")
        self.assertEqual(len(df_results), 2)
        self.assertIn("fixed_left_25_59", df_results["channel"].values)
        self.assertIn("right_mode_59_29", df_results["channel"].values)
        
        # Max errors should be machine precision level (~1e-16)
        self.assertLess(summary["left_channel_max_err"], 1e-14)
        self.assertLess(summary["right_channel_max_err"], 1e-14)


if __name__ == "__main__":
    unittest.main()
