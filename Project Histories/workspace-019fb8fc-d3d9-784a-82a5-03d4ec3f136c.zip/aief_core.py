"""
AIEF-1.4 Core Model & Mathematical Definitions Module

Provides exact implementations for:
- Complex EMA state updates
- Physical driver R and forcing F
- Finite Euler proposal calculation
- Symmetrization and zero-diagonal projection
- Row-sum global gate scaling
- K3 subgraph indexing, winner mapping, and analytic vectors
- Exact proposal-equalization recurrences and channel identities
- Two-channel directed alignment decomposition and transfer gain formulas
"""

import numpy as np
from typing import Dict, Tuple, Any

# Frozen AIEF-1.4 Default Constants
DEFAULT_DT = 0.01
DEFAULT_ALPHA_EMA = 0.999428829846
DEFAULT_R_EMA = -np.log(DEFAULT_ALPHA_EMA) / DEFAULT_DT  # ~0.0571333334
DEFAULT_SAFEGUARD = 1e-12

# K3 Exceptional Seed & Graph Indexing Constants
EXCEPTIONAL_SEED = "4619122171158768524"
K3_NODES = [2, 7, 11]
K3_EDGE_INDICES = {
    "25": (2, 7),
    "29": (2, 11),
    "59": (7, 11)
}
K3_EDGE_WINNERS = {
    25: 7,
    29: 2,
    59: 7
}

# K3 Analytic Vectors (Section 6)
K3_V_VECTOR = np.array([1.0, -1.0, -1.0], dtype=np.float64) / np.sqrt(3.0)
K3_U_VECTOR = np.sqrt(3.0) * np.array([1.0, 0.0, -1.0], dtype=np.float64) / 2.0
# Ensure normalization u^T v = 1
assert np.isclose(np.dot(K3_U_VECTOR, K3_V_VECTOR), 1.0)


def compute_complex_ema(C_prev: np.ndarray, delta_phi: np.ndarray, alpha: float = DEFAULT_ALPHA_EMA) -> np.ndarray:
    """
    Complex EMA update: C_{n+1} = alpha * C_n + (1 - alpha) * exp(i * delta_phi_n)
    """
    forcing = np.exp(1j * delta_phi)
    return alpha * C_prev + (1.0 - alpha) * forcing


def compute_physical_driver_R(C: np.ndarray) -> np.ndarray:
    """
    Physical driver R = |C|, symmetrized with zero diagonal.
    """
    R = np.abs(C)
    R = 0.5 * (R + R.T)
    np.fill_diagonal(R, 0.0)
    return R


def compute_forcing_F(R: np.ndarray, B: np.ndarray, eta: float, mu: float, gamma: float) -> np.ndarray:
    """
    Forcing term: F = (eta + mu) * R - mu - gamma * B
    """
    return (eta + mu) * R - mu - gamma * B


def compute_euler_proposal(B: np.ndarray, F: np.ndarray, dt: float = DEFAULT_DT) -> np.ndarray:
    """
    Implemented finite Euler proposal:
    proposal = B + dt * F
    proposal = max(proposal, 0.0)
    proposal = 0.5 * (proposal + proposal.T)
    zero diagonal
    """
    proposal = B + dt * F
    proposal = np.maximum(proposal, 0.0)
    proposal = 0.5 * (proposal + proposal.T)
    np.fill_diagonal(proposal, 0.0)
    return proposal


def apply_global_projection_gate(proposal: np.ndarray, capacities: np.ndarray, safeguard: float = DEFAULT_SAFEGUARD) -> Tuple[np.ndarray, np.ndarray, bool]:
    """
    Global gate determined by proposal row violation:
    scale = min(1.0, capacities / (row_sum + safeguard))
    projected = proposal * min.outer(scale, scale)
    Returns (projected_B, scale_vector, is_gated)
    """
    row_sum = np.sum(proposal, axis=1)
    scale = np.minimum(1.0, capacities / (row_sum + safeguard))
    outer_scale = np.minimum.outer(scale, scale)
    projected = proposal * outer_scale
    is_gated = bool(np.any(scale < 1.0))
    return projected, scale, is_gated


def compute_proposal_recurrence_step(
    d_proj_n: float, 
    gamma: float, 
    r_n_plus_1: float, 
    eta: float, 
    mu: float, 
    dt: float = DEFAULT_DT
) -> float:
    """
    Exact downstream forced proposal recurrence step:
    d_{n+1} = (1 - dt * gamma) * d_proj_n + dt * (eta + mu) * r_{n+1}
    """
    return (1.0 - dt * gamma) * d_proj_n + dt * (eta + mu) * r_n_plus_1


def evaluate_channel_identities(
    d_proposal: np.ndarray,
    d_projected: np.ndarray,
    r_resonance: np.ndarray,
    gamma: float,
    eta: float,
    mu: float,
    dt: float = DEFAULT_DT
) -> Dict[str, float]:
    """
    Evaluate exact implementation closure errors for a channel trajectory.
    Uses exact identity: d_{n+1} = (1 - dt * gamma) * d_proj_n + dt * (eta + mu) * r_{n+1}
    Returns maximum absolute errors across the trajectory.
    """
    N = len(d_proposal)
    if N < 2:
        return {}

    # One-step exact recurrence check
    predicted_d_next = (1.0 - dt * gamma) * d_projected[:-1] + dt * (eta + mu) * r_resonance[1:]
    actual_d_next = d_proposal[1:]
    
    err_step_diff = np.max(np.abs(actual_d_next - predicted_d_next))

    # Full trajectory recurrence check
    d_rec = np.zeros(N, dtype=np.float64)
    d_rec[0] = d_proposal[0]
    for n in range(N - 1):
        d_rec[n + 1] = (1.0 - dt * gamma) * d_projected[n] + dt * (eta + mu) * r_resonance[n + 1]

    err_proposal_recurrence = np.max(np.abs(d_proposal - d_rec))

    return {
        "max_err_proposal_recurrence": float(err_proposal_recurrence),
        "max_err_step_diff": float(err_step_diff)
    }


def compute_transfer_gain_prediction(
    lambda_star: float,
    alpha: float = DEFAULT_ALPHA_EMA,
    dt: float = DEFAULT_DT,
    eta: float = 0.5,
    mu: float = 0.1
) -> float:
    """
    Asymptotic Transfer-Gain Ratio formula:
    G_* = dt * (eta + mu) * alpha / (alpha - lambda_star)
    """
    denom = alpha - lambda_star
    if abs(denom) < 1e-15:
        return float("nan")
    return float(dt * (eta + mu) * alpha / denom)


def compute_directed_alignment_decomposition(
    C_a: np.ndarray,
    C_b: np.ndarray,
    delta_phi_a: np.ndarray,
    delta_phi_b: np.ndarray
) -> Dict[str, np.ndarray]:
    """
    Exact two-channel directed alignment decomposition:
    - Driver R_a = |C_a|, R_b = |C_b|, Delta R = R_a - R_b
    - Magnitude M_a = |C_a|^2, M_b = |C_b|^2, Delta M = M_a - M_b
    - Directed forcing z_a = exp(i * delta_phi_a), z_b = exp(i * delta_phi_b)
    - Alignment terms A_a = Re(C_a z_a^*), A_b = Re(C_b z_b^*), Delta A = A_a - A_b
    - Exact residual e_n = 2 * Delta A_n - Delta M_n
    - Exact decomposition e_n = T_1,n + T_2,n where:
        T_1,n = 2 * Re(C_bar * (Delta z^* - Delta C^*))
        T_2,n = 2 * Re(Delta C * z_bar^*)
    - Cancellation index = |T_1 + T_2| / (|T_1| + |T_2| + 1e-18)
    """
    R_a = np.abs(C_a)
    R_b = np.abs(C_b)
    delta_R = R_a - R_b

    M_a = np.abs(C_a)**2
    M_b = np.abs(C_b)**2
    delta_M = M_a - M_b

    z_a = np.exp(1j * delta_phi_a)
    z_b = np.exp(1j * delta_phi_b)

    A_a = np.real(C_a * np.conj(z_a))
    A_b = np.real(C_b * np.conj(z_b))
    delta_A = A_a - A_b

    # Exact residual
    e_n = 2.0 * delta_A - delta_M

    # State and forcing differences & means
    delta_C = C_a - C_b
    C_bar = 0.5 * (C_a + C_b)
    delta_z = z_a - z_b
    z_bar = 0.5 * (z_a + z_b)

    T_1 = 2.0 * np.real(C_bar * np.conj(delta_z - delta_C))
    T_2 = 2.0 * np.real(delta_C * np.conj(z_bar))

    cancellation_index = np.abs(T_1 + T_2) / (np.abs(T_1) + np.abs(T_2) + 1e-18)

    return {
        "delta_R": delta_R,
        "delta_M": delta_M,
        "delta_A": delta_A,
        "e_n": e_n,
        "T_1": T_1,
        "T_2": T_2,
        "cancellation_index": cancellation_index
    }
