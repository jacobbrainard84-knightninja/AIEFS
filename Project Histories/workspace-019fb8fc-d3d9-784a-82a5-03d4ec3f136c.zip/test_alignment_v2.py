"""
Comprehensive Test Suite for AIEF-1.4 Two-Channel Directed Alignment Decomposition V2
"""

import unittest
import numpy as np
import os
import tempfile
from pathlib import Path

from aief_1_4_two_channel_alignment_v2 import (
    validate_edge_indexing,
    count_sign_changes,
    channel_quantities,
    test_alignment_identity,
    test_radial_identity,
    test_symmetrization_identity,
    run_self_test
)


class TestAlignmentV2(unittest.TestCase):

    def test_edge_indexing_tuple_of_arrays(self):
        """Verify validate_edge_indexing works on tuple of arrays (edge_i, edge_j)."""
        edge_i = np.zeros(60, dtype=int)
        edge_j = np.zeros(60, dtype=int)
        edge_i[25], edge_j[25] = 2, 7
        edge_i[29], edge_j[29] = 2, 11
        edge_i[59], edge_j[59] = 7, 11

        edges = (edge_i, edge_j)
        validate_edge_indexing(edges)  # Should pass without error

    def test_count_sign_changes_with_below_floor_gap(self):
        """Verify count_sign_changes handles below-floor gaps correctly."""
        arr = np.array([0.5, 0.2, 1e-18, -0.1, -0.4])
        pos, neg, sc = count_sign_changes(arr, tol=1e-14)
        self.assertEqual(pos, 2)
        self.assertEqual(neg, 2)
        self.assertEqual(sc, 1)  # Exactly 1 transition from positive to negative

    def test_exact_channel_identities(self):
        """Verify e_n = T_1 + T_2 exact identity on random complex inputs."""
        rng = np.random.default_rng(42)
        C_a = rng.uniform(-1, 1) + 1j * rng.uniform(-1, 1)
        C_b = rng.uniform(-1, 1) + 1j * rng.uniform(-1, 1)
        Z_a = np.exp(1j * rng.uniform(-0.5, 0.5))
        Z_b = np.exp(1j * rng.uniform(-0.5, 0.5))

        q = channel_quantities(C_a, C_b, Z_a, Z_b)
        res = test_alignment_identity(
            np.array([q["alignment_residual"]]),
            np.array([q["T1"]]),
            np.array([q["T2"]]),
            tol=1e-12
        )
        self.assertTrue(res["identity_passes"])

    def test_symmetrization_identity(self):
        """Verify D_sym = Delta R identity."""
        D_sym = np.array([0.05, 0.02])
        DeltaR = np.array([0.05, 0.02])
        res = test_symmetrization_identity(D_sym, DeltaR, tol=1e-12)
        self.assertTrue(res["identity_passes"])

    def test_self_test_runner(self):
        """Verify self-test routine executes cleanly."""
        self.assertTrue(run_self_test())


if __name__ == "__main__":
    unittest.main()
