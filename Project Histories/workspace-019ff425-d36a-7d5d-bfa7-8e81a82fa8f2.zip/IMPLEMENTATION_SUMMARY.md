# Implementation Summary: P0 and P1 Fixes for aief_experiment_engine_v1.py

## Overview
This document summarizes all P0 (must fix before baseline) and P1 (strongly recommended) fixes implemented in `aief_experiment_engine_v1.py` as specified in the detailed code review.

## P0 Issues (MUST FIX BEFORE BASELINE) - All Complete ✅

### P0 #1: Extended scalar equivalence map not used
**Problem**: Local `frozen_scalar_map` and `frozen_key_map` were defined in `run_baseline_equivalence()` instead of using module-level `EXTENDED_SCALAR_EQUIVALENCE_MAP`. Extended scalar keys were only checked for presence, not equality.

**Implementation**:
- Created new module-level constant `EXTENDED_MATRIX_EQUIVALENCE_MAP` containing mappings for all extended matrix keys
- Replaced local `frozen_key_map` in matrix validation section with `EXTENDED_MATRIX_EQUIVALENCE_MAP[key]` using direct indexing
- Replaced local `frozen_scalar_map` in scalar validation section with `EXTENDED_SCALAR_EQUIVALENCE_MAP[key]` using direct indexing
- Moved `EXTENDED_SCALAR_EQUIVALENCE_MAP` definition before validation code to avoid NameError at module load time

**Files Modified**: `aief_experiment_engine_v1.py`

---

### P0 #2: Duplicate in EXTENDED_BRANCH_SCALAR_KEYS  
**Problem**: `REQUIRED_BRANCH_SCALAR_KEYS` assignment appeared twice in the file.

**Implementation**:
- Removed duplicate assignment of `REQUIRED_BRANCH_SCALAR_KEYS` (was defined at lines ~1650 and ~1681, now only once)
- Verified "Corr_Rpast_Plate_normalized_EMA" is NOT duplicated in `EXTENDED_BRANCH_SCALAR_KEYS` (it appears only once)

**Files Modified**: `aief_experiment_engine_v1.py`

---

### P0 #3: Validate baseline horizon metadata
**Problem**: Need to verify `window_steps`, `recovery_end_ema`, `fixed_immediate_end`, `fixed_recovery_end` at frozen baseline (rho=1).

**Implementation**:
- Added validation in `run_baseline_equivalence()` that checks these four values match `BASELINE_HORIZON_METADATA` when `T_window == T_star` (rho=1)
- Validation fails with descriptive error message if any value doesn't match

**Files Modified**: `aief_experiment_engine_v1.py`

---

### P0 #4: Seed/branch authority validation
**Problem**: Need to validate seeds and branches match manifest before simulation.

**Implementation**:
- Added validation in `run_baseline_equivalence()` that:
  - `seeds` must exactly match `frozen_manifest["randomization"]["paired_seeds"]` (converted to int)
  - `branch_order` must exactly match `frozen_manifest["protocol"]["branches"]` (as tuple)
- Fails immediately with descriptive error if either check fails

**Files Modified**: `aief_experiment_engine_v1.py`

## P1 Issues (STRONGLY RECOMMENDED) - All Complete ✅

### P1 #5: CSV duplicate detection
**Problem**: Current parser silently overwrites duplicate `(seed, branch)` rows in CSV.

**Implementation**:
- Modified CSV parser in `run_baseline_equivalence()` to detect duplicates
- When a duplicate key is encountered, immediately returns failure with error message indicating which key was duplicated
- Uses the pattern: if `key in frozen_scalar_csv: return error` before adding new entries

**Files Modified**: `aief_experiment_engine_v1.py`

---

### P1 #6: Preflight all authority files
**Problem**: Files are opened before existence checks.

**Implementation**:
- Added existence checks for all authority files before any file operations:
  - `frozen_manifest_path` - checked with `os.path.isfile()`
  - `frozen_npz_path` - checked with `os.path.isfile()`
  - `frozen_csv_path` - checked with `os.path.isfile()` (if not None)
- Each check returns descriptive error if file is missing

**Files Modified**: `aief_experiment_engine_v1.py`

---

### P1 #7: Preflight frozen NPZ schema
**Problem**: Expected NPZ keys should be validated before simulation.

**Implementation**:
- Added validation after loading frozen NPZ that checks:
  - All required prefix keys exist for all seeds (e.g., `prefix_seed_{seed}_B_at_split`)
  - All frozen branch matrix keys exist for all seeds and branches (e.g., `{branch}_seed_{seed}_B_final`)
- Fails immediately with descriptive error if any required key is missing

**Files Modified**: `aief_experiment_engine_v1.py`

---

### P1 #8: Remove scalar fallback to NPZ
**Problem**: Should use CSV as authority, not NPZ fallback for scalar values.

**Implementation**:
- Removed the fallback logic that tried NPZ if scalar not found in CSV
- Now only uses CSV as the source of truth for scalar values
- If a scalar key is not found in CSV, it fails with "present_in_frozen" check

**Files Modified**: `aief_experiment_engine_v1.py`

---

### P1 #9: Match frozen persistence-ratio condition
**Problem**: Need to match frozen source exactly for persistence ratio condition.

**Implementation**:
- Verified that `finalize_historical_branch_metrics()` already uses the correct condition:
  ```python
  if np.isfinite(reference_late_persistence) and abs(reference_late_persistence) > FROZEN_ZERO_TOL:
  ```
- This matches the frozen production which uses both `isfinite()` and `abs() > ZERO_TOL` checks

**Files Modified**: None (already correct)

---

### P1 #10-11: Validation hardening
**Problem**: Need integer validation and state validation at transition boundaries.

**Implementation**:
- **Integer validation**: Added type check in `ProtocolConfig.validate()` to ensure `diagnostic_stride` is an integer
- **State validation at transition boundaries**:
  - In `simulate_prefix()`: Added `state.validate(config, step)` at `burn_end` and `hist_end - 1`
  - In `simulate_future()`: Added `state.validate(config, step)` at steps: 0, `window_steps`, `recovery_end_ema`, `fixed_immediate_end`, `fixed_recovery_end`

**Files Modified**: `aief_experiment_engine_v1.py`

## Testing

All changes have been verified with:
1. ✅ Syntax check passes (`python3 -m py_compile`)
2. ✅ Module loads successfully
3. ✅ All module-level constants are accessible
4. ✅ All validation code is in place and functional
5. ✅ Default configurations validate correctly
6. ✅ No duplicate keys in any schema definitions

## Files Modified

- `/home/user/aief_experiment_engine_v1.py` - All P0 and P1 fixes implemented

## Files NOT Modified (as required)

- `/home/user/AIEF_1_4_memory_ablation_updated_REAL.py` - Frozen production file, left unchanged

## Next Steps

The engine is now ready for baseline equivalence testing. All P0 issues (must fix) and P1 issues (strongly recommended) have been implemented. The next step would be to run the baseline equivalence test with actual frozen data files to verify the implementation.
