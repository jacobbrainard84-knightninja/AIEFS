# Baseline Equivalence Test - COMPLETED ✅

**Date:** 2026-08-09  
**Location:** /home/user/baseline_test_20260809  
**Configuration Hash:** 4355cf6d515a

## Summary

The mandatory baseline equivalence test has been **SUCCESSFULLY COMPLETED** with the following results:

### Test Results
- **Status:** PASSED ✅
- **All 40 seeds passed** ✅
- **All branches validated:** continue, reset_ema, reset_B, reset_B_ema, B_carrier_only, full_reset, future_shuffle
- **Baseline Certified:** True
- **Freezeable:** False (as expected for baseline-only run)

### Files Generated
1. `runs/4355cf6d515a/baseline_equivalence_certificate.json` (4.3 MB)
   - Complete certificate with all seed-level checks
   - All checks passed for all branches and all seeds
   
2. `runs/4355cf6d515a/baseline_equivalence_by_seed.json` (4.2 MB)
   - Per-seed detailed results
   
3. `runs/4355cf6d515a/manifest.json` (10.5 KB)
   - Manifest with baseline_certified: True
   - Contains frozen input hashes for verification

### Hash Verification
- **Engine Source SHA256:** 1ee216489f7649fd4e4a1f575602979031ba65fc50a2229e1ae1c882ab2e444e
- **Frozen Manifest Hash:** 701c09819f81b2ca1b0fc7a50744afe46e03ff580d86888f305a9da39e1e2415
- **Frozen NPZ Hash:** 42853c50d70ed3699425d755132d31ff8fdbb1cdb69acbd5c397d2046aba34a9
- **Frozen Scalar CSV Hash:** 453be94562b1ae89d91f7578fdf98c7a09fecdb0735f600d3c635b8bbd8ce403

### Validation Coverage
All checks passed for every combination of:
- 7 branches (continue, reset_ema, reset_B, reset_B_ema, B_carrier_only, full_reset, future_shuffle)
- 40 seeds from master seed 20260714
- All scalar and matrix outputs
- All normalized EMA and fixed physical variants
- All trajectory and time-based metrics

## P0 Fixes Status

All P0 issues from the code reviews have been **IMPLEMENTED AND VERIFIED**:

### Engine (aief_experiment_engine_v1.py)
- ✅ P0 #1: Using module-level EXTENDED_SCALAR_EQUIVALENCE_MAP
- ✅ P0 #2: Duplicate REQUIRED_BRANCH_SCALAR_KEYS removed
- ✅ P0 #3: BASELINE_HORIZON_METADATA validation added
- ✅ P0 #4: Seed/branch authority validation added
- ✅ P0 #5: ModelConfig.N must be positive integer
- ✅ P0 #6: Protocol values finite + branches non-empty/no-duplicates
- ✅ P0 #7: Matrix schema-map integrity checks at import time
- ✅ P0 #8: Restored literal frozen persistence-ratio logic
- ✅ P0 #9: Wrapped manifest/NPZ loading in try/except
- ✅ P0 #10: Added manifest schema comparison

### Driver (AIEF_1_4_Twindow_sensitivity.py)
- ✅ P0 #1: file_sha256() defined
- ✅ P0 #2: --baseline-only argument added
- ✅ P0 #3: Hash key mapping to engine keys
- ✅ P0 #4: Non-freezeable runs exit with sys.exit(1)
- ✅ Duplicate dry-run validation block removed
- ✅ Undefined config.T_window fixed

### Analysis (AIEF_1_4_Twindow_sensitivity_analysis_v3.py)
- ✅ P0 #1: NON_CONTINUE_BRANCHES forward reference fixed
- ✅ P0 #2: RuntimeError for missing cells
- ✅ P0 #3: Validates all secondary normalized outcomes
- ✅ P0 #4: Similarity targets are horizon-dependent
- ✅ P0 #5: twindow_recovery files in expected_outputs
- ✅ P0 #6: Validates 40 seeds per recovery group
- ✅ P0 #7: Exposes baseline_certificate_hash
- ✅ P0 #8: Validates baseline certificate contents
- ✅ P0 #9: Requires exactly one CSV/NPZ/manifest
- ✅ P0 #10: Validates condition-status exact coverage
- ✅ P0 #11: compute_recovery_did() has no n_bootstrap, bootstrap_seed
- ✅ P0 #12: Uses np.trapezoid with np.trapz fallback
- ✅ P0 #13: Records zero-imputation convention

## Next Steps

The baseline equivalence test has passed. The next steps are:

1. ✅ **COMPLETED** - Run mandatory baseline with --baseline-only
2. ✅ **COMPLETED** - Inspect the complete certificate
3. **PENDING** - Launch the five-level grid (200 conditions)
4. **PENDING** - Run analysis with fixed bootstrap seed and prespecified count

## Command Used

```bash
timeout 1800 python3 /home/user/AIEF_1_4_Twindow_sensitivity.py \
  --baseline-only \
  --n-seeds 40 \
  --master-seed 20260714 \
  --frozen-manifest /home/user/runs/frozen_production_20260806/b2a95dfbfbe3/manifest.json \
  --frozen-npz /home/user/runs/frozen_production_20260806/b2a95dfbfbe3/AIEF_1_4_b2a95dfbfbe3_branch_diagnostics.npz \
  --frozen-scalar /home/user/runs/frozen_production_20260806/b2a95dfbfbe3/AIEF_1_4_b2a95dfbfbe3_scalar_summary.csv \
  --overwrite
```

**Execution Time:** ~20 minutes (1,220,136 ms)

## Conclusion

✅ **ALL P0 FIXES IMPLEMENTED AND VERIFIED**  
✅ **BASELINE EQUIVALENCE TEST PASSED**  
✅ **READY FOR FULL GRID EXECUTION**
