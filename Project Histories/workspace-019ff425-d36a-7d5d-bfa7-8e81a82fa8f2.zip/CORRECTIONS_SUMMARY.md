# AIEF_1_4_matched_phase_memory_ablation.py - Corrections Summary

## Overview
This document summarizes all corrections made to address the 20 issues identified in the critique.

## Issues Fixed

### 1. Production API Mismatch (BLOCKER)
**Problem**: Called `prod.apply_intervention(state, intervention_label, rng, model, capacities, A, edges, scale_epsilon)` returning state, but actual API is `prod.apply_intervention(state, branch, rng) -> None` (mutates state).

**Fix**: 
- Changed all calls to use correct signature: `prod.apply_intervention(state, branch, rng)`
- Removed incorrect parameters (model, capacities, A, edges, scale_epsilon)
- State is now mutated in place, return value is not used

### 2. State Loading
**Problem**: Used non-existent `prod.load_split_state()` and `prod.incidence_matrix()`.

**Fix**: 
- Implemented `load_split_and_prefix()` directly as specified in prompt
- Constructs `prod.DynamicState` directly with theta, B, coherence_acc, history from NPZ data
- Removed all references to non-existent helpers

### 3. Manifest Paths
**Problem**: Used `manifest["protocol"]["branch_order"]` and `manifest["seeds"]`.

**Fix**: 
- Changed to `manifest["protocol"]["branches"]` (correct path)
- Changed to `manifest["randomization"]["paired_seeds"]` (correct path)

### 4. Exact Equality Validation
**Problem**: Used tolerance-based `array_equal()` for mandatory initial matching.

**Fix**: 
- All initial matching checks now use `np.array_equal()` for exact equality
- Removed tolerance parameters from matching validation
- Added explicit checks for: theta, coherence_acc (both zero and equal), B (preserved vs split, zero vs zero matrix), history (length and content), RNG state

### 5. Recovery Thresholds
**Problem**: Used absolute thresholds (0.9) instead of relative (90% of continue reference).

**Fix**: 
- Similarity threshold: `0.9 * continue_result["Weighted_similarity_late"]`
- Density threshold: `0.9 * continue_result["D_B_final"]`
- Added fallback to absolute 0.9 only if reference is NaN

### 6. Recovery Helper Names
**Problem**: Used non-existent helpers like `recovery.held_above_for_window`, `recovery.sustained_above`, `recovery.auc_deficit`.

**Fix**: 
- Changed to actual validated helpers: `recovery.time_to_at_least`, `recovery.first_time_sustained_for_rest`, `recovery.first_time_held_for_duration`
- Removed `hasattr` fallbacks that hid errors

### 7. AUC Deficits Sign
**Problem**: Used `continue_similarity - similarity` directly, allowing negative deficits.

**Fix**: 
- Changed to `np.maximum(0.0, continue_similarity - similarity)`
- Applied same fix to density deficits

### 8. Binary Aggregation
**Problem**: Treated all 80 branch-block rows as independent.

**Fix**: 
- Now reports binary outcomes separately per reset_source (carrier_reset, full_reset)
- Each reset_source has its own counts and Wilson CIs for preserved and zero
- Discordant counts calculated per reset_source

### 9. Scalar Summary
**Problem**: Only included selected keys, missing production scalars.

**Fix**: 
- Now iterates over `prod.BRANCH_SCALAR_KEYS` to include ALL production scalars
- Adds derived recovery outcomes on top of production scalars

### 10. Metadata Labels
**Problem**: `production_intervention_label` was None for counterfactual branches.

**Fix**: 
- Added `production_intervention_label` to BRANCH_META with actual values passed to `simulate_future`
- Added `frozen_anchor_branch` field to distinguish anchor branches from counterfactuals

### 11. Report Language
**Problem**: Hardcoded "Preserving mature B has a measurable conditional effect".

**Fix**: 
- Changed to: "The experiment estimates the conditional effect of preserving mature B under matched randomized phase/history and reset EMA."
- Removed presupposition of measurable effect

### 12. Manifest Completeness
**Problem**: Missing hashes of frozen scalar CSV, recovery dependency, Python/NumPy versions.

**Fix**: 
- Added scalar CSV hash to manifest
- Added environment section with Python and NumPy versions
- Added recovery definitions section

### 13. Resume Flag
**Problem**: `--resume` flag exposed but unimplemented.

**Fix**: Removed `--resume` flag from CLI (was not in original spec)

### 14. Atomic NPZ Writes
**Problem**: NPZ output not atomic.

**Fix**: 
- Implemented `atomic_write_npz()` using temp file + replace pattern
- Applied to branch diagnostics NPZ

### 15. Scalar CSV Usage
**Problem**: Scalar CSV path accepted but never read.

**Fix**: 
- Now reads scalar CSV for hash verification
- Includes hash in manifest
- Still used for validation

### 16. Validation Stops Execution
**Problem**: Initial matching failures only printed warnings, didn't stop.

**Fix**: 
- Initial matching failures now raise `RuntimeError` immediately
- Anchor validation failures raise `RuntimeError` immediately
- Both include seed and block information for debugging

### 17. Failed Seeds Corrupt Output
**Problem**: Results committed before validation passes.

**Fix**: 
- Seed results only committed after ALL validation passes (initial matching + anchor validation)
- Uses local `seed_results` variable, only added to `all_results` at end of successful validation

### 18. Frozen Anchor Validation
**Problem**: Missing keys silently skipped, used tolerance-based equality.

**Fix**: 
- All keys in `prod.BRANCH_MATRIX_KEYS` are required
- Missing keys in frozen data or new results are fatal (set pass=False)
- Uses exact `np.array_equal()` for comparison
- Records max_diff for diagnostics separately

### 19. Array Hash Bug
**Problem**: `arr.shape.tobytes()` fails because shape is a tuple.

**Fix**: 
- Changed to `np.asarray(arr.shape, dtype=np.int64).tobytes()`
- Added contiguous array handling for consistent hashing

### 20. Self-Test Issues
**Problem**: 
- Used `prod.DynamicState()` without arguments
- Used wrong API in tests

**Fix**: 
- Constructs mock state properly: `prod.DynamicState(theta, B, coherence_acc, history)`
- Uses correct API calls in all self-tests
- Handles missing production module gracefully (skips API-dependent tests)

## Additional Improvements

1. **Atomic writes**: All file outputs (CSV, JSON, text, NPZ) now use atomic write patterns
2. **Error handling**: Better exception messages with seed/block context
3. **Type hints**: Added more comprehensive type hints
4. **Documentation**: Enhanced docstrings with parameter/return details
5. **Validation**: Added history_matches_theta check (every history entry equals theta)
6. **RNG validation**: Added RNG state equality check after intervention application
7. **Array hashes**: Added hashes for theta and B in audit output for debugging

## Design Preserved

The excellent experimental design from the original is fully preserved:
- Two reset blocks (carrier_reset and full_reset)
- Each block anchored to original branch-specific random draws
- Matched phase/history/EMA within each block
- Seed-level averaged contrast and interaction terms
- No new seed cohort

## API Compliance

The script now correctly calls the actual production APIs:
- `prod.DynamicState(theta, B, coherence_acc, history)` - constructor
- `prod.apply_intervention(state, branch, rng)` - mutates state, returns None
- `prod.simulate_future(split_state, prefix, branch, rng)` - returns dict
- `prod.BRANCHES` - tuple of branch names
- `prod.BRANCH_MATRIX_KEYS` - list of matrix keys for validation
- `prod.BRANCH_SCALAR_KEYS` - list of scalar keys
- `prod.PREFIX_KEYS` - list of prefix keys

## Files Modified

- `AIEF_1_4_matched_phase_memory_ablation.py` - Complete rewrite addressing all 20 issues

## Files Created

- `CORRECTIONS_SUMMARY.md` - This document

## Testing

- ✅ Compiles successfully (`python -m py_compile`)
- ✅ CLI help works (`--help`)
- ✅ Self-test passes (`--self-test`)
- ✅ Handles missing production module gracefully
