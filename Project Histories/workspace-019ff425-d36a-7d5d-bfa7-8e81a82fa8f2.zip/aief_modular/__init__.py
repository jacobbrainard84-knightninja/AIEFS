"""
AIEF Modular Experiment Driver Platform v1

This package provides a modular, reusable experiment orchestration layer
that builds on top of the validated aief_experiment_engine_v1.

Core Principles:
- Do not modify the numerical dynamics (engine v1 is authoritative)
- Full regeneration policy for model parameter changes
- Seed/graph is the inferential unit
- Mandatory baseline equivalence gate
- Atomic writes and durable artifacts
- Reproducible scientific run identity

Package Structure:
- spec.py: Core specification dataclasses
- registry.py: Study registry and lookup
- factors.py: Model factor specifications
- branches.py: Branch and intervention specifications  
- collectors.py: Output collection specifications
- validation.py: Validation gates and checks
- artifacts.py: Artifact management and atomic writes
- runner.py: Main execution engine
- catalog.py: Rebuildable catalog of runs
- studies/: Study-specific implementations
"""

__version__ = "1.0.0"
__study_id__ = "AIEF_1_4_S01"  # Default study for T_window sensitivity

# Re-export key types and functions for convenience
from aief_modular.spec import (
    ExperimentSpec,
    ModelConfig,
    ModelFactorSpec,
    FactorLevel,
    ProtocolSpec,
    SeedDesignSpec,
    BranchSpec,
    CollectorSpec,
    ValidatorSpec,
    BaselineGateSpec,
    ArtifactPolicySpec,
    canonical_json,
)
from aief_modular.registry import (
    StudyRegistry,
    register_study,
    get_study,
    list_studies,
    describe_study,
)

__all__ = [
    "__version__",
    "ExperimentSpec",
    "ModelConfig", 
    "ModelFactorSpec",
    "FactorLevel",
    "ProtocolSpec",
    "SeedDesignSpec",
    "BranchSpec",
    "CollectorSpec",
    "ValidatorSpec",
    "BaselineGateSpec",
    "ArtifactPolicySpec",
    "canonical_json",
    "StudyRegistry",
    "register_study",
    "get_study",
    "list_studies",
    "describe_study",
]
