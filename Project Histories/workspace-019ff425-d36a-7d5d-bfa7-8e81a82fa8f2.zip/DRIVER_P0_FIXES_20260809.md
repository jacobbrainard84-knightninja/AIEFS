# Driver P0 Fixes - 2026-08-09

## Overview
Fixed all P0 issues in `AIEF_1_4_Twindow_sensitivity.py` as identified in the code review.

## P0 Issues Fixed

### P0 #1: Dry-run incorrectly requires all frozen artifact paths

**Issue:** Frozen path validation happened before dry-run check, causing `--dry-run` to fail without frozen paths.

**Fix:** Moved dry-run block (lines 1044-1078) BEFORE frozen path validation (lines 1025-1042).

**Result:** `--dry-run` now validates configuration without requiring frozen paths.

---

### P0 #2: Manifest matrix schema contradicts actual validation

**Issue:** `BRANCH_MATRIX_KEYS` contained only 11 historical keys, but `validate_branch_outputs()` uses `engine.REQUIRED_BRANCH_MATRIX_KEYS` which includes 21 keys (frozen + extended).

**Fix:** 
- Separated `FROZEN_BRANCH_MATRIX_KEYS` (11 historical keys) from `REQUIRED_BRANCH_MATRIX_KEYS` (all engine keys)
- Set `REQUIRED_BRANCH_MATRIX_KEYS = tuple(engine.REQUIRED_BRANCH_MATRIX_KEYS)`
- Added import-time validation that frozen keys are subset of engine keys
- Updated `BRANCH_MATRIX_KEYS = REQUIRED_BRANCH_MATRIX_KEYS` to use full schema

**Result:** Manifest now truthfully records the validated output contract.

---

### P0 #3: Metadata validation does not validate `rho` or `T_window`

**Issue:** Empty `if` statements for `rho` and `T_window` (lines 289-295) did nothing (`pass`).

**Fix:** 
- Updated `validate_branch_outputs()` signature to accept `expected_rho` and `expected_T_window`
- Added actual validation:
  - `rho` must exist and match expected value
  - `T_window` must exist and match expected value
- Updated all call sites to pass expected values

**Result:** Metadata is now properly validated.

---

### P0 #4: `recovery_end_ema` is not validated

**Issue:** Metadata validation checked `window_steps`, `fixed_immediate_end`, `fixed_recovery_end` but not `recovery_end_ema`.

**Fix:** Added validation for `recovery_end_ema`:
```python
if "recovery_end_ema" in branch_result:
    expected_recovery_end = min(
        5 * int(round(branch_result["T_window"] / FROZEN_DT)),
        FROZEN_FUTURE_STEPS,
    )
    if branch_result["recovery_end_ema"] != expected_recovery_end:
        metadata_errors.append(f"recovery_end_ema={branch_result['recovery_end_ema']} != {expected_recovery_end}")
else:
    metadata_errors.append("missing recovery_end_ema")
```

**Result:** All horizon metadata is now validated.

---

### P0 #5: Prefix outputs are declared but never validated

**Issue:** `REQUIRED_PREFIX_KEYS` was defined but never validated in `simulate_seed_rho()`.

**Fix:**
- Added `validate_prefix_outputs()` function that:
  - Checks all required prefix keys are present
  - Validates array shapes match expected dimensions
- Called `validate_prefix_outputs(prefix)` immediately after `engine.simulate_prefix()`

**Result:** Prefix outputs are now validated before use.

---

## Files Modified
- `/home/user/AIEF_1_4_Twindow_sensitivity.py`

## Changes Summary

1. **Lines ~1017-1078:** Moved dry-run block before frozen path validation
2. **Lines ~133-148:** Separated FROZEN vs REQUIRED matrix key schemas
3. **Lines ~309-315:** Updated `validate_branch_outputs()` signature
4. **Lines ~320-355:** Added actual validation for rho, T_window, recovery_end_ema
5. **Lines ~266-288:** Added `validate_prefix_outputs()` function
6. **Lines ~646-647:** Added prefix validation call in `simulate_seed_rho`
7. **Lines ~664:** Added branch validation call in `simulate_seed_rho`
8. **Lines ~987:** Updated call in `extract_scalar_row`

## Validation Results

✅ Syntax check passes
✅ Module imports successfully
✅ Dry-run works without frozen paths
✅ Configuration validation passes

## Next Steps

All P0 issues for the driver are now fixed. The driver is ready for:
1. Baseline equivalence test execution
2. Full grid execution (after baseline passes)

---

*Document created: 2026-08-09*
*All driver P0 fixes implemented*
