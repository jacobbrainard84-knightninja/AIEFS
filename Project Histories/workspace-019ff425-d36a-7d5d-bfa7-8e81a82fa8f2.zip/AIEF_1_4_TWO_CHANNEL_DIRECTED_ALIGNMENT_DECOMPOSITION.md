# AIEF-1.4 Two-Channel Directed Alignment Decomposition

## Purpose

This script audits the **positivity and decay** of the directed magnitude differences for the K3 subgraph:

- **Fixed-left channel**: `D_L = R_25 - R_59` (Edge 25 vs Edge 59)
- **Right-mode channel**: `D_R = R_59 - R_29` (Edge 59 vs Edge 29)

Where edge magnitudes are defined as `R_e = |C_i - C_j|` for edge `e = (i, j)`.

## Mathematical Target

The resonance ordering `R_25,n > R_59,n > R_29,n` holds at every saved step. This script explains **both** the positivity and decay of the differences:

```
D_L,n = R_25,n - R_59,n  (fixed-left)
D_R,n = R_59,n - R_29,n  (right-mode)
```

## Audit Items (Per Channel, Per Orientation)

For each channel and orientation (forward/reverse), the script computes:

1. **Directed magnitude-difference signs**: `sign(D_n)`
2. **Forward/reverse reinforcement or cancellation**: Classification based on sign comparison between `D_n` and its driving term
3. **Exact residual**: `e_n = 2ΔA_n - ΔM_n` (computed as difference between edge residuals)
4. **Exact decomposition**: `e_n = T_1,n + T_2,n` (verified identity)
5. **Rates and signs**: Exponential decay rates for `T_1`, `T_2`, `e`, and `D`
6. **Cancellation index**: `|T_1 + T_2| / (|T_1| + |T_2|)` — measures alignment (0=cancellation, 1=reinforcement)
7. **Delayed phase-balance contributions**: Phase differences between edges (memory and source)
8. **T_1/T_2 → -1 mechanism**: Checks if the ratio converges to -1 (same mechanism as fixed-left pair)

## Key Definitions

### Edge Definitions (K3 Subgraph)
```
Edge 25: nodes (2, 7)
Edge 29: nodes (2, 11)  
Edge 59: nodes (7, 11)
```

### Channel Definitions
```
fixed_left:  Edge pair (25, 59) → D_L = R_25 - R_59
right_mode: Edge pair (59, 29) → D_R = R_59 - R_29
```

### Channel Quantities
For each edge `e = (i, j)` with node coherences `C_i`, `C_j` and phase factors `Z_i`, `Z_j`:

```
DeltaC    = C_i - C_j
DeltaZ    = Z_i - Z_j
E          = DeltaZ - DeltaC
DeltaM    = |C_i|² - |C_j|²
DeltaA    = Re(conj(C_i)·Z_i) - Re(conj(C_j)·Z_j)
e_edge     = 2·DeltaA - DeltaM  (= T_1 + T_2, exact identity)
T_1,edge   = 2·Re(conj(Cbar)·E)        where Cbar = 0.5·(C_i + C_j)
T_2,edge   = 2·Re(conj(DeltaC)·Zbar)   where Zbar = 0.5·(Z_i + Z_j)
```

For a **channel** (edge pair `(e1, e2)`):
```
e_channel   = e_e1 - e_e2
T_1,channel = T_1,e1 - T_1,e2
T_2,channel = T_2,e1 - T_2,e2
```

The exact identity `e_channel = T_1,channel + T_2,channel` is verified numerically.

## Reinforcement/Cancellation Classification

The recurrence for directed differences is:
```
D_{n+1} ≈ λ_n · D_n + driving_term_n
```

Classification:
- **Reinforcement**: `driving_term_n` has the **same sign** as `D_n` (amplifies the difference)
- **Cancellation**: `driving_term_n` has the **opposite sign** to `D_n` (reduces the difference)
- **Neutral**: `|driving_term_n|` or `|D_n|` is below numerical floor

The driving term is approximated as `ΔD_n = D_{n+1} - D_n`.

## Cancellation Index

```
cancellation_index = |T_1 + T_2| / (|T_1| + |T_2|)
```

- **0.0**: Perfect cancellation (`T_1 ≈ -T_2`)
- **1.0**: Perfect reinforcement (`T_1` and `T_2` have same sign and magnitude)
- **Intermediate**: Partial cancellation/reinforcement

## T_1/T_2 → -1 Mechanism

The ratio `T_1/T_2` is tracked over time. Convergence to `-1` indicates the **alignment cancellation mechanism** where `T_1 ≈ -T_2`, leading to small `e_n = T_1 + T_2`.

This mechanism was previously established for the fixed-left channel. The script verifies whether the right-mode channel exhibits the same behavior.

## Delayed Phase-Balance Contributions

For each edge, phase factors are unwrapped (with `discont=π` convention) and tracked:

```
memory_phase_e   = angle(C_i · conj(C_j))  (unwrapped)
source_phase_e    = angle(Z_i · conj(Z_j))   (unwrapped)
```

For a channel `(e1, e2)`, the phase balance is:
```
Δmemory_phase = memory_phase_e1 - memory_phase_e2
Δsource_phase  = source_phase_e1 - source_phase_e2
```

These measure the relative phase alignment between edges in the channel.

## Interpretation Constraints

1. **Directed magnitude differences** are computed as `R_i - R_j` for K3 edge pairs `(25,59)` and `(59,29)`.
2. **Reinforcement/cancellation classification** uses sign comparison between the difference and its change (driving term proxy).
3. **The exact identity** `e_n = T_1,n + T_2,n` is verified numerically for each channel.
4. **Cancellation index** near 0 indicates strong cancellation; near 1 indicates reinforcement.
5. **T_1/T_2 → -1 mechanism** is checked via ratio convergence to -1.
6. **Results are conditional** on seed `4619122171158768524` and fixed branch.
7. **Unwrapped phases** use `discont=π` convention.
8. **Edge magnitudes** are computed as `|C_i - C_j|` for edge `(i,j)`.

## Expected Outcomes

Based on the provided context:

1. **Fixed-left channel (D_L = R_25 - R_59)**:
   - `minΔx ≈ 5.42×10⁻⁹`, `minΔR ≈ 5.35×10⁻⁹` (well above numerical floor)
   - `G_* = 1.0130571021` (predicted), `(Δx/ΔR)_final = 1.0130571619` (relative discrepancy ≈ 5.9×10⁻⁸)
   - Should show **cancellation mechanism** with `T_1/T_2 → -1`

2. **Right-mode channel (D_R = R_59 - R_29)**:
   - `minΔx ≈ 2.82×10⁻¹⁴`, `minΔR ≈ 2.02×10⁻¹¹` (right channel at numerical floor)
   - `G_* = 0.0013990334` (predicted), `(Δx/ΔR)_final = 0.0014019490` (relative discrepancy ≈ 2.1×10⁻³)
   - Should verify if **same T_1/T_2 → -1 mechanism** applies
   - Phase-balance contributions may dominate due to near-floor magnitude

## Files Generated

| File | Description |
|------|-------------|
| `two_channel_trajectory.csv` | Per-step values: R_e, D_channel, e, T1, T2, phases |
| `two_channel_summary.csv` | Per-channel, per-interval summaries of all audit items |
| `two_channel_identity_checks.csv` | Verification of `e_n = T_1,n + T_2,n` identity |
| `two_channel_decomposition_report.txt` | Human-readable summary |
| `analysis_manifest.json` | Full provenance with SHA-256 hashes |

## Run Command

```bash
python aief_1_4_two_channel_directed_alignment_decomposition.py \
    --npz runs/5a9f093a2fe0/AIEF_1_4_5a9f093a2fe0_branch_diagnostics.npz \
    --manifest runs/5a9f093a2fe0/manifest.json
```

## Dependencies

- `AIEF_1_4_stationarity_perturbation_analysis_updated.py` (base module)
- `AIEF_1_4_component_controller_audit.py` (atomic write utilities)
- `AIEF_1_4_augmented_tangent_cocycle_analysis.py` (state advancement)

All dependencies are hashed in the manifest for reproducibility.
