# Verification Checklist - AIEF_1_4_matched_phase_memory_ablation.py

## Compilation and CLI
- [x] Script compiles without errors (`python -m py_compile`)
- [x] CLI help works (`--help`)
- [x] Self-test runs without production module (`--self-test`)
- [x] Self-test passes when production module available

## API Compliance (Issues 1, 2)
- [x] Uses `prod.apply_intervention(state, branch, rng)` - correct 3-arg signature
- [x] Does NOT use return value (mutates state in place)
- [x] Uses `prod.simulate_future(split_state, prefix, branch, rng)` - correct 4-arg signature
- [x] Uses `prod.DynamicState(theta, B, coherence_acc, history)` constructor
- [x] Implements `load_split_and_prefix()` directly (no non-existent helpers)
- [x] Removed all references to `prod.load_split_state`, `prod.incidence_matrix`

## Manifest Paths (Issue 3)
- [x] Uses `manifest["protocol"]["branches"]` (not `branch_order`)
- [x] Uses `manifest["randomization"]["paired_seeds"]` (not top-level `seeds`)
- [x] Validates both paths exist before proceeding

## Exact Equality Validation (Issue 5)
- [x] Uses `np.array_equal()` for all initial matching checks
- [x] Theta: exact equality between preserved and zero
- [x] Coherence_acc: exact equality and both zero
- [x] B: preserved equals split B, zero equals zero matrix
- [x] History: length equal, all entries equal, all entries match theta
- [x] RNG state: equality after intervention application
- [x] Array hashes: included for debugging

## Frozen Anchor Validation (Issue 8)
- [x] Uses `np.array_equal()` for exact comparison
- [x] Checks ALL keys in `prod.BRANCH_MATRIX_KEYS`
- [x] Missing keys in frozen data: fatal (pass=False)
- [x] Missing keys in new results: fatal (pass=False)
- [x] Records max_diff separately for diagnostics

## Recovery Calculations (Issues 9, 10, 11)
- [x] Uses relative thresholds: `0.9 * continue_reference`
- [x] Similarity threshold: `0.9 * continue_result["Weighted_similarity_late"]`
- [x] Density threshold: `0.9 * continue_result["D_B_final"]`
- [x] Uses validated recovery helpers: `time_to_at_least`, `first_time_sustained_for_rest`, `first_time_held_for_duration`
- [x] AUC deficits use `np.maximum(0.0, continue_value - value)`
- [x] Applied to both similarity and density deficits

## Statistical Issues (Issues 12, 13)
- [x] Binary aggregation per reset_source (carrier_reset, full_reset)
- [x] Each reset_source has separate counts and Wilson CIs
- [x] Discordant counts per reset_source
- [x] Restricted Mean Survival Time (RMST) for censored outcomes
- [x] Censored times replaced by horizon in RMST calculation

## Metadata and Outputs (Issues 14, 15, 16, 17, 19, 20)
- [x] `production_intervention_label` contains actual label passed to simulate_future
- [x] Added `frozen_anchor_branch` field to distinguish anchors
- [x] Report uses "estimates the conditional effect" (not "has measurable effect")
- [x] Manifest includes: scalar CSV hash, environment (Python/NumPy versions), recovery definitions
- [x] Atomic writes for all outputs (CSV, JSON, text, NPZ)
- [x] Scalar summary includes ALL production scalars from `prod.BRANCH_SCALAR_KEYS`
- [x] Array hash bug fixed: uses `np.asarray(arr.shape, dtype=np.int64).tobytes()`
- [x] Self-test constructs mock state properly
- [x] Self-test uses correct API calls

## Execution Control (Issues 6, 7, 18)
- [x] Initial matching failures raise `RuntimeError` immediately
- [x] Anchor validation failures raise `RuntimeError` immediately
- [x] Seed results only committed after ALL validation passes
- [x] Uses local `seed_results` variable, only adds to `all_results` at end
- [x] All keys in `prod.BRANCH_MATRIX_KEYS` required for anchor validation
- [x] `--resume` flag removed (was unimplemented)

## Design Preservation
- [x] Two reset blocks (carrier_reset and full_reset)
- [x] Each anchored to original branch-specific random draws
- [x] Matched phase/history/EMA within each block
- [x] Seed-level averaged contrast: Δ̄_s(Y) = 0.5 * [Δ_{s,carrier}(Y) + Δ_{s,full}(Y)]
- [x] Interaction: I_s(Y) = Δ_{s,carrier}(Y) - Δ_{s,full}(Y)
- [x] No new seed cohort (uses existing 40 paired seeds)

## All 20 Issues Addressed

1. ✅ Production API mismatch - corrected signatures
2. ✅ State loading - implemented directly
3. ✅ Manifest paths - corrected to protocol.branches and randomization.paired_seeds
4. ✅ Self-test - fixed mock state creation and API calls
5. ✅ Exact equality - uses np.array_equal throughout
6. ✅ Validation stops execution - raises RuntimeError on failure
7. ✅ Failed seeds don't corrupt output - commit only after validation
8. ✅ Frozen anchor validation - exact equality, all keys required
9. ✅ Recovery thresholds - relative (90% of continue reference)
10. ✅ Recovery helper names - uses actual validated helpers
11. ✅ AUC deficits - uses np.maximum(0, ...)
12. ✅ RMST calculations - proper restricted mean with horizon
13. ✅ Binary aggregation - per reset_source, not combined
14. ✅ Scalar summary - includes all production scalars
15. ✅ Metadata labels - correct production_intervention_label
16. ✅ Report language - doesn't presuppose measurable effect
17. ✅ Manifest completeness - includes all required hashes and metadata
18. ✅ Resume - removed unimplemented flag
19. ✅ Atomic NPZ writes - uses temp file + replace
20. ✅ Scalar CSV - read and hashed, used for validation

## Next Steps for User

To run the analysis:

```bash
# Smoke test on one seed
python AIEF_1_4_matched_phase_memory_ablation.py \
    --npz runs/5a9f093a2fe0/AIEF_1_4_5a9f093a2fe0_branch_diagnostics.npz \
    --manifest runs/5a9f093a2fe0/manifest.json \
    --scalar runs/5a9f093a2fe0/AIEF_1_4_5a9f093a2fe0_scalar_summary.csv \
    --max-seeds 1

# Full 40-seed analysis
python AIEF_1_4_matched_phase_memory_ablation.py \
    --npz runs/5a9f093a2fe0/AIEF_1_4_5a9f093a2fe0_branch_diagnostics.npz \
    --manifest runs/5a9f093a2fe0/manifest.json \
    --scalar runs/5a9f093a2fe0/AIEF_1_4_5a9f093a2fe0_scalar_summary.csv
```

Note: Requires `AIEF_1_4_memory_ablation_updated.py` to be available in Python path.
