# P0 Corrections Implementation - COMPLETE ✅

## Summary

All P0 corrections specified in the code review have been **successfully implemented** in `AIEF_1_4_Twindow_sensitivity_analysis_v3.py`. The file passes syntax validation and is ready for the next steps in the analysis workflow.

---

## ✅ Completed P0 Corrections

### Critical Recovery DID Fixes

1. **✅ Recovery DID excludes continue branch**
   - Changed loop from `branches` to `NON_CONTINUE_BRANCHES`
   - Removed unused bootstrap arguments from function signature
   - Updated docstring to clarify continue branch exclusion
   - Expected row count: **24,960** (down from 33,280)

2. **✅ Exact row count validation**
   - Added `EXPECTED_N_RECOVERY_DID` constant
   - Validates exactly 24,960 rows at end of `compute_recovery_did()`
   - Error message clearly indicates if continue branch was incorrectly included

3. **✅ Fail on missing cells**
   - Replaced all `continue` statements with explicit RuntimeError
   - Validates exactly one match for each cell (rho_branch, rho_continue, baseline_branch, baseline_continue)
   - Applied to both continuous outcomes and binary indicators

### Input Validation Fixes

4. **✅ Validate secondary normalized outcomes**
   - Extended validation to check `PRIMARY_OUTCOMES + SECONDARY_NORMALIZED_OUTCOMES`
   - Error messages updated to refer to "Outcome" generally

5. **✅ Require exactly one input CSV/NPZ**
   - Added checks: `if len(csv_files) != 1: sys.exit(1)`
   - Error messages include list of found files

6. **✅ Validate condition-status coverage**
   - Checks for duplicate (seed, rho) rows
   - Validates status values are only "success" or "failed"
   - Validates exact condition set matches manifest
   - Same validation applied to CSV cohort

7. **✅ Expose baseline certificate hash**
   - Added top-level `results["baseline_certificate_hash"]`
   - Added comprehensive certificate content validation:
     - Status must be "passed"
     - n_seeds must match EXPECTED_N_SEEDS
     - All seed_results must have status "passed"

### Schema and Metadata Fixes

8. **✅ Mark similarity targets as horizon-dependent**
   - Changed from "horizon_independent" to "horizon_dependent"
   - Density targets remain "horizon_independent" (correct)
   - Added clarifying comments

9. **✅ Add recovery-interaction files to stale protection**
   - Added `twindow_recovery_interactions.csv`
   - Added `twindow_recovery_interactions_summary.csv`

10. **✅ Require 40 seed rows in every recovery group**
    - Added validation after `compute_recovery_scaling()`
    - Added validation for recovery DID groups
    - Added `RESTRICTED_RECOVERY_FIELDS` constant for finite value checks

### Code Quality Fixes

11. **✅ Use `np.trapezoid` with fallback**
    - Uses `np.trapezoid` if available, else `np.trapz`
    - Enhanced docstring with NaN imputation convention

12. **✅ Remove unused bootstrap arguments**
    - Simplified `compute_recovery_did()` signature
    - Removed unused RNG creation

---

## Constants Added

```python
# Recovery DID expected count
EXPECTED_N_RECOVERY_DID = EXPECTED_N_SEEDS * (len(EXPECTED_RHO_VALUES) - 1) * len(NON_CONTINUE_BRANCHES) * 2 * 2 * 13

# Recovery groups
EXPECTED_N_RECOVERY_GROUPS = len(EXPECTED_RHO_VALUES) * len(EXPECTED_BRANCHES) * 2 * 2

# Recovery DID groups
EXPECTED_N_RECOVERY_DID_GROUPS = (len(EXPECTED_RHO_VALUES) - 1) * len(NON_CONTINUE_BRANCHES) * 2 * 2 * 13

# Censoring-aware fields
RESTRICTED_RECOVERY_FIELDS = (
    "restricted_first_crossing_time", "restricted_sustained_time", "restricted_held_time",
    "restricted_first_over_Twindow", "restricted_sustained_over_Twindow", "restricted_held_over_Twindow",
    "auc_deficit_vs_continue", "first_crossing_observed", "sustained_observed", "held_observed",
)
```

---

## Verification Results

### ✅ Syntax Check
```bash
python3 -m py_compile /home/user/AIEF_1_4_Twindow_sensitivity_analysis_v3.py
# Result: No errors
```

### ✅ AST Parsing
```python
import ast
ast.parse(code)  # Success
```

### ✅ Function Count
- 27 functions defined
- All expected functions present (compute_recovery_did, validate_run, etc.)

---

## Expected Behavior Changes

### Recovery DID
- **Before**: Included continue branch → 33,280 rows
- **After**: Excludes continue branch → 24,960 rows
- **Formula**: 40 seeds × 4 non-baseline rho × 3 non-continue branches × 2 systems × 2 metrics × 13 outcomes

### Error Handling
- **Before**: Silently skipped missing cells
- **After**: Raises RuntimeError with detailed context

### Validation
- **Before**: Only checked primary outcomes
- **After**: Checks primary + secondary outcomes, condition status, certificate contents

---

## Files Modified

- `/home/user/AIEF_1_4_Twindow_sensitivity_analysis_v3.py` - All P0 corrections implemented

---

## Next Steps (Per Original Workflow)

The file is now ready for:

1. ✅ **Syntax check** - Completed
2. ⏳ **Import test** - `python3 -c "import aief_experiment_engine_v1"`
3. ⏳ **Driver dry-run** - `AIEF_1_4_Twindow_sensitivity.py --dry-run`
4. ⏳ **Baseline-only run** - `AIEF_1_4_Twindow_sensitivity.py --baseline-only`
5. ⏳ **Inspect certificate** - Verify baseline equivalence
6. ⏳ **Launch grid** - Only after exact baseline passage
7. ⏳ **Run analysis** - With fixed bootstrap seed

---

## Key Mathematical Correctness

### Recovery DID Formula (Corrected)
```
I_{s,ρ,b} = [R_{s,ρ,b} - R_{s,ρ,continue}] - [R_{s,1,b} - R_{s,1,continue}]
```
where:
- b ∈ {reset_ema, reset_B, future_shuffle} (NON_CONTINUE_BRANCHES only)
- ρ ∈ {0.5, 0.75, 1.5, 2.0} (non-baseline rho only)
- R = recovery metric value

### Horizon Dependence
- **Density**: horizon_independent (0.9 × D_B_final_continue for both systems)
- **Similarity**: horizon_dependent (different targets for fixed_physical vs normalized_EMA)

---

## Document Information

- **Date**: 2026-08-09
- **Status**: ✅ ALL P0 CORRECTIONS COMPLETE
- **File**: AIEF_1_4_Twindow_sensitivity_analysis_v3.py
- **Verified by**: Syntax check, AST parsing, manual review

---

## Appendix: P0 Correction Checklist

| # | Description | Status | Location |
|---|-------------|--------|----------|
| 1 | Recovery DID excludes continue branch | ✅ | Line 1386 |
| 2 | Require exactly 24,960 rows | ✅ | Line 1537-1541 |
| 3 | Fail on missing cells | ✅ | Lines 1425-1435, 1500-1510 |
| 4 | Validate secondary outcomes | ✅ | Lines 965-985 |
| 5 | Mark similarity as horizon-dependent | ✅ | Line 648 |
| 6 | Add recovery-interaction to stale protection | ✅ | Lines 1777-1779 |
| 7 | Require 40 seeds per recovery group | ✅ | Lines 2575-2585, 2618-2628 |
| 8 | Expose baseline certificate hash | ✅ | Lines 1050-1055 |
| 9 | Require exactly one CSV/NPZ | ✅ | Lines 2530-2538 |
| 10 | Validate condition-status coverage | ✅ | Lines 720-770, 940-970 |
| 11 | Remove unused bootstrap args | ✅ | Line 1326, 2588 |
| 12 | Use np.trapezoid with fallback | ✅ | Lines 355-358 |

**All 12 P0 corrections: COMPLETE ✅**
