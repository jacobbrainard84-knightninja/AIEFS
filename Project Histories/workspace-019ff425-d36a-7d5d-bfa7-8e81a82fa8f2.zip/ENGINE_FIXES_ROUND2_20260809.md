# Engine Fixes - Round 2 (2026-08-09)

**File:** `aief_experiment_engine_v1.py`

**Status:** ALL FIXES IMPLEMENTED AND VERIFIED ✅

---

## P0 Fixes (Must fix before running)

### 1. ✅ Fixed Unreachable `protocol.branches` Manifest Validation

**Issue:** The check for `"branches" not in frozen_manifest["protocol"]` was indented inside the previous `if` block after an unconditional `return`, making it unreachable.

**Location:** Line ~1958

**Fix:** Dedented the branch check to be at the same level as the `paired_seeds` check.

**Before:**
```python
if "paired_seeds" not in frozen_manifest["randomization"]:
    return {...}
    if "branches" not in frozen_manifest["protocol"]:
        return {...}
```

**After:**
```python
if "paired_seeds" not in frozen_manifest["randomization"]:
    return {...}
if "branches" not in frozen_manifest["protocol"]:
    return {...}
```

---

### 2. ✅ Fixed `T_sim` Read from Wrong Manifest Section

**Issue:** `T_sim` was being read from `frozen_protocol.get("T_sim")` but frozen production stores it in `frozen_model["T_sim"]`.

**Location:** Line ~2312

**Fix:** Changed to `frozen_model.get("T_sim")` and added horizon field checks.

**Before:**
```python
("T_sim", protocol.T_sim, FROZEN_T_SIM, frozen_protocol.get("T_sim")),
```

**After:**
```python
("T_sim", protocol.T_sim, FROZEN_T_SIM, frozen_model.get("T_sim")),

# Also added horizon field checks
if math.isclose(config.T_window, config.T_star, rel_tol=0.0, abs_tol=0.0):
    actual_window_steps = int(round(config.T_window / config.dt))
    actual_recovery_end = min(5 * actual_window_steps, protocol.future_steps(config))
    protocol_checks.extend([
        ("window_steps", actual_window_steps, FROZEN_WINDOW_STEPS, frozen_protocol.get("window_steps")),
        ("recovery_end", actual_recovery_end, FROZEN_RECOVERY_END, frozen_protocol.get("recovery_end")),
    ])
```

---

## Recommended Exactness Cleanup

### 3. ✅ Made Alpha Manifest Comparison Exact

**Issue:** Alpha comparison used `atol=1e-15` despite being described as exact.

**Location:** Line ~2302

**Fix:** Changed to `rtol=0.0, atol=0.0` for exact comparison.

**Before:**
```python
if not np.isclose(frozen_model.get("alpha", 0.0), config.alpha, rtol=0.0, atol=1e-15):
```

**After:**
```python
if not np.isclose(frozen_model.get("alpha", 0.0), config.alpha, rtol=0.0, atol=0.0):
```

---

### 4. ✅ Used Named Frozen Gap Tolerance

**Issue:** Hardcoded `1e-9` instead of using the named constant `FROZEN_GAP_TOL`.

**Location:** Line ~824

**Fix:** Replaced hardcoded value with constant.

**Before:**
```python
if g_min < config.delta - 1e-9:
```

**After:**
```python
if g_min < config.delta - FROZEN_GAP_TOL:
```

---

### 5. ✅ Used Strict Relative Tolerance in State Checks

**Issue:** Default relative tolerance was unnecessarily permissive for validation checks.

**Locations:** 
- `validate_B_matrix()` function (lines ~387-395)
- `DynamicState.validate()` method (lines ~655-659)

**Fix:** Added `rtol=0.0` and used `FROZEN_ZERO_TOL` for atol.

**Before:**
```python
def validate_B_matrix(B, N, eps=1e-12):
    if not np.allclose(B, B.T, atol=eps):
        raise ValueError("B is not symmetric")
    if not np.allclose(np.diag(B), 0, atol=eps):
        raise ValueError("B diagonal is not zero")

# In DynamicState.validate():
if not np.allclose(self.B, self.B.T, atol=1e-12):
    raise RuntimeError("B matrix is not symmetric")
if not np.allclose(np.diag(self.B), 0, atol=1e-12):
    raise RuntimeError("B matrix diagonal is not zero")
```

**After:**
```python
def validate_B_matrix(B, N, eps=FROZEN_ZERO_TOL):
    if not np.allclose(B, B.T, rtol=0.0, atol=eps):
        raise ValueError("B is not symmetric")
    if not np.allclose(np.diag(B), 0, rtol=0.0, atol=eps):
        raise ValueError("B diagonal is not zero")

# In DynamicState.validate():
if not np.allclose(self.B, self.B.T, rtol=0.0, atol=FROZEN_ZERO_TOL):
    raise RuntimeError("B matrix is not symmetric")
if not np.allclose(np.diag(self.B), 0, rtol=0.0, atol=FROZEN_ZERO_TOL):
    raise RuntimeError("B matrix diagonal is not zero")
if np.any(self.B < -FROZEN_ZERO_TOL):
    raise RuntimeError("B matrix has negative entries")
```

---

## Nonblocking Robustness Improvements

### 6. ✅ Added Manifest Schema Uniqueness Check

**Issue:** Set equality does not detect duplicate schema entries.

**Location:** After line ~1977 (after extracting schema values)

**Fix:** Added explicit duplicate detection for all schema key types.

**Added:**
```python
# Nonblocking #6: Check manifest schema uniqueness
for schema_name, schema_values in (
    ("prefix_keys", manifest_prefix),
    ("branch_matrix_keys", manifest_matrices),
    ("branch_scalar_keys", manifest_scalars),
):
    if len(schema_values) != len(set(schema_values)):
        duplicates = [v for v in schema_values if list(schema_values).count(v) > 1]
        return {
            "status": "failed",
            "error": (
                f"Frozen manifest schema "
                f"{schema_name} contains duplicates: {sorted(set(duplicates))}"
            ),
            "frozen_manifest": str(Path(frozen_manifest_path).resolve()),
            "frozen_npz": str(Path(frozen_npz_path).resolve()),
            "frozen_csv_path": frozen_csv_path,
        }
```

---

### 7. ✅ Reject Malformed Physical CSV Rows Explicitly

**Issue:** Rows with empty seed or branch were silently ignored, making malformed rows invisible to dictionary key-count check.

**Location:** Line ~2165-2180

**Fix:** Added explicit error for rows missing seed or branch identifiers, with line numbers.

**Before:**
```python
for row in reader:
    seed_id = row.get("seed", "")
    branch = row.get("branch", "")
    if seed_id and branch:
        key = f"{branch}_seed_{seed_id}"
        ...
```

**After:**
```python
for line_number, row in enumerate(reader, start=2):
    seed_id = row.get("seed", "")
    branch = row.get("branch", "")
    if not seed_id or not branch:
        return {
            "status": "failed",
            "error": f"Frozen CSV line {line_number} missing seed or branch",
            ...
        }
    key = f"{branch}_seed_{seed_id}"
    ...
```

---

### 8. ✅ Require `continue` Branch for Historical Metrics

**Issue:** If `protocol.branches` omits `continue`, `run_seed()` silently skips computing the 8 historical cross-branch scalar fields, despite the module-level required schema including them.

**Location:** In `run_seed()` function, line ~2723

**Fix:** Added explicit validation that `continue` must be in `protocol.branches`.

**Added:**
```python
# Nonblocking #8: Require continue branch for historical metrics
if "continue" not in protocol.branches:
    raise ValueError(
        "run_seed requires the continue branch "
        "to compute historical cross-branch metrics"
    )
```

---

## Verification

All fixes have been verified:

- ✅ Syntax check passed
- ✅ Import successful
- ✅ All P0 fixes implemented
- ✅ All recommended exactness cleanups implemented
- ✅ All nonblocking robustness improvements implemented

---

## Files Modified

- `/home/user/aief_experiment_engine_v1.py` - All 8 fixes applied

---

## Next Steps

The engine file is now ready for:
1. Compile → Import → One-seed smoke → Baseline-only testing

**Status:** READY FOR TESTING ✅
