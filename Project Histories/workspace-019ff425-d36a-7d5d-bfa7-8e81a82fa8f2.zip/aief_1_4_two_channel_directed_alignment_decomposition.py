#!/usr/bin/env python3
"""Two-channel directed alignment decomposition for K3 resonance ordering.

This script audits the positivity and decay of the directed magnitude differences:

    D_L = R_25 - R_59  (fixed-left channel)
    D_R = R_59 - R_29  (right-mode channel)

For each channel and orientation, it computes:
1. Directed magnitude-difference signs
2. Forward/reverse reinforcement or cancellation classification
3. Exact residual e_n = 2*DeltaA_n - DeltaM_n
4. Exact decomposition e_n = T_1,n + T_2,n (verified identity)
5. Decay rates and signs of T_1, T_2, e
6. Cancellation index |T_1 + T_2| / (|T_1| + |T_2|)
7. Delayed phase-balance contributions
8. T_1/T_2 -> -1 mechanism verification

Edge definitions (K3 subgraph):
    Edge 25: nodes (2, 7)
    Edge 29: nodes (2, 11)
    Edge 59: nodes (7, 11)

Resonance ordering target: R_25,n > R_59,n > R_29,n at every saved step.

Unwrapping convention: np.unwrap with discont=pi (radians).

Reference: AIEF_1_4_FORWARD_PLAN.md, Section 3 (geometric/dual invariant-subspace checks)
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

# Local imports - SHA-256 hashes recorded in manifest
import AIEF_1_4_stationarity_perturbation_analysis_updated as base
import AIEF_1_4_component_controller_audit as component_audit
import AIEF_1_4_augmented_tangent_cocycle_analysis as augmented

# === Constants ===
DEFAULT_RUN_HASH = "5a9f093a2fe0"
DEFAULT_NPZ = (
    f"runs/{DEFAULT_RUN_HASH}/AIEF_1_4_{DEFAULT_RUN_HASH}_branch_diagnostics.npz"
)
DEFAULT_MANIFEST = f"runs/{DEFAULT_RUN_HASH}/manifest.json"
DEFAULT_OUTPUT_DIR = "aief_1_4_two_channel_alignment"
DEFAULT_SEED = "4619122171158768524"
DEFAULT_DT = 0.01
DEFAULT_SCALE_EPSILON = 1e-12
DEFAULT_INTERVALS = "0,50,100,150,200,250,300,320"
DEFAULT_SIGNAL_FLOOR = 1e-14
ZERO_TOL = 1e-300
UNWRAP_DISCONT = np.pi

# === K3 Configuration ===
K3_NODES = (2, 7, 11)

# Edge index -> (node_i, node_j) for undirected edges
K3_EDGES = {
    25: (2, 7),
    29: (2, 11),
    59: (7, 11),
}

# Channel definitions: each channel tracks a directed edge-pair difference
CHANNELS = {
    "fixed_left": {
        "description": "Edge 25 vs Edge 59 (R_25 - R_59)",
        "edge_pair": (25, 59),
        "forward_diff": lambda R: R[25] - R[59],
        "reverse_diff": lambda R: R[59] - R[25],
    },
    "right_mode": {
        "description": "Edge 59 vs Edge 29 (R_59 - R_29)",
        "edge_pair": (59, 29),
        "forward_diff": lambda R: R[59] - R[29],
        "reverse_diff": lambda R: R[29] - R[59],
    },
}

ORIENTATIONS = ["forward", "reverse"]


# =============================================================================
# Utility Functions
# =============================================================================

def file_sha256(path: str | os.PathLike[str]) -> str:
    """Compute SHA-256 hash of a file."""
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def compute_module_sha256(module: Any) -> str:
    """Compute SHA-256 hash of a module's source file."""
    path = Path(module.__file__).resolve()
    return file_sha256(path)


def parse_nonnegative_float_list(value: str) -> list[float]:
    """Parse comma-separated nonnegative floats."""
    try:
        values = [float(x.strip()) for x in value.split(",") if x.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("expected comma-separated floats") from exc
    if not values or any(v < 0.0 for v in values):
        raise argparse.ArgumentTypeError("values must be nonnegative")
    result = sorted(set(values))
    if not result:
        raise argparse.ArgumentTypeError("at least one unique nonnegative value required")
    return result


def fit_log_rate(times: np.ndarray, values: np.ndarray, floor: float) -> dict[str, float]:
    """Fit exponential decay rate from log magnitudes."""
    magnitudes = np.abs(np.asarray(values, dtype=float))
    valid = np.isfinite(magnitudes) & (magnitudes > floor)
    if np.sum(valid) < 3:
        return {"rate": np.nan, "R_squared": np.nan, "count": int(np.sum(valid))}
    x = np.asarray(times, dtype=float)[valid]
    y = np.log(magnitudes[valid])
    slope, intercept = np.polyfit(x, y, 1)
    prediction = slope * x + intercept
    residual = float(np.sum((y - prediction) ** 2))
    total = float(np.sum((y - np.mean(y)) ** 2))
    return {
        "rate": float(-slope),
        "R_squared": float(1.0 - residual / total) if total > 0.0 else np.nan,
        "count": int(len(x)),
    }


def channel_quantities(
    C_a: complex,
    C_b: complex,
    Z_a: complex,
    Z_b: complex,
) -> dict[str, Any]:
    """Compute channel quantities for a directed node pair (a, b).
    
    Returns:
        DeltaC: C_a - C_b
        DeltaZ: Z_a - Z_b
        E: DeltaZ - DeltaC
        DeltaM: |C_a|^2 - |C_b|^2
        DeltaA: Re(conj(C_a)*Z_a) - Re(conj(C_b)*Z_b)
        T1: 2 * Re(conj(Cbar) * E) where Cbar = 0.5*(C_a + C_b)
        T2: 2 * Re(conj(DeltaC) * Zbar) where Zbar = 0.5*(Z_a + Z_b)
        alignment_residual: 2*DeltaA - DeltaM (= T1 + T2, exact identity)
        radius: |C_a - C_b|
        memory_phase_raw: angle(C_a * conj(C_b))
        source_phase_raw: angle(Z_a * conj(Z_b))
    """
    Cbar = 0.5 * (C_a + C_b)
    Zbar = 0.5 * (Z_a + Z_b)
    DeltaC = C_a - C_b
    DeltaZ = Z_a - Z_b
    E = DeltaZ - DeltaC
    
    DeltaM = float(abs(C_a) ** 2 - abs(C_b) ** 2)
    DeltaA = float(
        np.real(np.conj(C_a) * Z_a) - np.real(np.conj(C_b) * Z_b)
    )
    
    T1 = float(2.0 * np.real(np.conj(Cbar) * E))
    T2 = float(2.0 * np.real(np.conj(DeltaC) * Zbar))
    
    return {
        "DeltaC": DeltaC,
        "DeltaZ": DeltaZ,
        "E": E,
        "DeltaM": DeltaM,
        "DeltaA": DeltaA,
        "T1": T1,
        "T2": T2,
        "alignment_residual": 2.0 * DeltaA - DeltaM,
        "radius": float(abs(DeltaC)),
        "memory_phase_raw": float(np.angle(C_a * np.conj(C_b))),
        "source_phase_raw": float(np.angle(Z_a * np.conj(Z_b))),
    }


def compute_edge_radius(coherence: np.ndarray, i: int, j: int) -> float:
    """Compute edge radius (magnitude) as |C_i - C_j|."""
    return float(abs(coherence[i] - coherence[j]))


def classify_reinforcement(
    D_n: float,
    D_next: float,
    tol: float = 1e-12,
) -> str:
    """Classify forward/reverse reinforcement or cancellation.
    
    Uses the sign of the change (D_next - D_n) as a proxy for the driving term.
    
    - Reinforcement: change has same sign as D_n (difference is growing)
    - Cancellation: change has opposite sign to D_n (difference is shrinking)
    - Neutral: either D_n or change is near zero
    """
    change = D_next - D_n
    
    if abs(D_n) < tol or abs(change) < tol:
        return "neutral"
    
    if D_n * change > 0:
        return "reinforcement"
    elif D_n * change < 0:
        return "cancellation"
    return "ambiguous"


# =============================================================================
# Validation Functions
# =============================================================================

def validate_manifest_structure(manifest: dict[str, Any]) -> None:
    """Validate manifest has required keys."""
    required_model_keys = {"dt", "T_window", "a", "delta", "q", "N"}
    if "model" not in manifest:
        raise ValueError("manifest missing 'model' key")
    if not required_model_keys.issubset(manifest["model"].keys()):
        missing = required_model_keys - set(manifest["model"].keys())
        raise ValueError(f"model missing keys: {missing}")
    if "protocol" not in manifest or "future_steps" not in manifest.get("protocol", {}):
        raise ValueError("manifest missing protocol.future_steps")


def validate_npz_keys(data: Any, seed: str) -> None:
    """Validate NPZ file has required keys."""
    required_keys = {base.branch_key("continue", seed, "B_final")}
    available = set(data.files)
    missing = required_keys - available
    if missing:
        raise ValueError(f"NPZ missing keys: {missing}")


def validate_state(state: Any, N: int) -> None:
    """Validate state object has required attributes."""
    if not hasattr(state, "coherence_acc"):
        raise ValueError("state missing coherence_acc")
    if not hasattr(state, "B"):
        raise ValueError("state missing B")
    if len(state.coherence_acc) != N:
        raise ValueError(
            f"state.coherence_acc length {len(state.coherence_acc)} != N={N}"
        )
    if state.B.shape != (N, N):
        raise ValueError(f"state.B shape {state.B.shape} != (N, N)")


def validate_intermediate(intermediate: dict[str, Any], N: int) -> None:
    """Validate intermediate dict has required keys."""
    if "phase_factor" not in intermediate:
        raise ValueError("intermediate missing phase_factor")
    if len(intermediate["phase_factor"]) != N:
        raise ValueError(
            f"phase_factor length {len(intermediate['phase_factor'])} != N={N}"
        )


def test_alignment_identity(
    e_values: np.ndarray,
    T1_values: np.ndarray,
    T2_values: np.ndarray,
    tol: float = 1e-14,
) -> dict[str, float]:
    """Test the exact identity e_n = T_1,n + T_2,n."""
    e = np.asarray(e_values, dtype=float)
    T1 = np.asarray(T1_values, dtype=float)
    T2 = np.asarray(T2_values, dtype=float)
    
    if len(e) != len(T1) or len(e) != len(T2):
        raise ValueError(f"Length mismatch: e={len(e)}, T1={len(T1)}, T2={len(T2)}")
    
    errors = np.abs(e - (T1 + T2))
    return {
        "max_abs_error": float(np.max(errors)),
        "median_abs_error": float(np.median(errors)),
        "identity_passes": float(np.max(errors)) < tol,
    }


# =============================================================================
# Report Generation
# =============================================================================

def make_report(
    channel_summary: pd.DataFrame,
    identity_checks: pd.DataFrame,
    trajectory: pd.DataFrame,
    *,
    alpha: float,
    dt: float,
    final_replay_exact: bool,
) -> str:
    """Generate human-readable report."""
    lines = [
        "=" * 70,
        "AIEF-1.4 Two-Channel Directed Alignment Decomposition",
        "=" * 70,
        "",
        f"alpha_EMA: {alpha:.12g}",
        f"dt: {dt:.12g}",
        f"Final replay exact: {final_replay_exact}",
        "",
        "-" * 70,
        "Resonance Ordering Target: R_25 > R_59 > R_29 at every step",
        "-" * 70,
        "",
    ]

    # Final values from trajectory
    final_row = trajectory.iloc[-1]
    lines.extend([
        "Final Edge Magnitudes:",
        f"  R_25 = {final_row['R_25']:.12g}",
        f"  R_59 = {final_row['R_59']:.12g}",
        f"  R_29 = {final_row['R_29']:.12g}",
        "",
        "Final Directed Differences:",
        f"  D_L (fixed-left, forward)  = R_25 - R_59 = {final_row['D_fixed_left_forward']:.12g}",
        f"  D_L (fixed-left, reverse)  = R_59 - R_25 = {final_row['D_fixed_left_reverse']:.12g}",
        f"  D_R (right-mode, forward)  = R_59 - R_29 = {final_row['D_right_mode_forward']:.12g}",
        f"  D_R (right-mode, reverse)  = R_29 - R_59 = {final_row['D_right_mode_reverse']:.12g}",
        "",
    ])

    # Channel summaries
    lines.extend([
        "-" * 70,
        "Channel Audit Summary (Full Trajectory)",
        "-" * 70,
        "",
    ])

    for (ch, orient), group in channel_summary.groupby(["channel", "orientation"]):
        row = group.iloc[0]  # Full trajectory row
        lines.extend([
            f"[{ch}:{orient}]",
            f"  Directed diff sign: {row['directed_diff_sign']:+d}",
            f"  Dominant mechanism: {row['reinforcement_class']}",
            f"  Min |D|: {row['min_abs_D']:.2e}, Max |D|: {row['max_abs_D']:.2e}",
            f"  e decay rate: {row['e_rate']:.6g} (R²={row['e_R_squared']:.6g})",
            f"  T1 decay rate: {row['T1_rate']:.6g} (R²={row['T1_R_squared']:.6g})",
            f"  T2 decay rate: {row['T2_rate']:.6g} (R²={row['T2_R_squared']:.6g})",
            f"  Cancellation index (final): {row['cancellation_index_final']:.6g}",
            f"  T1/T2 ratio (final): {row['T1_T2_ratio_final']:.6g}",
            f"  Identity error (max): {row['max_identity_error']:.2e}",
            "",
        ])

    # T1/T2 -> -1 check
    lines.extend([
        "-" * 70,
        "T1/T2 -> -1 Mechanism Check",
        "-" * 70,
        "",
    ])

    for (ch, orient), group in channel_summary.groupby(["channel", "orientation"]):
        row = group.iloc[0]
        ratio = row['T1_T2_ratio_final']
        lines.append(
            f"  [{ch}:{orient}] T1/T2 final = {ratio:.6g} "
            f"{'→ -1 (CONVERGED)' if abs(ratio + 1.0) < 0.01 else '(not converged)'}"
        )

    # Identity checks
    lines.extend([
        "",
        "-" * 70,
        "Exact Identity Verification: e_n = T_1,n + T_2,n",
        "-" * 70,
        "",
    ])

    for _, row in identity_checks.iterrows():
        status = "PASS" if row["passes"] else "FAIL"
        lines.append(
            f"  {row['channel']}:{row['orientation']}: "
            f"max_err={row['maximum_absolute_error']:.2e}, "
            f"med_err={row['median_absolute_error']:.2e} [{status}]"
        )

    lines.extend([
        "",
        "-" * 70,
        "Interpretation Constraints",
        "-" * 70,
        "* Directed magnitude differences: R_i - R_j for K3 edge pairs (25,59) and (59,29)",
        "* Edge magnitudes: R_e = |C_i - C_j| for edge e = (i,j)",
        "* Reinforcement/cancellation: based on sign(D_n) vs sign(ΔD_n)",
        "* Cancellation index: |T1+T2|/(|T1|+|T2|); 0=cancellation, 1=reinforcement",
        "* T1/T2 -> -1: checked via final ratio; convergence if |ratio+1| < 0.01",
        "* Exact identity e_n = T1_n + T2_n verified numerically",
        "* Results conditional on seed 4619122171158768524 and fixed branch",
        "* Unwrapped phases: discont=pi convention",
        "",
    ])

    return "\n".join(lines)


# =============================================================================
# Argument Parsing
# =============================================================================

def parse_arguments() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--npz", default=DEFAULT_NPZ)
    parser.add_argument("--manifest", default=DEFAULT_MANIFEST)
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--seed", default=DEFAULT_SEED)
    parser.add_argument("--dt", type=float, default=DEFAULT_DT)
    parser.add_argument("--scale-epsilon", type=float, default=DEFAULT_SCALE_EPSILON)
    parser.add_argument(
        "--intervals",
        type=parse_nonnegative_float_list,
        default=parse_nonnegative_float_list(DEFAULT_INTERVALS),
    )
    parser.add_argument("--signal-floor", type=float, default=DEFAULT_SIGNAL_FLOOR)
    return parser.parse_args()


# =============================================================================
# Main Analysis Routine
# =============================================================================

def main() -> None:
    """Main analysis routine."""
    args = parse_arguments()

    # --- Validate inputs exist ---
    for path in (args.npz, args.manifest):
        if not os.path.isfile(path):
            raise FileNotFoundError(path)

    # --- Validate numeric arguments ---
    if min(args.dt, args.scale_epsilon, args.signal_floor) <= 0.0:
        raise ValueError("dt and tolerances must be positive")

    if args.scale_epsilon != 1e-12:
        raise ValueError("implemented actual_step uses fixed scale epsilon=1e-12")

    # --- Create output directory ---
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # --- Load and validate manifest ---
    with open(args.manifest, "r", encoding="utf-8") as handle:
        manifest = json.load(handle)

    validate_manifest_structure(manifest)

    model = manifest["model"]
    dt = float(model["dt"])
    if abs(dt - args.dt) > 1e-15:
        raise ValueError("command dt does not match manifest dt")

    alpha = math.exp(-dt / float(model["T_window"]))
    capacity = (float(model["a"]) - float(model["delta"])) / float(model["q"])
    capacities = np.full(int(model["N"]), capacity)
    N = int(model["N"])

    # --- Build incidence matrix ---
    A, edges = base.incidence_matrix(N)

    future_steps = int(manifest["protocol"]["future_steps"])
    if future_steps <= 0:
        raise ValueError(f"future_steps must be positive, got {future_steps}")

    # --- Load and validate NPZ data ---
    with np.load(args.npz, allow_pickle=False) as data:
        validate_npz_keys(data, args.seed)
        state = base.load_split_state(data, args.seed)
        expected_final = np.asarray(
            data[base.branch_key("continue", args.seed, "B_final")], dtype=float
        ).copy()

    validate_state(state, N)

    # --- Validate K3 node indices ---
    if max(K3_NODES) >= N:
        raise ValueError(f"K3 node index >= N={N}: {K3_NODES}")

    # --- Collect trajectory data ---
    # For each step, store:
    #   - Edge radii R_25, R_59, R_29
    #   - Channel quantities for each K3 edge
    #   - Directed differences for each channel
    
    step_count = future_steps + 1
    
    # Initialize storage
    trajectory_rows = []
    
    # Per-edge storage for quantities
    edge_data = {
        e_idx: {
            "R": np.zeros(step_count),
            "e": np.zeros(step_count),
            "T1": np.zeros(step_count),
            "T2": np.zeros(step_count),
            "DeltaM": np.zeros(step_count),
            "DeltaA": np.zeros(step_count),
            "memory_phase": np.zeros(step_count),
            "source_phase": np.zeros(step_count),
        }
        for e_idx in K3_EDGES
    }

    # --- Simulate forward and collect data ---
    for step in range(step_count):
        intermediate = augmented.base_intermediates(
            state,
            model,
            capacities,
            A,
            edges,
            args.scale_epsilon,
        )
        validate_intermediate(intermediate, N)

        coherence = state.coherence_acc
        phase_factor = intermediate["phase_factor"]

        # Compute edge radii: R_e = |C_i - C_j|
        for e_idx, (i, j) in K3_EDGES.items():
            edge_data[e_idx]["R"][step] = compute_edge_radius(coherence, i, j)

        # Compute channel quantities for each edge
        for e_idx, (i, j) in K3_EDGES.items():
            q = channel_quantities(
                coherence[i],
                coherence[j],
                phase_factor[i],
                phase_factor[j],
            )
            edge_data[e_idx]["e"][step] = q["alignment_residual"]
            edge_data[e_idx]["T1"][step] = q["T1"]
            edge_data[e_idx]["T2"][step] = q["T2"]
            edge_data[e_idx]["DeltaM"][step] = q["DeltaM"]
            edge_data[e_idx]["DeltaA"][step] = q["DeltaA"]
            
            # Handle phase unwrapping
            raw_mem = q["memory_phase_raw"]
            raw_src = q["source_phase_raw"]
            
            if step == 0:
                edge_data[e_idx]["memory_phase"][step] = raw_mem
                edge_data[e_idx]["source_phase"][step] = raw_src
            else:
                prev_mem = edge_data[e_idx]["memory_phase"][step - 1]
                prev_src = edge_data[e_idx]["source_phase"][step - 1]
                
                # Unwrap with explicit convention
                mem_phases = np.array([prev_mem, raw_mem])
                src_phases = np.array([prev_src, raw_src])
                
                edge_data[e_idx]["memory_phase"][step] = float(
                    np.unwrap(mem_phases, discont=UNWRAP_DISCONT)[1]
                )
                edge_data[e_idx]["source_phase"][step] = float(
                    np.unwrap(src_phases, discont=UNWRAP_DISCONT)[1]
                )

        if step < future_steps:
            augmented.advance_base_state(state, intermediate)

    # --- Verify final state ---
    final_replay_exact = bool(np.array_equal(state.B, expected_final))

    # --- Build trajectory DataFrame ---
    for step in range(step_count):
        row = {"step": step, "time": step * dt}
        
        # Add R values
        for e_idx in K3_EDGES:
            row[f"R_{e_idx}"] = float(edge_data[e_idx]["R"][step])
        
        # Add directed differences for each channel
        R_dict = {e: float(edge_data[e]["R"][step]) for e in K3_EDGES}
        for ch_name, ch_def in CHANNELS.items():
            row[f"D_{ch_name}_forward"] = float(ch_def["forward_diff"](R_dict))
            row[f"D_{ch_name}_reverse"] = float(ch_def["reverse_diff"](R_dict))
        
        # Add channel quantities for each edge
        for e_idx in K3_EDGES:
            row[f"e_{e_idx}"] = float(edge_data[e_idx]["e"][step])
            row[f"T1_{e_idx}"] = float(edge_data[e_idx]["T1"][step])
            row[f"T2_{e_idx}"] = float(edge_data[e_idx]["T2"][step])
            row[f"T1_T2_ratio_{e_idx}"] = float(
                edge_data[e_idx]["T1"][step] / edge_data[e_idx]["T2"][step]
            ) if abs(edge_data[e_idx]["T2"][step]) > args.signal_floor else np.nan
        
        # Add phases
        for e_idx in K3_EDGES:
            row[f"mem_phase_{e_idx}"] = float(edge_data[e_idx]["memory_phase"][step])
            row[f"src_phase_{e_idx}"] = float(edge_data[e_idx]["source_phase"][step])
        
        trajectory_rows.append(row)
    
    trajectory = pd.DataFrame(trajectory_rows)

    # --- Process intervals ---
    boundaries = np.asarray(args.intervals, dtype=float)
    T_end = future_steps * dt

    if boundaries.size == 0:
        boundaries = np.array([0.0, T_end])
    else:
        if boundaries[0] > 0.0:
            boundaries = np.concatenate(([0.0], boundaries))
        if boundaries[-1] < T_end:
            boundaries = np.concatenate((boundaries, [T_end]))
    boundaries = np.unique(boundaries)

    # --- Audit each channel and orientation ---
    channel_summary_rows = []
    identity_check_rows = []

    times = trajectory["time"].values

    for ch_name, ch_def in CHANNELS.items():
        edge1, edge2 = ch_def["edge_pair"]
        
        for orientation in ORIENTATIONS:
            # Select difference function
            if orientation == "forward":
                diff_func = ch_def["forward_diff"]
            else:
                diff_func = ch_def["reverse_diff"]
            
            # Compute directed difference at each step
            R_dict = {e: trajectory[f"R_{e}"].values for e in K3_EDGES}
            D = np.array([diff_func({e: R_dict[e][step] for e in K3_EDGES}) 
                         for step in range(len(times))])
            
            # Channel-level quantities (difference of edge quantities)
            e1 = edge_data[edge1]["e"]
            e2 = edge_data[edge2]["e"]
            T1_1 = edge_data[edge1]["T1"]
            T1_2 = edge_data[edge2]["T1"]
            T2_1 = edge_data[edge1]["T2"]
            T2_2 = edge_data[edge2]["T2"]
            
            e_ch = e1 - e2
            T1_ch = T1_1 - T1_2
            T2_ch = T2_1 - T2_2
            
            # Verify identity: e_ch = T1_ch + T2_ch
            identity_error = np.abs(e_ch - (T1_ch + T2_ch))
            
            # Cancellation index: |T1 + T2| / (|T1| + |T2|)
            denom = np.abs(T1_ch) + np.abs(T2_ch)
            cancellation_idx = np.where(
                denom > args.signal_floor,
                np.abs(T1_ch + T2_ch) / denom,
                np.nan
            )
            
            # Phase balance: difference between edge phases
            mem_phase_1 = edge_data[edge1]["memory_phase"]
            mem_phase_2 = edge_data[edge2]["memory_phase"]
            src_phase_1 = edge_data[edge1]["source_phase"]
            src_phase_2 = edge_data[edge2]["source_phase"]
            
            phase_balance_mem = mem_phase_1 - mem_phase_2
            phase_balance_src = src_phase_1 - src_phase_2
            
            # T1/T2 ratio
            T1_T2_ratio = np.where(
                np.abs(T2_ch) > args.signal_floor,
                T1_ch / T2_ch,
                np.nan
            )
            
            # Reinforcement/cancellation classification
            reinforcement_classes = ["neutral"] * len(D)
            for n in range(len(D) - 1):
                reinforcement_classes[n] = classify_reinforcement(
                    D[n], D[n + 1], tol=args.signal_floor
                )
            
            # Fit rates over full trajectory
            e_rate_fit = fit_log_rate(times, e_ch, args.signal_floor)
            T1_rate_fit = fit_log_rate(times, T1_ch, args.signal_floor)
            T2_rate_fit = fit_log_rate(times, T2_ch, args.signal_floor)
            D_rate_fit = fit_log_rate(times, np.abs(D), args.signal_floor)
            
            # --- Per-interval summaries ---
            for interval in range(len(boundaries) - 1):
                start_idx = max(0, int(round(boundaries[interval] / dt)))
                end_idx = min(step_count, int(round(boundaries[interval + 1] / dt)))
                
                if end_idx <= start_idx + 2:
                    continue
                
                # Extract interval data
                interval_D = D[start_idx:end_idx]
                interval_e = e_ch[start_idx:end_idx]
                interval_T1 = T1_ch[start_idx:end_idx]
                interval_T2 = T2_ch[start_idx:end_idx]
                interval_cancel = cancellation_idx[start_idx:end_idx]
                interval_T1_T2 = T1_T2_ratio[start_idx:end_idx]
                interval_phase_mem = phase_balance_mem[start_idx:end_idx]
                interval_phase_src = phase_balance_src[start_idx:end_idx]
                interval_errors = identity_error[start_idx:end_idx]
                interval_classes = reinforcement_classes[start_idx:end_idx]
                
                # Most common reinforcement class
                class_counts = {}
                for cls in interval_classes:
                    class_counts[cls] = class_counts.get(cls, 0) + 1
                dominant_class = max(class_counts, key=class_counts.get) if class_counts else "neutral"
                
                # Interval-specific fits
                interval_times = times[start_idx:end_idx]
                e_fit = fit_log_rate(interval_times, interval_e, args.signal_floor)
                T1_fit = fit_log_rate(interval_times, interval_T1, args.signal_floor)
                T2_fit = fit_log_rate(interval_times, interval_T2, args.signal_floor)
                
                channel_summary_rows.append({
                    "channel": ch_name,
                    "orientation": orientation,
                    "start_time": boundaries[interval],
                    "end_time": boundaries[interval + 1],
                    "sample_count": end_idx - start_idx,
                    "directed_diff_sign": int(np.sign(np.median(interval_D))),
                    "reinforcement_class": dominant_class,
                    "min_abs_D": float(np.min(np.abs(interval_D))),
                    "max_abs_D": float(np.max(np.abs(interval_D))),
                    "e_rate": e_fit["rate"],
                    "e_R_squared": e_fit["R_squared"],
                    "T1_rate": T1_fit["rate"],
                    "T1_R_squared": T1_fit["R_squared"],
                    "T2_rate": T2_fit["rate"],
                    "T2_R_squared": T2_fit["R_squared"],
                    "cancellation_index_mean": float(np.nanmean(interval_cancel)),
                    "cancellation_index_final": float(interval_cancel[-1]) if len(interval_cancel) > 0 else np.nan,
                    "T1_T2_ratio_mean": float(np.nanmean(interval_T1_T2)),
                    "T1_T2_ratio_final": float(interval_T1_T2[-1]) if len(interval_T1_T2) > 0 else np.nan,
                    "phase_balance_mem_mean": float(np.nanmean(interval_phase_mem)),
                    "phase_balance_src_mean": float(np.nanmean(interval_phase_src)),
                    "max_identity_error": float(np.max(interval_errors)),
                    "median_identity_error": float(np.median(interval_errors)),
                })
            
            # --- Full trajectory summary ---
            class_counts_full = {}
            for cls in reinforcement_classes:
                class_counts_full[cls] = class_counts_full.get(cls, 0) + 1
            dominant_class_full = max(class_counts_full, key=class_counts_full.get) if class_counts_full else "neutral"
            
            channel_summary_rows.append({
                "channel": ch_name,
                "orientation": orientation,
                "start_time": 0.0,
                "end_time": T_end,
                "sample_count": step_count,
                "directed_diff_sign": int(np.sign(np.median(D))),
                "reinforcement_class": dominant_class_full,
                "min_abs_D": float(np.min(np.abs(D))),
                "max_abs_D": float(np.max(np.abs(D))),
                "e_rate": e_rate_fit["rate"],
                "e_R_squared": e_rate_fit["R_squared"],
                "T1_rate": T1_rate_fit["rate"],
                "T1_R_squared": T1_rate_fit["R_squared"],
                "T2_rate": T2_rate_fit["rate"],
                "T2_R_squared": T2_rate_fit["R_squared"],
                "cancellation_index_mean": float(np.nanmean(cancellation_idx)),
                "cancellation_index_final": float(cancellation_idx[-1]) if len(cancellation_idx) > 0 else np.nan,
                "T1_T2_ratio_mean": float(np.nanmean(T1_T2_ratio)),
                "T1_T2_ratio_final": float(T1_T2_ratio[-1]) if len(T1_T2_ratio) > 0 else np.nan,
                "phase_balance_mem_mean": float(np.nanmean(phase_balance_mem)),
                "phase_balance_src_mean": float(np.nanmean(phase_balance_src)),
                "max_identity_error": float(np.max(identity_error)),
                "median_identity_error": float(np.median(identity_error)),
            })
            
            # Identity check
            identity_test = test_alignment_identity(e_ch, T1_ch, T2_ch, tol=args.signal_floor)
            identity_check_rows.append({
                "identity": f"{ch_name}_{orientation}_alignment",
                "channel": ch_name,
                "orientation": orientation,
                "maximum_absolute_error": identity_test["max_abs_error"],
                "median_absolute_error": identity_test["median_abs_error"],
                "passes": identity_test["identity_passes"],
            })

    # --- Build DataFrames ---
    channel_summary = pd.DataFrame(channel_summary_rows)
    identity_checks = pd.DataFrame(identity_check_rows)

    # --- Write outputs ---
    component_audit.atomic_write_csv(
        output_dir / "two_channel_trajectory.csv", trajectory
    )
    component_audit.atomic_write_csv(
        output_dir / "two_channel_summary.csv", channel_summary
    )
    component_audit.atomic_write_csv(
        output_dir / "two_channel_identity_checks.csv", identity_checks
    )

    report = make_report(
        channel_summary,
        identity_checks,
        trajectory,
        alpha=alpha,
        dt=dt,
        final_replay_exact=final_replay_exact,
    )
    component_audit.atomic_write_text(
        output_dir / "two_channel_decomposition_report.txt", report
    )

    # --- Compute dependency hashes ---
    dep_hashes = {
        "AIEF_1_4_stationarity_perturbation_analysis_updated": compute_module_sha256(base),
        "AIEF_1_4_component_controller_audit": compute_module_sha256(component_audit),
        "AIEF_1_4_augmented_tangent_cocycle_analysis": compute_module_sha256(augmented),
    }

    # --- Build manifest ---
    manifest_output = {
        "analysis": "AIEF-1.4 two-channel directed alignment decomposition",
        "source": {
            "path": str(Path(__file__).resolve()),
            "sha256": file_sha256(Path(__file__).resolve()),
        },
        "command": sys.argv,
        "inputs": {
            "npz": {
                "path": str(Path(args.npz).resolve()),
                "sha256": file_sha256(args.npz),
            },
            "manifest": {
                "path": str(Path(args.manifest).resolve()),
                "sha256": file_sha256(args.manifest),
            },
        },
        "dependencies": {
            name: {"path": str(Path(module.__file__).resolve()), "sha256": h}
            for name, (module, h) in [
                ("base", base, dep_hashes["AIEF_1_4_stationarity_perturbation_analysis_updated"]),
                ("component_audit", component_audit, dep_hashes["AIEF_1_4_component_controller_audit"]),
                ("augmented", augmented, dep_hashes["AIEF_1_4_augmented_tangent_cocycle_analysis"]),
            ]
        },
        "seed": args.seed,
        "dt": dt,
        "alpha_EMA": alpha,
        "scale_epsilon": args.scale_epsilon,
        "intervals": boundaries.tolist(),
        "signal_floor": args.signal_floor,
        "unwrapping_convention": {"discont": UNWRAP_DISCONT},
        "final_replay_exact": final_replay_exact,
        "K3_configuration": {
            "nodes": list(K3_NODES),
            "edges": {str(e): list(nodes) for e, nodes in K3_EDGES.items()},
        },
        "channels": {
            name: {
                "description": defn["description"],
                "edge_pair": list(defn["edge_pair"]),
            }
            for name, defn in CHANNELS.items()
        },
        "outputs": [
            "two_channel_trajectory.csv",
            "two_channel_summary.csv",
            "two_channel_identity_checks.csv",
            "two_channel_decomposition_report.txt",
        ],
        "interpretation_constraints": [
            "Directed magnitude differences are R_i - R_j for K3 edge pairs (25,59) and (59,29).",
            "Edge magnitudes computed as |C_i - C_j| for edge (i,j).",
            "Reinforcement/cancellation classification uses sign(D_n) vs sign(ΔD_n) comparison.",
            "Cancellation index: |T1+T2|/(|T1|+|T2|); 0=cancellation, 1=reinforcement.",
            "T1/T2 -> -1 mechanism checked via ratio convergence to -1.",
            "Exact identity e_n = T1_n + T2_n verified numerically.",
            "Results conditional on seed 4619122171158768524 and fixed branch.",
            "Unwrapped phases use discont=pi convention.",
        ],
    }

    component_audit.atomic_write_text(
        output_dir / "analysis_manifest.json",
        json.dumps(manifest_output, indent=2, sort_keys=True) + "\n",
    )

    print(report)
    print(f"\nSaved analysis to {output_dir.resolve()}")


if __name__ == "__main__":
    main()
