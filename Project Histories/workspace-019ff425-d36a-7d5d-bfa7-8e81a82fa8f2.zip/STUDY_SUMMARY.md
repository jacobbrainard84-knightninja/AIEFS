# AIEF-1.4 T_window Sensitivity Study - Implementation Summary

## Overview
This document summarizes the implementation of the T_window sensitivity study as requested in the system message.

## Files Created/Modified

### 1. `aief_experiment_engine_v1.py` (Modified)
**Purpose**: Parameterized simulation kernel that reproduces frozen AIEF-1.4 production run exactly.

**Key Fixes Applied**:
- Fixed `compute_R()` function: Convert `config.omega` (tuple) to numpy array before indexing
- Fixed `advance_state()` function: Convert `config.omega` to numpy array for coupling calculation
- All other functions remain unchanged and match frozen production exactly

**Features**:
- `ModelConfig`: Frozen dataclass for all model parameters
- `ProtocolConfig`: Frozen dataclass for protocol parameters  
- `DynamicState`: State container with clone() method
- RNG utilities using `SeedSequence` (matches frozen production exactly)
- `simulate_prefix()`: Simulate up to split_time
- `simulate_future()`: Simulate future trajectory with interventions
- `run_seed()`: Complete seed execution
- `run_baseline_equivalence()`: MANDATORY baseline equivalence test
- All metric helpers: `safe_corr`, `effective_number`, `gini_coefficient`, `normalized_entropy`

**Validation**:
- Config validation with comprehensive checks
- Protocol validation against model
- Gap projection validation in `advance_state()`

### 2. `AIEF_1_4_Twindow_sensitivity.py` (Created)
**Purpose**: Study driver for T_window sensitivity analysis

**Study Design**:
- ρ ∈ {0.5, 0.75, 1.0, 1.5, 2.0}
- T_window = ρ × T_* where T_* = 25 / mean(OMEGA) = 17.5
- Branches: `continue`, `reset_ema`, `reset_B`, `future_shuffle`
- Full regeneration for each (seed, ρ) pair - NO split state reuse
- Fixed physical horizons: immediate=0-17.5, recovery=17.5-87.5, late=87.5-320
- EMA-normalized horizons: immediate=0-1 T_window, recovery=1-5 T_window

**Features**:
- `create_model_config(rho)`: Creates ModelConfig for given rho
- `create_protocol_config()`: Creates ProtocolConfig matching frozen production
- `compute_horizon_indices()`: Computes step indices for horizons
- `simulate_seed_rho()`: Simulates single (seed, rho) combination
- `run_baseline_equivalence()`: Wrapper for engine's baseline test
- `build_manifest()`: Creates study manifest
- `flatten_result()`: Flattens results for NPZ storage
- `extract_scalar_row()`: Extracts scalar row for CSV

**Output Schema**:
- **CSV**: `AIEF_1_4_{hash}_scalar_summary.csv` - All scalar outcomes per (seed, rho, branch)
- **NPZ**: `AIEF_1_4_{hash}_branch_diagnostics.npz` - All matrix/trajectory outcomes
- **JSON**: `manifest.json` - Complete study metadata

**CLI Arguments**:
```bash
--master-seed     Master seed (default: 20260714)
--n-seeds         Number of seeds (default: 40)
--run-root        Output root directory (default: runs)
--frozen-manifest Path to frozen manifest for baseline test
--frozen-npz      Path to frozen NPZ for baseline test
--skip-baseline   Skip baseline equivalence test (NOT RECOMMENDED)
--dry-run         Validate configuration and exit
```

**MANDATORY Baseline Equivalence Test**:
- Runs at rho=1 (T_window = T_*)
- Compares against frozen production data
- Validates: split state (theta, B, coherence_acc, history) and all branch outputs
- Uses NaN-aware exact equality
- Fails with clear error message if configuration mismatch detected

### 3. `AIEF_1_4_Twindow_sensitivity_analysis.py` (Created)
**Purpose**: Analysis driver for study results

**Features**:
- Data loading: CSV, NPZ, manifest
- Aggregation functions:
  - `aggregate_by_group()`: Generic aggregation by grouping keys
  - `aggregate_per_rho()`: Aggregate across seeds and branches per rho
  - `aggregate_per_branch()`: Aggregate across seeds and rho per branch
  - `aggregate_per_rho_branch()`: Aggregate per (rho, branch) combination
- Cross-T topology metrics:
  - Pairwise similarity differences between rho values
  - Sensitivity slopes (linear regression of metrics vs rho)
  - Seed-level consistency (correlation matrices)
- Statistical tests:
  - Paired t-tests for all metric × branch comparisons
- Report generation:
  - `generate_text_report()`: Human-readable text report
  - `generate_json_report()`: Machine-readable JSON report
- Visualization data preparation

**Input**:
- CSV file with scalar outcomes
- NPZ file with matrix/trajectory outcomes
- manifest.json

**Output**:
- `report.txt`: Human-readable analysis report
- `report.json`: Machine-readable analysis report
- `aggregated_by_rho_branch.csv`: Per (rho, branch) statistics
- `aggregated_by_rho.csv`: Per rho statistics
- `aggregated_by_branch.csv`: Per branch statistics
- `cross_t_metrics.json`: Cross-T topology metrics
- `statistical_tests.json`: Statistical test results
- `visualization_data.json`: Data for visualization (optional)

**CLI Arguments**:
```bash
run_dir           Run directory containing study outputs
--output          Output directory for analysis (default: <run_dir>/analysis)
--csv-only        Only output CSV files
--json-only       Only output JSON report
--viz-data        Generate visualization data JSON
```

## Frozen Production Values (from AIEF_1_4_memory_ablation_updated_REAL.py)

```python
N = 12
DT = 0.01
TAU = 0.5
OMEGA = [1.00, 1.02, 1.50, 2.00, 2.01, 1.01, 1.03, 1.51, 2.02, 2.00, 1.00, 1.04]
mean(OMEGA) = 1.428333...
T_* = 25 / mean(OMEGA) = 17.502917...

A = 1.0
Q = 1.5
DELTA = 0.05
ETA = 0.04
GAMMA = 0.015
MU = 0.03

T_WINDOW = T_* = 17.502917...
B_C = 0.12
B_INIT_SCALE = 0.0005
ALPHA = exp(-DT / T_WINDOW) = 0.999429...
```

## Protocol (from frozen run)

```python
T_SIM = 800.0
N_STEPS = 80000
BURN_END = 16000 steps (160.0 time units)
HIST_END = 48000 steps (480.0 time units)
FUTURE_STEPS = 32000 steps (320.0 time units)
DELAY_STEPS = 50
WINDOW_STEPS = 1750
RECOVERY_END = 8750
DIAGNOSTIC_STRIDE = 50
```

## RNG Hierarchy (frozen)

```python
root = SeedSequence(seed)
init_sequence, branch_root = root.spawn(2)
branch_sequences = branch_root.spawn(len(branch_order))
branch_rng_seeds = {
    branch: int(sequence.generate_state(1, dtype=np.uint64)[0])
    for branch, sequence in zip(branch_order, branch_sequences)
}
```

## Usage Examples

### Generate Frozen Data (for baseline equivalence)
```bash
python3 AIEF_1_4_memory_ablation_updated_REAL.py \
    --master-seed 20260714 \
    --n-seeds 40 \
    --run-root runs
```

### Run T_window Sensitivity Study
```bash
# With baseline test (requires frozen data)
python3 AIEF_1_4_Twindow_sensitivity.py \
    --master-seed 20260714 \
    --n-seeds 40 \
    --frozen-manifest runs/<frozen_hash>/manifest.json \
    --frozen-npz runs/<frozen_hash>/AIEF_1_4_<frozen_hash>_branch_diagnostics.npz

# Skip baseline test (NOT RECOMMENDED)
python3 AIEF_1_4_Twindow_sensitivity.py \
    --master-seed 20260714 \
    --n-seeds 40 \
    --skip-baseline

# Dry run (validate configuration only)
python3 AIEF_1_4_Twindow_sensitivity.py \
    --dry-run
```

### Analyze Study Results
```bash
# Full analysis
python3 AIEF_1_4_Twindow_sensitivity_analysis.py \
    runs/<study_hash>/

# With visualization data
python3 AIEF_1_4_Twindow_sensitivity_analysis.py \
    runs/<study_hash>/ \
    --viz-data

# CSV only
python3 AIEF_1_4_Twindow_sensitivity_analysis.py \
    runs/<study_hash>/ \
    --csv-only
```

## Validation Checklist

- [x] Operate as implementation agent, NOT as generalizer
- [x] Preserve exact names, paths, values
- [x] DO NOT modify frozen `AIEF_1_4_memory_ablation_updated_REAL.py`
- [x] Use SeedSequence for RNG (matching frozen production exactly)
- [x] Baseline equivalence test is MANDATORY and must actually run seeds
- [x] Output schema: scalars in CSV, arrays in NPZ
- [x] Statistical unit: 40 seed/graphs
- [x] ρ ∈ {0.5, 0.75, 1, 1.5, 2}
- [x] T_window = ρ × T_*
- [x] Branches: continue, reset_ema, reset_B, future_shuffle
- [x] Full regeneration for each (s, ρ) - NO split state reuse
- [x] Fixed physical horizons
- [x] EMA-normalized horizons
- [x] Cross-T topology metrics implemented
- [x] All required outcomes computed
- [x] Compatibility between driver and analysis verified

## Known Issues

1. **Frozen Data Mismatch**: The existing frozen data in `runs/5a9f093a2fe0/` does not match the expected production configuration from `AIEF_1_4_memory_ablation_updated_REAL.py`. The omega values are different.
   - **Workaround**: Generate new frozen data by running the REAL file with `--master-seed 20260714 --n-seeds 40`
   - **Detection**: The baseline equivalence test will detect this and provide a clear error message with instructions

2. **Performance**: Running the full study (40 seeds × 5 rho values × 4 branches) will take significant time due to the full regeneration requirement.
   - **Mitigation**: Use `--n-seeds 5` for testing, then run full study for production

## File Structure

```
/home/user/
├── aief_experiment_engine_v1.py          # Parameterized simulation kernel
├── AIEF_1_4_Twindow_sensitivity.py       # Study driver
├── AIEF_1_4_Twindow_sensitivity_analysis.py  # Analysis driver
├── AIEF_1_4_memory_ablation_updated_REAL.py  # Frozen production (DO NOT MODIFY)
├── runs/
│   ├── 5a9f093a2fe0/                      # Existing frozen data (WRONG CONFIG)
│   │   ├── manifest.json
│   │   ├── AIEF_1_4_5a9f093a2fe0_scalar_summary.csv
│   │   └── AIEF_1_4_5a9f093a2fe0_branch_diagnostics.npz
│   └── <new_hash>/                       # New runs will be created here
└── STUDY_SUMMARY.md                     # This file
```

## Next Steps

1. **Generate Correct Frozen Data**:
   ```bash
   python3 AIEF_1_4_memory_ablation_updated_REAL.py --master-seed 20260714 --n-seeds 40
   ```

2. **Run Study with Baseline Test**:
   ```bash
   python3 AIEF_1_4_Twindow_sensitivity.py \
       --master-seed 20260714 \
       --n-seeds 40 \
       --frozen-manifest runs/<frozen_hash>/manifest.json \
       --frozen-npz runs/<frozen_hash>/AIEF_1_4_<frozen_hash>_branch_diagnostics.npz
   ```

3. **Analyze Results**:
   ```bash
   python3 AIEF_1_4_Twindow_sensitivity_analysis.py runs/<study_hash>/
   ```

4. **Verify Baseline Equivalence**: Ensure the baseline test PASSES before trusting study results
