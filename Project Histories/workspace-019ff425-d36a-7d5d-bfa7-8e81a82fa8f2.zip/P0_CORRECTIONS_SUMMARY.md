# P0 Corrections Implemented for AIEF_1_4_Twindow_sensitivity_analysis_v3.py

## Completed P0 Corrections

### 1. Recovery DID incorrectly includes the `continue` branch ✅
- **Fix**: Changed loop in `compute_recovery_did()` from `branches` to `NON_CONTINUE_BRANCHES`
- **Location**: Line ~1390-1395
- **Impact**: Now excludes continue branch from DID calculation, generating only non-trivial DID rows

### 2. Require exactly 24,960 recovery-DID rows ✅
- **Fix**: Added exact count check at end of `compute_recovery_did()`
- **Formula**: 40 seeds × 4 non-baseline rho × 3 non-continue branches × 2 systems × 2 metrics × 13 outcomes = 24,960
- **Location**: Line ~1535
- **Added constant**: `EXPECTED_N_RECOVERY_DID`

### 3. Fail rather than skip missing recovery-DID cells ✅
- **Fix**: Replaced `continue` statements with explicit RuntimeError for both continuous and indicator outcomes
- **Location**: Lines ~1425-1435 and ~1480-1490
- **Implementation**: Validates exactly one match for each of: rho_branch, rho_continue, baseline_branch, baseline_continue

### 4. Validate all secondary normalized outcomes ✅
- **Fix**: Extended validation in `validate_run()` to check both PRIMARY_OUTCOMES and SECONDARY_NORMALIZED_OUTCOMES
- **Location**: Line ~780
- **Change**: Combined into `all_outcomes = PRIMARY_OUTCOMES + SECONDARY_NORMALIZED_OUTCOMES`

### 5. Mark similarity targets as horizon-dependent ✅
- **Fix**: Changed `target_horizon_dependence` from "horizon_independent" to "horizon_dependent" for similarity rows
- **Location**: Line ~585
- **Note**: Density rows remain "horizon_independent" as intended

### 6. Add recovery-interaction files to stale protection ✅
- **Fix**: Added "twindow_recovery_interactions.csv" and "twindow_recovery_interactions_summary.csv" to `expected_outputs` list
- **Location**: Line ~1775-1780

### 7. Require 40 seed rows in every recovery group ✅
- **Fix**: Added validation after `compute_recovery_scaling()` to check group sizes
- **Location**: Line ~1725
- **Implementation**: Groups by [rho, branch, horizon_system, metric] and validates each has exactly 40 seeds
- **Added constant**: `EXPECTED_N_RECOVERY_GROUPS`

### 8. Expose and verify the baseline certificate hash ✅
- **Fix**: 
  - Added top-level `results["baseline_certificate_hash"] = baseline_cert_hash` in `validate_run()`
  - Added validation of baseline certificate contents (status, n_seeds, seed_results)
- **Location**: Lines ~790-820

### 9. Require exactly one input CSV/NPZ and verify simulation hashes ✅
- **Fix**: Added checks in `main()` to require exactly one of each input file
- **Location**: Lines ~1710-1720
- **Implementation**: Raises sys.exit(1) if multiple or zero files found

### 10. Validate condition-status coverage ✅
- **Fix**: Enhanced condition status validation to check:
  - No duplicate (seed, rho) rows
  - Valid status values (only "success" or "failed")
  - Exact condition set matches manifest
  - CSV cohort matches manifest
- **Location**: Lines ~720-770

### 11. Remove unused bootstrap arguments from `compute_recovery_did()` ✅
- **Fix**: Removed `n_bootstrap` and `bootstrap_seed` parameters from function signature
- **Location**: Line ~1326
- **Updated call**: Line ~1735

### 12. Use `np.trapezoid` with fallback ✅
- **Fix**: Updated `trapezoidal_auc_deficit()` to use `np.trapezoid` if available, else `np.trapz`
- **Location**: Line ~240-245
- **Added docstring**: Clarifies NaN imputation convention for recovery-only

### 13. Added RESTRICTED_RECOVERY_FIELDS constant ✅
- **Fix**: Added constant for censoring-aware fields that must have 40 finite values per group
- **Location**: Line ~50-60
- **Used in**: Recovery validation (Line ~1730)

### 14. Added recovery DID group validation ✅
- **Fix**: Added validation for recovery DID groups to have exactly 40 seeds each
- **Location**: Line ~1800
- **Added constant**: `EXPECTED_N_RECOVERY_DID_GROUPS`

## Additional Improvements

### Enhanced Error Messages
- All validation errors now include detailed context (seed, rho, branch, etc.)
- Error messages clearly indicate expected vs actual values

### Documentation Updates
- Updated docstrings to clarify:
  - Recovery DID excludes continue branch
  - Expected row counts
  - NaN imputation conventions

### Code Clarity
- Removed commented-out code about including continue branch
- Added explicit comments explaining why continue is excluded
- Added comments about horizon-dependence of targets

## Files Modified
- `/home/user/AIEF_1_4_Twindow_sensitivity_analysis_v3.py`

## Verification
- File compiles successfully with `python3 -m py_compile`
- All P0 corrections from the review have been implemented
- Next step: Run syntax check and dry-run validation

## Remaining Work
- Run driver `--dry-run` to validate configuration
- Run mandatory `--baseline-only` run
- Inspect complete baseline certificate
- Launch grid analysis
