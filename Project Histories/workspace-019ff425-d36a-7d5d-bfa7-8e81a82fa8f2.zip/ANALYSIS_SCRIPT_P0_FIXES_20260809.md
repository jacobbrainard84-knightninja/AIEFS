# Analysis Script P0 Fixes - 2026-08-09

## Overview

This document summarizes the P0 fixes applied to `AIEF_1_4_Twindow_sensitivity_analysis_v3.py` based on the detailed code review provided.

## P0 Issues Fixed

### P0 #1: `NON_CONTINUE_BRANCHES` Forward Reference (Already Fixed)

**Issue:** `NON_CONTINUE_BRANCHES` was referenced at lines 75 and 81 before being defined at line 95, causing `NameError` at import time.

**Fix:** Moved definition to line 65, before any references.

**Status:** ✅ Already fixed in earlier work

---

### P0 #2: `T_window` Not Validated Before Recovery Normalization

**Issue:** Stage 1 validation did not verify:
- `T_window` column exists in CSV
- `T_window` values are finite and positive
- `T_window` is consistent across branches for each (seed, rho)
- `T_window` matches expected values from manifest

**Fix Applied:** Added comprehensive `T_window` validation in `validate_run()` function:

```python
# P0 #2: Validate T_window exists and is consistent
if "T_window" not in df.columns:
    results["status"] = "failed"
    results["errors"].append("T_window missing from scalar CSV")
    return results
else:
    tw = pd.to_numeric(df["T_window"], errors="coerce")
    if (~np.isfinite(tw) | (tw <= 0)).any():
        results["status"] = "failed"
        results["errors"].append("T_window contains non-finite or non-positive values")
        return results
    
    # Validate T_window is consistent across branches for each (seed, rho)
    for rho, expected_twindow in zip(
        [float(r) for r in manifest["study"]["rho_values"]],
        [float(x) for x in manifest["study"]["T_window_values"]]
    ):
        rho_mask = df["rho"] == rho
        values = df.loc[rho_mask, "T_window"].unique()
        if len(values) != 1:
            results["status"] = "failed"
            results["errors"].append(f"rho={rho} has {len(values)} distinct T_window values")
            return results
        elif float(values[0]) != expected_twindow:
            results["status"] = "failed"
            results["errors"].append(f"rho={rho}: T_window={values[0]} != expected {expected_twindow}")
            return results
```

**Impact:** Prevents corrupted `T_window` values from corrupting recovery normalization calculations.

**Status:** ✅ Fixed

---

### P0 #3: `D_B_final` Not Validated

**Issue:** Density recovery uses `D_B_final` for targets (0.9 * D_B_final_continue), but Stage 1 did not validate:
- `D_B_final` column exists
- Values are finite
- Values are in valid range [0, 1]

**Fix Applied:** Added validation in `validate_run()` function:

```python
# P0 #3: Validate D_B_final exists and is valid
if "D_B_final" not in df.columns:
    results["status"] = "failed"
    results["errors"].append("D_B_final missing from scalar CSV")
    return results
else:
    density = pd.to_numeric(df["D_B_final"], errors="coerce")
    invalid = (~np.isfinite(density) | (density < 0.0) | (density > 1.0))
    if invalid.any():
        results["status"] = "failed"
        results["errors"].append(
            f"D_B_final has {int(invalid.sum())} invalid values (must be in [0,1])"
        )
        return results
```

**Impact:** Ensures density targets are valid before recovery calculations.

**Status:** ✅ Fixed

---

### P0 #4: Simulation Output Hashes Not Verified

**Issue:** Stage 1 did not compare actual input file hashes against the simulation manifest's recorded hashes. A modified CSV, NPZ, or certificate could pass structural checks.

**Fix Applied:** Added hash verification in `validate_run()` function:

```python
# P0 #4: Verify simulation output hashes against manifest
recorded_hashes = manifest.get("output_hashes", {})

files_to_verify = {
    "scalar_csv": csv_path,
    "branch_npz": npz_path,
    "condition_status_csv": condition_status_path,
    "baseline_certificate": baseline_cert_path,
}

for label, path in files_to_verify.items():
    expected_hash = recorded_hashes.get(label)
    observed_hash = file_sha256(path)
    
    if expected_hash is None:
        results["status"] = "failed"
        results["errors"].append(
            f"Simulation manifest missing output hash for {label}"
        )
        return results
    elif observed_hash != expected_hash:
        results["status"] = "failed"
        results["errors"].append(
            f"Hash mismatch for {label}: expected={expected_hash}, observed={observed_hash}"
        )
        return results
```

**Impact:** Prevents analysis of tampered or mismatched input files.

**Status:** ✅ Fixed

---

### P0 #5: Expected Recovery Group Constants Not Used

**Issue:** Expected count constants were defined but not used to validate actual group counts:
- `EXPECTED_N_RECOVERY_GROUPS` = 80 (5 rho × 4 branches × 2 systems × 2 metrics)
- `EXPECTED_N_RECOVERY_DID_GROUPS` = 624 (4 rho × 3 branches × 2 systems × 2 metrics × 13 outcomes)

**Fix Applied:** Added group count validation in main execution:

```python
# P0 #5: Validate expected number of recovery groups
if len(recovery_group_sizes) != EXPECTED_N_RECOVERY_GROUPS:
    raise RuntimeError(
        f"Expected {EXPECTED_N_RECOVERY_GROUPS} recovery groups, "
        f"got {len(recovery_group_sizes)}"
    )

# And for recovery DID:
if len(recovery_did_group_sizes) != EXPECTED_N_RECOVERY_DID_GROUPS:
    raise RuntimeError(
        f"Expected {EXPECTED_N_RECOVERY_DID_GROUPS} recovery DID groups, "
        f"got {len(recovery_did_group_sizes)}"
    )
```

**Impact:** Detects missing entire groups (not just individual rows).

**Status:** ✅ Fixed

---

## Summary of Changes

### Files Modified
- `/home/user/AIEF_1_4_Twindow_sensitivity_analysis_v3.py`

### Lines Changed
1. **P0 #2 & #3:** Lines ~1020-1050 - Added `T_window` and `D_B_final` validation
2. **P0 #4:** Lines ~1050-1080 - Added simulation output hash verification
3. **P0 #5:** Lines ~2578-2581 - Added recovery group count validation
4. **P0 #5:** Lines ~2624-2627 - Added recovery DID group count validation

## Validation Results

✅ All syntax checks pass
✅ Module imports successfully
✅ All P0 issues from the review are addressed

## Remaining P1 Issues

The following P1 issues from the review are NOT addressed in this fix (they are lower priority):

1. **P1 #6:** Validate regime, DID, and topology summary group sizes
2. **P1 #7:** Validate topology matrices before computing metrics
3. **P1 #8:** Validate all trajectory lengths against `sample_times`
4. **P1 #9:** Validate density and similarity trajectory ranges
5. **P1 #10:** Add zero-imputation convention to recovery rows
6. **P1 #11:** Manifest cohort validation failures downgraded to warnings
7. **P1 #12:** Stale output deletion occurs before input validation
8. **P1 #13:** Summary docstring says "Std error" but computes sample SD
9. **P1 #14:** Conditional sustained/held CIs remain absent
10. **P1 #15:** CSV atomic writing lacks file fsync
11. **Minor cleanup:** Various unused variables and imports

These P1 issues can be addressed in a subsequent pass if needed.

## Testing Recommendations

To verify the fixes work:

```bash
# Syntax check
python3 -m py_compile AIEF_1_4_Twindow_sensitivity_analysis_v3.py

# Import check
python3 -c "import AIEF_1_4_Twindow_sensitivity_analysis_v3; print('OK')"

# Run with test data (if available)
python3 AIEF_1_4_Twindow_sensitivity_analysis_v3.py <run_dir> --bootstrap-seed 42
```

## Next Steps

1. ✅ All P0 issues for analysis script are now fixed
2. Run the analysis script with actual data to verify end-to-end
3. Address P1 issues if time permits (optional for baseline certification)

---

*Document created: 2026-08-09 06:45 UTC*
*Status: All P0 fixes implemented for analysis script*
