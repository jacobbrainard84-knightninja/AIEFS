#!/usr/bin/env python3
"""AIEF_1_4_trajectory_recovery_equivalence - Recovery helpers stub for testing.

This is a minimal stub implementing the validated recovery helpers.
"""

from __future__ import annotations

import numpy as np


def time_to_at_least(
    times: np.ndarray,
    values: np.ndarray,
    threshold: float,
) -> float:
    """Find first time where values >= threshold."""
    above = np.asarray(values, dtype=float) >= threshold
    if np.any(above):
        idx = np.argmax(above)
        return float(times[idx])
    return float('nan')


def first_time_sustained_for_rest(
    times: np.ndarray,
    values: np.ndarray,
    threshold: float,
) -> float:
    """Find first time where values stays >= threshold for the rest of the trajectory."""
    above = np.asarray(values, dtype=float) >= threshold
    # Find first index where all subsequent values are above threshold
    for i in range(len(above)):
        if np.all(above[i:]):
            return float(times[i])
    return float('nan')


def first_time_held_for_duration(
    times: np.ndarray,
    values: np.ndarray,
    threshold: float,
    duration: float,
) -> float:
    """Find first time where values stays >= threshold for at least duration."""
    if len(times) == 0:
        return float('nan')
    
    times_arr = np.asarray(times, dtype=float)
    values_arr = np.asarray(values, dtype=float)
    
    # Calculate time step
    if len(times_arr) > 1:
        dt = float(times_arr[1] - times_arr[0])
    else:
        dt = duration  # If only one time point, need it to be >= duration
    
    if dt <= 0:
        return float('nan')
    
    # Number of steps needed
    n_steps = int(np.ceil(duration / dt))
    
    if n_steps < 1:
        n_steps = 1
    
    above = values_arr >= threshold
    
    # Check each possible starting point
    for i in range(len(above) - n_steps + 1):
        if np.all(above[i:i + n_steps]):
            return float(times_arr[i])
    
    return float('nan')


def time_to_below(
    times: np.ndarray,
    values: np.ndarray,
    threshold: float,
) -> float:
    """Find first time where values <= threshold."""
    below = np.asarray(values, dtype=float) <= threshold
    if np.any(below):
        idx = np.argmax(below)
        return float(times[idx])
    return float('nan')


if __name__ == "__main__":
    print("AIEF_1_4_trajectory_recovery_equivalence stub loaded")
