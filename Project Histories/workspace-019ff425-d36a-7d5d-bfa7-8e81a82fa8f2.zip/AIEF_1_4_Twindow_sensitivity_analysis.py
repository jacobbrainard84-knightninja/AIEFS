#!/usr/bin/env python3
"""AIEF-1.4 T_window Sensitivity Study Analysis Driver.

Analysis driver for T_window sensitivity study results.

Input:
- CSV file with scalar outcomes from AIEF_1_4_Twindow_sensitivity.py
- NPZ file with matrix/trajectory outcomes

Output:
- Analysis reports (text and JSON)
- Aggregated statistics
- Cross-T topology metrics
- Visualization-ready data

Features:
- Per-rho aggregation across seeds
- Per-branch aggregation across seeds and rho
- Cross-T topology metric computation
- Statistical significance testing
- Report generation
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path
from typing import Any

import numpy as np


# =============================================================================
# Configuration
# =============================================================================

STUDY_NAME = "AIEF_1_4_Twindow_sensitivity"
ANALYSIS_VERSION = "v1.0"

# Expected values from study design
RHO_VALUES = (0.5, 0.75, 1.0, 1.5, 2.0)
T_STAR = 17.5
T_WINDOW_VALUES = tuple(rho * T_STAR for rho in RHO_VALUES)
STUDY_BRANCHES = ("continue", "reset_ema", "reset_B", "future_shuffle")

# Primary outcomes
PRIMARY_OUTCOMES = (
    "Weighted_similarity_late",
    "Retention_contrast_late",
    "P_mean_late",
)

# Key metrics for cross-T analysis
CROSS_T_METRICS = (
    "D_B_final",
    "P_mean_late",
    "Weighted_similarity_late",
    "Retention_contrast_late",
    "Retention_selected_late",
    "Emergence_unselected_late",
    "Total_edge_weight",
    "Effective_edges",
    "Weight_gini",
    "Weight_entropy",
    "Projection_active_fraction",
    "Minimum_similarity",
)

# Branch families for aggregation
BRANCH_FAMILIES = {
    "reference": ("continue",),
    "memory_ablation": ("reset_ema", "reset_B"),
    "driver_control": ("future_shuffle",),
}


# =============================================================================
# Utility Functions
# =============================================================================

def load_csv(path: str | Path) -> list[dict[str, Any]]:
    """Load CSV file into list of dicts."""
    rows = []
    with open(path, "r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            # Convert numeric fields
            for key, value in row.items():
                try:
                    if "." in value or "e" in value.lower():
                        row[key] = float(value)
                    elif value.lstrip("-").isdigit():
                        row[key] = int(value)
                except (ValueError, AttributeError):
                    pass
            rows.append(row)
    return rows


def load_npz(path: str | Path) -> dict[str, Any]:
    """Load NPZ file."""
    payload: dict[str, Any] = {}
    with np.load(str(path), allow_pickle=False) as data:
        for key in data.files:
            value = data[key]
            payload[key] = value.item() if value.ndim == 0 else value.copy()
    return payload


def load_manifest(path: str | Path) -> dict[str, Any]:
    """Load manifest JSON."""
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def save_json(path: str | Path, data: dict[str, Any]) -> None:
    """Save JSON file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")


def save_csv(path: str | Path, rows: list[dict[str, Any]]) -> None:
    """Save CSV file."""
    if not rows:
        return
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def parse_run_dir(run_dir: str | Path) -> tuple[Path, Path, Path, Path]:
    """Parse run directory to find input files."""
    run_dir = Path(run_dir)
    
    # Find manifest
    manifest_path = run_dir / "manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError(f"manifest.json not found in {run_dir}")
    
    # Find CSV
    csv_files = list(run_dir.glob(f"{STUDY_NAME}_*_scalar_summary.csv"))
    if not csv_files:
        raise FileNotFoundError(f"CSV file not found in {run_dir}")
    csv_path = csv_files[0]
    
    # Find NPZ
    npz_files = list(run_dir.glob(f"{STUDY_NAME}_*_branch_diagnostics.npz"))
    if not npz_files:
        raise FileNotFoundError(f"NPZ file not found in {run_dir}")
    npz_path = npz_files[0]
    
    return run_dir, manifest_path, csv_path, npz_path


# =============================================================================
# Data Aggregation
# =============================================================================

def aggregate_by_group(
    data: list[dict[str, Any]],
    group_keys: tuple[str, ...],
    value_keys: tuple[str, ...],
) -> dict[tuple, dict[str, dict[str, float]]]:
    """Aggregate data by grouping keys, computing statistics for each value key.
    
    Returns nested dict: {(group_values): {value_key: {stat: value}}}
    """
    from collections import defaultdict
    
    groups = defaultdict(lambda: defaultdict(list))
    
    for row in data:
        # Create group key
        group_key = tuple(row[k] for k in group_keys)
        
        for vk in value_keys:
            if vk in row and isinstance(row[vk], (int, float)):
                groups[group_key][vk].append(float(row[vk]))
    
    # Compute statistics
    result = {}
    for group_key, values in groups.items():
        result[group_key] = {}
        for vk, vals in values.items():
            vals = np.array(vals)
            finite_vals = vals[np.isfinite(vals)]
            if len(finite_vals) > 0:
                result[group_key][vk] = {
                    "n": int(len(finite_vals)),
                    "mean": float(np.mean(finite_vals)),
                    "std": float(np.std(finite_vals)),
                    "min": float(np.min(finite_vals)),
                    "max": float(np.max(finite_vals)),
                    "median": float(np.median(finite_vals)),
                    "q25": float(np.percentile(finite_vals, 25)),
                    "q75": float(np.percentile(finite_vals, 75)),
                }
            else:
                result[group_key][vk] = {
                    "n": 0,
                    "mean": float('nan'),
                    "std": float('nan'),
                    "min": float('nan'),
                    "max": float('nan'),
                    "median": float('nan'),
                    "q25": float('nan'),
                    "q75": float('nan'),
                }
    
    return result


def aggregate_per_rho(
    data: list[dict[str, Any]],
    value_keys: tuple[str, ...] = CROSS_T_METRICS,
) -> dict[float, dict[str, dict[str, float]]]:
    """Aggregate data per rho value, across all seeds and branches."""
    return aggregate_by_group(data, ("rho",), value_keys)


def aggregate_per_branch(
    data: list[dict[str, Any]],
    value_keys: tuple[str, ...] = CROSS_T_METRICS,
) -> dict[str, dict[str, dict[str, float]]]:
    """Aggregate data per branch, across all seeds and rho."""
    return aggregate_by_group(data, ("branch",), value_keys)


def aggregate_per_rho_branch(
    data: list[dict[str, Any]],
    value_keys: tuple[str, ...] = CROSS_T_METRICS,
) -> dict[tuple, dict[str, dict[str, float]]]:
    """Aggregate data per (rho, branch) combination."""
    return aggregate_by_group(data, ("rho", "branch"), value_keys)


# =============================================================================
# Cross-T Topology Metrics
# =============================================================================

def compute_cross_t_metrics(
    data: list[dict[str, Any]],
) -> dict[str, Any]:
    """Compute cross-T topology metrics comparing different T_window values.
    
    Metrics:
    - Consistency: How similar are topologies across different T_window values?
    - Stability: How stable is topology within a T_window across seeds?
    - Sensitivity: How much do metrics change with T_window?
    """
    results = {}
    
    # Group by seed and rho
    seed_rho_data = {}
    for row in data:
        key = (row["seed"], row["rho"])
        if key not in seed_rho_data:
            seed_rho_data[key] = {}
        seed_rho_data[key][row["branch"]] = row
    
    # Compute pairwise similarities between rho values (for continue branch)
    rho_pairs = []
    for i, rho1 in enumerate(RHO_VALUES):
        for rho2 in RHO_VALUES[i+1:]:
            rho_pairs.append((rho1, rho2))
    
    pairwise_similarities = {}
    for rho1, rho2 in rho_pairs:
        similarities = []
        for seed in set(r["seed"] for r in data):
            key1 = (seed, rho1)
            key2 = (seed, rho2)
            if key1 in seed_rho_data and key2 in seed_rho_data:
                if "continue" in seed_rho_data[key1] and "continue" in seed_rho_data[key2]:
                    sim1 = seed_rho_data[key1]["continue"].get("Weighted_similarity_late", np.nan)
                    sim2 = seed_rho_data[key2]["continue"].get("Weighted_similarity_late", np.nan)
                    # We want similarity between B matrices at different T_window
                    # For now, use the similarity metric itself as proxy
                    if np.isfinite(sim1) and np.isfinite(sim2):
                        similarities.append(abs(sim1 - sim2))
        
        if similarities:
            pairwise_similarities[(rho1, rho2)] = {
                "mean_diff": float(np.mean(similarities)),
                "std_diff": float(np.std(similarities)),
                "n": len(similarities),
            }
    
    results["pairwise_rho_similarity_differences"] = pairwise_similarities
    
    # Compute sensitivity metrics (slope of metrics vs rho)
    sensitivity = {}
    for metric in CROSS_T_METRICS:
        # Collect (rho, value) pairs for continue branch
        rho_values = []
        metric_values = []
        for row in data:
            if row["branch"] == "continue" and metric in row:
                rho_values.append(row["rho"])
                metric_values.append(row[metric])
        
        if len(rho_values) >= 2:
            # Fit linear regression
            x = np.array(rho_values)
            y = np.array(metric_values)
            finite = np.isfinite(y)
            x = x[finite]
            y = y[finite]
            
            if len(x) >= 2:
                A = np.vstack([x, np.ones(len(x))]).T
                m, c = np.linalg.lstsq(A, y, rcond=None)[0]
                sensitivity[metric] = {
                    "slope": float(m),
                    "intercept": float(c),
                    "r_squared": float(1 - np.sum((y - (m*x + c))**2) / np.sum((y - np.mean(y))**2)) if np.std(y) > 0 else float('nan'),
                }
            else:
                sensitivity[metric] = {
                    "slope": float('nan'),
                    "intercept": float('nan'),
                    "r_squared": float('nan'),
                }
        else:
            sensitivity[metric] = {
                "slope": float('nan'),
                "intercept": float('nan'),
                "r_squared": float('nan'),
            }
    
    results["sensitivity_slopes"] = sensitivity
    
    # Compute topology consistency across T_window
    # For each seed, compute correlation of metrics across rho values
    seed_consistency = {}
    for seed in set(r["seed"] for r in data):
        seed_data = [r for r in data if r["seed"] == seed and r["branch"] == "continue"]
        if len(seed_data) >= 2:
            # Compute correlation matrix of metrics across rho
            metrics = list(CROSS_T_METRICS)
            n_metrics = len(metrics)
            corr_matrix = np.zeros((n_metrics, n_metrics))
            
            for i, m1 in enumerate(metrics):
                for j, m2 in enumerate(metrics):
                    vals1 = np.array([r.get(m1, np.nan) for r in seed_data])
                    vals2 = np.array([r.get(m2, np.nan) for r in seed_data])
                    finite = np.isfinite(vals1) & np.isfinite(vals2)
                    if np.sum(finite) >= 2:
                        corr_matrix[i, j] = float(np.corrcoef(vals1[finite], vals2[finite])[0, 1])
                    else:
                        corr_matrix[i, j] = float('nan')
            
            seed_consistency[seed] = {
                "correlation_matrix": corr_matrix.tolist(),
                "metrics": list(metrics),
            }
    
    results["seed_consistency"] = seed_consistency
    
    return results


# =============================================================================
# Statistical Analysis
# =============================================================================

def compute_statistical_tests(
    data: list[dict[str, Any]],
    comparisons: list[tuple[str, str, str]],  # (metric, branch1, branch2)
) -> dict[str, Any]:
    """Compute statistical tests for specified comparisons.
    
    Uses paired t-tests (since seeds are paired across branches).
    """
    results = {}
    
    for metric, branch1, branch2 in comparisons:
        # Collect paired values
        values1 = []
        values2 = []
        
        for seed in set(r["seed"] for r in data):
            seed_data = [r for r in data if r["seed"] == seed]
            r1 = next((r for r in seed_data if r["branch"] == branch1), None)
            r2 = next((r for r in seed_data if r["branch"] == branch2), None)
            
            if r1 and r2 and metric in r1 and metric in r2:
                v1 = r1[metric]
                v2 = r2[metric]
                if isinstance(v1, (int, float)) and isinstance(v2, (int, float)):
                    if np.isfinite(v1) and np.isfinite(v2):
                        values1.append(float(v1))
                        values2.append(float(v2))
        
        if len(values1) >= 2:
            # Paired t-test
            diffs = np.array(values1) - np.array(values2)
            n = len(diffs)
            mean_diff = float(np.mean(diffs))
            std_diff = float(np.std(diffs, ddof=1))
            se = std_diff / np.sqrt(n)
            t_stat = mean_diff / se if se > 0 else float('nan')
            
            # Two-tailed p-value
            from scipy import stats
            p_value = float(stats.t.sf(abs(t_stat), n-1) * 2) if not np.isnan(t_stat) else float('nan')
            
            results[f"{metric}_{branch1}_vs_{branch2}"] = {
                "n": n,
                "mean_diff": mean_diff,
                "std_diff": std_diff,
                "t_stat": t_stat,
                "p_value": p_value,
                "mean_branch1": float(np.mean(values1)),
                "mean_branch2": float(np.mean(values2)),
            }
        else:
            results[f"{metric}_{branch1}_vs_{branch2}"] = {
                "n": len(values1),
                "mean_diff": float('nan'),
                "std_diff": float('nan'),
                "t_stat": float('nan'),
                "p_value": float('nan'),
                "mean_branch1": float('nan'),
                "mean_branch2": float('nan'),
            }
    
    return results


# =============================================================================
# Report Generation
# =============================================================================

def generate_text_report(
    data: list[dict[str, Any]],
    manifest: dict[str, Any],
    cross_t_metrics: dict[str, Any],
    statistical_tests: dict[str, Any],
) -> str:
    """Generate human-readable text report."""
    lines = []
    lines.append("=" * 80)
    lines.append(f"AIEF-1.4 T_window Sensitivity Study Analysis Report")
    lines.append("=" * 80)
    lines.append("")
    
    # Study info
    lines.append("STUDY INFORMATION")
    lines.append("-" * 40)
    lines.append(f"  Study name:     {manifest.get('study_name', 'N/A')}")
    lines.append(f"  Workflow:       {manifest.get('workflow_version', 'N/A')}")
    lines.append(f"  Config hash:    {manifest.get('config_hash', 'N/A')}")
    lines.append(f"  N seeds:       {manifest.get('study', {}).get('n_seeds', 'N/A')}")
    lines.append(f"  Rho values:    {manifest.get('study', {}).get('rho_values', 'N/A')}")
    lines.append(f"  T_*:           {manifest.get('notes', {}).get('T_*', 'N/A')}")
    lines.append("")
    
    # Model parameters
    lines.append("MODEL PARAMETERS")
    lines.append("-" * 40)
    model = manifest.get("model", {})
    for key, value in model.items():
        if isinstance(value, list):
            lines.append(f"  {key}: {value[:5]}..." if len(value) > 5 else f"  {key}: {value}")
        else:
            lines.append(f"  {key}: {value}")
    lines.append("")
    
    # Primary outcomes summary
    lines.append("PRIMARY OUTCOMES BY (rho, branch)")
    lines.append("-" * 40)
    
    agg = aggregate_per_rho_branch(data, PRIMARY_OUTCOMES)
    for (rho, branch) in sorted(agg.keys()):
        stats = agg[(rho, branch)]
        cells = []
        for metric in PRIMARY_OUTCOMES:
            if metric in stats:
                s = stats[metric]
                cells.append(f"{s['mean']:.4f}±{s['std']:.4f}")
            else:
                cells.append("N/A")
        lines.append(f"  rho={rho:.2f}, branch={branch:<15} | " + " | ".join(cells))
    lines.append("")
    
    # Sensitivity analysis
    lines.append("SENSITIVITY ANALYSIS (Slope vs rho)")
    lines.append("-" * 40)
    sensitivity = cross_t_metrics.get("sensitivity_slopes", {})
    for metric, stats in sorted(sensitivity.items()):
        if metric in PRIMARY_OUTCOMES:
            lines.append(f"  {metric}: slope={stats.get('slope', float('nan')):.4f}, "
                         f"r²={stats.get('r_squared', float('nan')):.4f}")
    lines.append("")
    
    # Pairwise rho differences
    lines.append("PAIRWISE RHO SIMILARITY DIFFERENCES (continue branch)")
    lines.append("-" * 40)
    pairwise = cross_t_metrics.get("pairwise_rho_similarity_differences", {})
    for (rho1, rho2), stats in sorted(pairwise.items()):
        lines.append(f"  rho={rho1:.2f} vs {rho2:.2f}: mean_diff={stats.get('mean_diff', float('nan')):.4f}, "
                     f"std={stats.get('std_diff', float('nan')):.4f}, n={stats.get('n', 0)}")
    lines.append("")
    
    # Statistical tests
    lines.append("STATISTICAL TESTS (Paired t-tests)")
    lines.append("-" * 40)
    for test_name, stats in sorted(statistical_tests.items()):
        if stats.get("p_value", float('nan')) < 0.05:
            sig = "*"
        else:
            sig = ""
        lines.append(f"  {test_name}{sig}: t={stats.get('t_stat', float('nan')):.4f}, "
                     f"p={stats.get('p_value', float('nan')):.4f}, "
                     f"n={stats.get('n', 0)}")
    lines.append("")
    
    # Branch comparisons
    lines.append("BRANCH COMPARISONS (mean ± std across all rho)")
    lines.append("-" * 40)
    
    agg_branch = aggregate_per_branch(data, PRIMARY_OUTCOMES)
    for branch in STUDY_BRANCHES:
        if branch in agg_branch:
            stats = agg_branch[branch]
            cells = []
            for metric in PRIMARY_OUTCOMES:
                if metric in stats:
                    s = stats[metric]
                    cells.append(f"{s['mean']:.4f}±{s['std']:.4f}")
                else:
                    cells.append("N/A")
            lines.append(f"  {branch:<15} | " + " | ".join(cells))
    lines.append("")
    
    lines.append("=" * 80)
    lines.append("END OF REPORT")
    lines.append("=" * 80)
    
    return "\n".join(lines)


def generate_json_report(
    data: list[dict[str, Any]],
    manifest: dict[str, Any],
    cross_t_metrics: dict[str, Any],
    statistical_tests: dict[str, Any],
) -> dict[str, Any]:
    """Generate machine-readable JSON report."""
    report = {
        "study_name": STUDY_NAME,
        "analysis_version": ANALYSIS_VERSION,
        "timestamp": int(time.time()),
        "manifest": manifest,
        "summary_statistics": {
            "per_rho": aggregate_per_rho(data, CROSS_T_METRICS),
            "per_branch": aggregate_per_branch(data, CROSS_T_METRICS),
            "per_rho_branch": aggregate_per_rho_branch(data, CROSS_T_METRICS),
        },
        "cross_t_metrics": cross_t_metrics,
        "statistical_tests": statistical_tests,
        "primary_outcomes": list(PRIMARY_OUTCOMES),
        "rho_values": list(RHO_VALUES),
        "t_window_values": list(T_WINDOW_VALUES),
        "branches": list(STUDY_BRANCHES),
    }
    
    return report


# =============================================================================
# Visualization Data
# =============================================================================

def prepare_visualization_data(
    data: list[dict[str, Any]],
) -> dict[str, Any]:
    """Prepare data for visualization in a structured format."""
    viz_data = {
        "metadata": {
            "study_name": STUDY_NAME,
            "rho_values": list(RHO_VALUES),
            "t_window_values": list(T_WINDOW_VALUES),
            "branches": list(STUDY_BRANCHES),
            "n_seeds": len(set(r["seed"] for r in data)),
        },
        "line_plots": {},
        "bar_plots": {},
        "scatter_plots": {},
    }
    
    # Line plots: metric vs rho for each branch
    for metric in CROSS_T_METRICS:
        plot_data = {}
        for branch in STUDY_BRANCHES:
            rho_vals = []
            mean_vals = []
            std_vals = []
            
            for rho in RHO_VALUES:
                rho_data = [r for r in data if r["rho"] == rho and r["branch"] == branch]
                vals = [r.get(metric, np.nan) for r in rho_data if metric in r]
                vals = np.array(vals)
                finite = vals[np.isfinite(vals)]
                
                if len(finite) > 0:
                    rho_vals.append(rho)
                    mean_vals.append(float(np.mean(finite)))
                    std_vals.append(float(np.std(finite)))
            
            if rho_vals:
                plot_data[branch] = {
                    "rho": rho_vals,
                    "mean": mean_vals,
                    "std": std_vals,
                }
        
        if plot_data:
            viz_data["line_plots"][metric] = plot_data
    
    # Bar plots: metric by branch for each rho
    for metric in PRIMARY_OUTCOMES:
        plot_data = {}
        for rho in RHO_VALUES:
            branch_means = []
            branch_stds = []
            branch_names = []
            
            for branch in STUDY_BRANCHES:
                rho_branch_data = [r for r in data if r["rho"] == rho and r["branch"] == branch]
                vals = [r.get(metric, np.nan) for r in rho_branch_data if metric in r]
                vals = np.array(vals)
                finite = vals[np.isfinite(vals)]
                
                if len(finite) > 0:
                    branch_names.append(branch)
                    branch_means.append(float(np.mean(finite)))
                    branch_stds.append(float(np.std(finite)))
            
            if branch_names:
                plot_data[f"rho_{rho}"] = {
                    "branch": branch_names,
                    "mean": branch_means,
                    "std": branch_stds,
                }
        
        if plot_data:
            viz_data["bar_plots"][metric] = plot_data
    
    # Scatter plots: pairwise metric comparisons
    for i, metric1 in enumerate(CROSS_T_METRICS[:5]):  # Limit to first 5 for demo
        for metric2 in CROSS_T_METRICS[i+1:]:
            x_vals = []
            y_vals = []
            labels = []
            
            for rho in RHO_VALUES:
                for branch in STUDY_BRANCHES:
                    rho_branch_data = [r for r in data if r["rho"] == rho and r["branch"] == branch]
                    if rho_branch_data:
                        x = np.mean([r.get(metric1, np.nan) for r in rho_branch_data if metric1 in r])
                        y = np.mean([r.get(metric2, np.nan) for r in rho_branch_data if metric2 in r])
                        if np.isfinite(x) and np.isfinite(y):
                            x_vals.append(float(x))
                            y_vals.append(float(y))
                            labels.append(f"rho={rho}, {branch}")
            
            if x_vals:
                viz_data["scatter_plots"][f"{metric1}_vs_{metric2}"] = {
                    "x": x_vals,
                    "y": y_vals,
                    "labels": labels,
                    "x_label": metric1,
                    "y_label": metric2,
                }
    
    return viz_data


# =============================================================================
# Main Execution
# =============================================================================

def parse_arguments() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "run_dir",
        type=str,
        help="run directory containing study outputs",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="output directory for analysis (default: <run_dir>/analysis)",
    )
    parser.add_argument(
        "--csv-only",
        action="store_true",
        help="only output CSV files (no JSON/text reports)",
    )
    parser.add_argument(
        "--json-only",
        action="store_true",
        help="only output JSON report (no text/CSV)",
    )
    parser.add_argument(
        "--viz-data",
        action="store_true",
        help="generate visualization data JSON",
    )
    return parser.parse_args()


def main() -> None:
    """Main entry point."""
    args = parse_arguments()
    
    # Parse run directory
    run_dir, manifest_path, csv_path, npz_path = parse_run_dir(args.run_dir)
    
    # Load data
    print(f"Loading data from {run_dir}...")
    data = load_csv(csv_path)
    manifest = load_manifest(manifest_path)
    npz_data = load_npz(npz_path)
    
    print(f"  Loaded {len(data)} rows from CSV")
    print(f"  Loaded {len(npz_data)} arrays from NPZ")
    
    # Set up output directory
    if args.output is None:
        output_dir = run_dir / "analysis"
    else:
        output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Compute aggregations
    print("\nComputing aggregations...")
    per_rho = aggregate_per_rho(data)
    per_branch = aggregate_per_branch(data)
    per_rho_branch = aggregate_per_rho_branch(data)
    
    # Compute cross-T metrics
    print("Computing cross-T topology metrics...")
    cross_t_metrics = compute_cross_t_metrics(data)
    
    # Compute statistical tests
    print("Computing statistical tests...")
    
    # Define comparisons: (metric, branch1, branch2)
    comparisons = []
    for metric in PRIMARY_OUTCOMES:
        for i, b1 in enumerate(STUDY_BRANCHES):
            for b2 in STUDY_BRANCHES[i+1:]:
                comparisons.append((metric, b1, b2))
    
    try:
        statistical_tests = compute_statistical_tests(data, comparisons)
    except ImportError:
        print("  scipy not available, skipping statistical tests")
        statistical_tests = {}
    
    # Generate reports
    print("\nGenerating reports...")
    
    if not args.json_only:
        # Text report
        text_report = generate_text_report(data, manifest, cross_t_metrics, statistical_tests)
        text_path = output_dir / "report.txt"
        with open(text_path, "w", encoding="utf-8") as f:
            f.write(text_report)
        print(f"  Saved text report to {text_path}")
        
        # Print to console
        print("\n" + "=" * 80)
        print("ANALYSIS REPORT")
        print("=" * 80)
        print(text_report)
    
    if not args.csv_only:
        # JSON report
        json_report = generate_json_report(data, manifest, cross_t_metrics, statistical_tests)
        json_path = output_dir / "report.json"
        save_json(json_path, json_report)
        print(f"  Saved JSON report to {json_path}")
    
    # Aggregated CSV files
    print("\nSaving aggregated data...")
    
    # Per (rho, branch) aggregation
    agg_rows = []
    for (rho, branch), metrics in per_rho_branch.items():
        row = {"rho": rho, "branch": branch}
        for metric, stats in metrics.items():
            row[f"{metric}_mean"] = stats["mean"]
            row[f"{metric}_std"] = stats["std"]
            row[f"{metric}_n"] = stats["n"]
        agg_rows.append(row)
    
    agg_csv_path = output_dir / "aggregated_by_rho_branch.csv"
    save_csv(agg_csv_path, agg_rows)
    print(f"  Saved aggregated data to {agg_csv_path}")
    
    # Per rho aggregation
    rho_agg_rows = []
    for rho, metrics in per_rho.items():
        row = {"rho": rho}
        for metric, stats in metrics.items():
            row[f"{metric}_mean"] = stats["mean"]
            row[f"{metric}_std"] = stats["std"]
        rho_agg_rows.append(row)
    
    rho_csv_path = output_dir / "aggregated_by_rho.csv"
    save_csv(rho_csv_path, rho_agg_rows)
    print(f"  Saved per-rho aggregation to {rho_csv_path}")
    
    # Per branch aggregation
    branch_agg_rows = []
    for branch, metrics in per_branch.items():
        row = {"branch": branch}
        for metric, stats in metrics.items():
            row[f"{metric}_mean"] = stats["mean"]
            row[f"{metric}_std"] = stats["std"]
        branch_agg_rows.append(row)
    
    branch_csv_path = output_dir / "aggregated_by_branch.csv"
    save_csv(branch_csv_path, branch_agg_rows)
    print(f"  Saved per-branch aggregation to {branch_csv_path}")
    
    # Cross-T metrics
    cross_t_path = output_dir / "cross_t_metrics.json"
    save_json(cross_t_path, cross_t_metrics)
    print(f"  Saved cross-T metrics to {cross_t_path}")
    
    # Statistical tests
    if statistical_tests:
        stats_path = output_dir / "statistical_tests.json"
        save_json(stats_path, statistical_tests)
        print(f"  Saved statistical tests to {stats_path}")
    
    # Visualization data
    if args.viz_data:
        print("\nGenerating visualization data...")
        viz_data = prepare_visualization_data(data)
        viz_path = output_dir / "visualization_data.json"
        save_json(viz_path, viz_data)
        print(f"  Saved visualization data to {viz_path}")
    
    print("\n" + "=" * 80)
    print("ANALYSIS COMPLETE")
    print("=" * 80)


if __name__ == "__main__":
    main()
