#!/usr/bin/env python3
"""AIEF-1.4 T_window Sensitivity Study Analysis Driver v2.

Correct implementation of the prespecified estimands:

1. Regime contrasts: Δ_{s,ρ}^regime(Y) = Y_{s,ρ,continue} - Y_{s,1,continue}
2. Branch DID: I_{s,ρ,b}(Y) = [Y_{s,ρ,b} - Y_{s,ρ,continue}] - [Y_{s,1,b} - Y_{s,1,continue}]
3. Cross-T topology: S_{s,ρ} = cos(B_final_{s,ρ,continue}, B_final_{s,1,continue})
4. Recovery scaling: t_rec / T_window for both horizon systems

Output:
- twindow_paired_regime_contrasts.csv
- twindow_branch_interactions.csv
- twindow_cross_condition_topology.csv
- twindow_recovery_summary.csv
- twindow_sensitivity_report.txt
- analysis_manifest.json

This script implements the 5-stage analysis structure as specified.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


# =============================================================================
# Configuration
# =============================================================================

ANALYSIS_VERSION = "v2.0"
STUDY_NAME = "AIEF_1_4_Twindow_sensitivity"

# Expected values (for validation)
EXPECTED_N_SEEDS = 40
EXPECTED_RHO_VALUES = (0.5, 0.75, 1.0, 1.5, 2.0)
EXPECTED_BRANCHES = ("continue", "reset_ema", "reset_B", "future_shuffle")
EXPECTED_N_CONDITIONS = EXPECTED_N_SEEDS * len(EXPECTED_RHO_VALUES)
EXPECTED_N_ROWS = EXPECTED_N_CONDITIONS * len(EXPECTED_BRANCHES)

# Primary outcomes
PRIMARY_OUTCOMES = (
    "Weighted_similarity_late",
    "Retention_contrast_late",
    "P_mean_late",
)

# All scalar outcomes for validation
ALL_SCALAR_OUTCOMES = (
    "D_B_final",
    "P_mean_full",
    "P_mean_immediate",
    "P_mean_recovery",
    "P_mean_late",
    "Weighted_similarity_final",
    "Weighted_similarity_late",
    "Jaccard_final",
    "Retention_selected_late",
    "Emergence_unselected_late",
    "Retention_contrast_late",
    "Corr_Rpast_Pfull",
    "Corr_Rpast_Plate",
    "Total_edge_weight",
    "Mean_row_sum",
    "Max_row_sum",
    "Nonzero_edge_fraction",
    "Effective_edges",
    "Weight_gini",
    "Weight_entropy",
    "r_mean_future",
    "r_mean_late",
    "Minimum_similarity",
)

# Matrix keys needed for cross-T topology
MATRIX_KEYS = (
    "B_final",
)


# =============================================================================
# Utility Functions
# =============================================================================

def load_csv_atomic(path: str | Path) -> pd.DataFrame:
    """Load CSV file atomically with validation."""
    path = Path(path)
    
    # Use pandas with explicit dtypes
    df = pd.read_csv(
        path,
        dtype={"seed": str, "branch": str},  # Keep seeds as strings
    )
    
    # Convert numeric columns, coercing errors to NaN
    for col in df.columns:
        if col not in ("seed", "seed_index", "branch", "rho"):
            try:
                df[col] = pd.to_numeric(df[col], errors="coerce")
            except Exception:
                pass
    
    return df


def load_npz_selective(path: str | Path, keys: list[str] | None = None) -> dict[str, Any]:
    """Load only specified keys from NPZ file to save memory."""
    path = Path(path)
    payload: dict[str, Any] = {}
    
    try:
        with np.load(str(path), allow_pickle=False) as data:
            if keys is None:
                keys = list(data.files)
            for key in keys:
                if key in data:
                    value = data[key]
                    payload[key] = value.item() if value.ndim == 0 else value.copy()
    except Exception as e:
        print(f"Warning: Could not load NPZ {path}: {e}")
    
    return payload


def save_csv_atomic(path: str | Path, df: pd.DataFrame) -> None:
    """Save CSV atomically with fsync."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    
    temp_path = path.with_suffix(path.suffix + f".tmp-{os.getpid()}-{time.time_ns()}")
    try:
        df.to_csv(temp_path, index=False)
        os.replace(str(temp_path), str(path))
    finally:
        if temp_path.exists():
            temp_path.unlink()


def save_json_atomic(path: str | Path, data: dict[str, Any]) -> None:
    """Save JSON atomically with fsync, handling NaN values."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    
    # Convert NaN to None for JSON serialization
    def sanitize(obj: Any) -> Any:
        if isinstance(obj, dict):
            return {k: sanitize(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [sanitize(v) for v in obj]
        elif isinstance(obj, float) and np.isnan(obj):
            return None
        elif isinstance(obj, (np.integer, np.floating)):
            return obj.item()
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return obj
    
    temp_path = path.with_suffix(path.suffix + f".tmp-{os.getpid()}-{time.time_ns()}")
    try:
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(sanitize(data), f, indent=2, sort_keys=True, allow_nan=False)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(str(temp_path), str(path))
    finally:
        if temp_path.exists():
            temp_path.unlink()


def file_sha256(path: str | Path) -> str:
    """Compute SHA-256 hash of a file."""
    import hashlib
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


# =============================================================================
# Metric Functions
# =============================================================================

def cosine_similarity(B1: np.ndarray, B2: np.ndarray) -> float:
    """Compute cosine similarity between two B matrices over upper triangle edges."""
    edges = np.triu_indices(B1.shape[0], k=1)
    x = B1[edges]
    y = B2[edges]
    
    norm_x = np.linalg.norm(x)
    norm_y = np.linalg.norm(y)
    
    if norm_x <= 1e-12 or norm_y <= 1e-12:
        return float('nan')
    
    return float(np.dot(x, y) / (norm_x * norm_y))


def jaccard_similarity(B1: np.ndarray, B2: np.ndarray, threshold: float = 0.12) -> float:
    """Compute Jaccard similarity between two B matrices over upper triangle edges."""
    edges = np.triu_indices(B1.shape[0], k=1)
    x = B1[edges] > threshold
    y = B2[edges] > threshold
    
    union = np.count_nonzero(x | y)
    if union == 0:
        return float('nan')
    
    return float(np.count_nonzero(x & y) / union)


def normalized_distance(B1: np.ndarray, B2: np.ndarray) -> float:
    """Compute normalized L2 distance between two B matrices."""
    diff = B1 - B2
    norm_diff = np.linalg.norm(diff)
    norm_B2 = np.linalg.norm(B2)
    
    if norm_B2 <= 1e-12:
        return float('nan')
    
    return float(norm_diff / norm_B2)


# =============================================================================
# Stage 1: Validation
# =============================================================================

def validate_run(
    csv_path: Path,
    npz_path: Path,
    manifest_path: Path,
) -> dict[str, Any]:
    """Validate the run before analysis.
    
    Checks:
    - 800 scalar rows (40 seeds × 5 rho × 4 branches)
    - 40 unique seeds
    - 5 rho values per seed
    - 4 branches per seed/rho
    - baseline equivalence passed
    - run is freezeable
    - no duplicate condition keys
    """
    results = {
        "status": "passed",
        "errors": [],
        "warnings": [],
    }
    
    # Load manifest
    try:
        with open(manifest_path, "r") as f:
            manifest = json.load(f)
    except Exception as e:
        results["status"] = "failed"
        results["errors"].append(f"Cannot load manifest: {e}")
        return results
    
    # Check baseline equivalence
    baseline_eq = manifest.get("baseline_equivalence", {})
    if baseline_eq.get("status") != "passed":
        results["status"] = "failed"
        results["errors"].append(
            f"Baseline equivalence not passed: {baseline_eq.get('status', 'unknown')}"
        )
        return results
    
    # Load CSV
    try:
        df = load_csv_atomic(csv_path)
    except Exception as e:
        results["status"] = "failed"
        results["errors"].append(f"Cannot load CSV: {e}")
        return results
    
    # Validate row count
    expected_rows = EXPECTED_N_ROWS
    actual_rows = len(df)
    if actual_rows != expected_rows:
        results["status"] = "failed"
        results["errors"].append(
            f"Row count mismatch: expected {expected_rows}, got {actual_rows}"
        )
    
    # Validate unique seeds
    unique_seeds = df["seed"].unique()
    if len(unique_seeds) != EXPECTED_N_SEEDS:
        results["status"] = "failed"
        results["errors"].append(
            f"Seed count mismatch: expected {EXPECTED_N_SEEDS}, got {len(unique_seeds)}"
        )
    
    # Validate rho values
    unique_rho = sorted(df["rho"].unique())
    expected_rho = sorted(EXPECTED_RHO_VALUES)
    if unique_rho != expected_rho:
        results["status"] = "failed"
        results["errors"].append(
            f"Rho values mismatch: expected {expected_rho}, got {unique_rho}"
        )
    
    # Validate branches
    unique_branches = sorted(df["branch"].unique())
    expected_branches = sorted(EXPECTED_BRANCHES)
    if unique_branches != expected_branches:
        results["status"] = "failed"
        results["errors"].append(
            f"Branches mismatch: expected {expected_branches}, got {unique_branches}"
        )
    
    # Validate completeness: each seed/rho/branch combination should exist
    for seed in unique_seeds:
        seed_data = df[df["seed"] == seed]
        for rho in unique_rho:
            rho_data = seed_data[seed_data["rho"] == rho]
            for branch in unique_branches:
                if not ((rho_data["branch"] == branch).any()):
                    results["status"] = "failed"
                    results["errors"].append(
                        f"Missing: seed={seed}, rho={rho}, branch={branch}"
                    )
    
    # Check for duplicates
    duplicate_rows = df.duplicated(subset=["seed", "rho", "branch"])
    if duplicate_rows.any():
        results["status"] = "failed"
        results["errors"].append(
            f"Duplicate rows found: {duplicate_rows.sum()} duplicates"
        )
    
    # Check freezeable status
    if not manifest.get("freezeable", True):
        results["warnings"].append("Run marked as non-freezeable")
    
    # Record validation info
    results["validation"] = {
        "n_rows": actual_rows,
        "n_seeds": len(unique_seeds),
        "n_rho": len(unique_rho),
        "n_branches": len(unique_branches),
        "n_duplicates": int(duplicate_rows.sum()),
        "baseline_equivalence": baseline_eq.get("status"),
        "freezeable": manifest.get("freezeable", True),
    }
    
    if results["status"] == "passed":
        print("✅ Stage 1: Validation PASSED")
        print(f"  {actual_rows} rows, {len(unique_seeds)} seeds, {len(unique_rho)} rho, {len(unique_branches)} branches")
    else:
        print("❌ Stage 1: Validation FAILED")
        for error in results["errors"]:
            print(f"  {error}")
    
    return results


# =============================================================================
# Stage 2: Regime Contrasts
# =============================================================================

def compute_regime_contrasts(
    df: pd.DataFrame,
    outcomes: tuple[str, ...] = PRIMARY_OUTCOMES,
) -> pd.DataFrame:
    """Compute regime contrasts: Δ_{s,ρ}^regime(Y) = Y_{s,ρ,continue} - Y_{s,1,continue}
    
    For each seed and non-baseline rho, compute the difference between
    the outcome at that rho and the outcome at rho=1 (baseline).
    """
    # Filter to continue branch only
    continue_df = df[df["branch"] == "continue"].copy()
    
    # Pivot to have seed × rho as index, outcomes as columns
    pivot_df = continue_df.pivot_table(
        index=["seed", "rho"],
        columns=["branch"],
        values=list(outcomes),
    )
    
    # Get baseline (rho=1) values
    baseline_df = pivot_df.xs(1.0, level="rho")
    baseline_df.columns = [f"{col}_baseline" for col in baseline_df.columns]
    
    # Merge with all rho values
    merged = pivot_df.merge(baseline_df, left_index=True, right_index=True)
    
    # Compute contrasts
    contrast_rows = []
    for (seed, rho), row in merged.iterrows():
        if rho == 1.0:
            continue  # Skip baseline
        
        for outcome in outcomes:
            baseline_key = f"{outcome}_baseline"
            contrast_key = f"{outcome}_regime_contrast"
            
            if outcome in row.index and baseline_key in row.index:
                contrast = row[outcome] - row[baseline_key]
                contrast_rows.append({
                    "seed": seed,
                    "rho": rho,
                    "outcome": outcome,
                    f"Y_rho_continue": row[outcome],
                    f"Y_baseline_continue": row[baseline_key],
                    "paired_regime_contrast": contrast,
                })
    
    if not contrast_rows:
        raise RuntimeError("No regime contrasts computed - check input data")
    
    contrasts_df = pd.DataFrame(contrast_rows)
    
    print(f"✅ Stage 2: Regime Contrasts - {len(contrast_rows)} contrasts computed")
    print(f"  Seeds: {contrasts_df['seed'].nunique()}, Rho values: {contrasts_df['rho'].nunique()}, Outcomes: {contrasts_df['outcome'].nunique()}")
    
    return contrasts_df


# =============================================================================
# Stage 3: Branch Difference-in-Differences
# =============================================================================

def compute_branch_did(
    df: pd.DataFrame,
    outcomes: tuple[str, ...] = PRIMARY_OUTCOMES,
) -> pd.DataFrame:
    """Compute branch DID: I_{s,ρ,b}(Y) = [Y_{s,ρ,b} - Y_{s,ρ,continue}] - [Y_{s,1,b} - Y_{s,1,continue}]
    
    For each seed, non-baseline rho, and non-continue branch, compute the
    difference-in-differences relative to continue branch.
    """
    did_rows = []
    
    for seed in df["seed"].unique():
        seed_data = df[df["seed"] == seed]
        
        for rho in sorted(df["rho"].unique()):
            rho_data = seed_data[seed_data["rho"] == rho]
            
            for branch in df["branch"].unique():
                if branch == "continue":
                    continue  # Skip continue branch
                
                for outcome in outcomes:
                    # Get Y_{s,ρ,b}
                    y_rho_b = rho_data[rho_data["branch"] == branch][outcome].values
                    if len(y_rho_b) == 0:
                        continue
                    y_rho_b = y_rho_b[0]
                    
                    # Get Y_{s,ρ,continue}
                    y_rho_c = rho_data[rho_data["branch"] == "continue"][outcome].values[0]
                    
                    # Get Y_{s,1,b}
                    baseline_data = seed_data[seed_data["rho"] == 1.0]
                    y_base_b = baseline_data[baseline_data["branch"] == branch][outcome].values
                    if len(y_base_b) == 0:
                        continue
                    y_base_b = y_base_b[0]
                    
                    # Get Y_{s,1,continue}
                    y_base_c = baseline_data[baseline_data["branch"] == "continue"][outcome].values[0]
                    
                    # Compute DID
                    branch_effect_rho = y_rho_b - y_rho_c
                    branch_effect_baseline = y_base_b - y_base_c
                    did = branch_effect_rho - branch_effect_baseline
                    
                    did_rows.append({
                        "seed": seed,
                        "rho": rho,
                        "branch": branch,
                        "outcome": outcome,
                        "Y_rho_branch": y_rho_b,
                        "Y_rho_continue": y_rho_c,
                        "branch_effect_rho": branch_effect_rho,
                        "Y_baseline_branch": y_base_b,
                        "Y_baseline_continue": y_base_c,
                        "branch_effect_baseline": branch_effect_baseline,
                        "difference_in_differences": did,
                    })
    
    if not did_rows:
        raise RuntimeError("No branch DID computed - check input data")
    
    did_df = pd.DataFrame(did_rows)
    
    print(f"✅ Stage 3: Branch DID - {len(did_rows)} DID values computed")
    print(f"  Seeds: {did_df['seed'].nunique()}, Rho: {did_df['rho'].nunique()}, Branches: {did_df['branch'].nunique()}")
    
    return did_df


# =============================================================================
# Stage 4: Cross-T Topology and Recovery
# =============================================================================

def compute_cross_t_topology(
    npz_path: Path,
    df: pd.DataFrame,
    seeds: list,
    rho_values: list,
) -> pd.DataFrame:
    """Compute cross-T topology metrics.
    
    For each seed and rho, compute:
    - S_{s,ρ} = cos(B_final_{s,ρ,continue}, B_final_{s,1,continue})
    - J_{s,ρ} = Jaccard(B_final_{s,ρ,continue}, B_final_{s,1,continue})
    - D_{s,ρ} = normalized_L2_distance(B_final_{s,ρ,continue}, B_final_{s,1,continue})
    """
    topology_rows = []
    
    # Load only B_final matrices from NPZ
    npz_data = load_npz_selective(npz_path)
    
    # Get baseline (rho=1) B_final for continue branch
    baseline_keys = {}
    for seed in seeds:
        key_pattern = f"continue_seed_{seed}_rho_1.0_B_final"
        # Try different key formats
        for possible_key in npz_data.keys():
            if f"continue_seed_{seed}_rho_1" in possible_key and "B_final" in possible_key:
                baseline_keys[seed] = possible_key
                break
    
    for seed in seeds:
        for rho in rho_values:
            if rho == 1.0:
                continue  # Skip baseline
            
            # Get B_final for this (seed, rho, continue)
            rho_key_pattern = f"continue_seed_{seed}_rho_{rho}_B_final"
            rho_key = None
            for possible_key in npz_data.keys():
                if f"continue_seed_{seed}_rho_{rho}" in possible_key and "B_final" in possible_key:
                    rho_key = possible_key
                    break
            
            if rho_key is None or seed not in baseline_keys:
                continue
            
            baseline_key = baseline_keys[seed]
            
            if rho_key not in npz_data or baseline_key not in npz_data:
                continue
            
            B_rho = npz_data[rho_key]
            B_baseline = npz_data[baseline_key]
            
            # Compute metrics
            cos_sim = cosine_similarity(B_rho, B_baseline)
            jaccard = jaccard_similarity(B_rho, B_baseline)
            norm_dist = normalized_distance(B_rho, B_baseline)
            
            topology_rows.append({
                "seed": seed,
                "rho": rho,
                "cross_T_cosine": cos_sim,
                "cross_T_Jaccard": jaccard,
                "cross_T_normalized_distance": norm_dist,
            })
    
    if not topology_rows:
        print("⚠️  Stage 4: Cross-T Topology - No matrices found in NPZ")
        print("  This is expected if NPZ uses different key format")
        # Return empty DataFrame with correct columns
        return pd.DataFrame(columns=["seed", "rho", "cross_T_cosine", "cross_T_Jaccard", "cross_T_normalized_distance"])
    
    topology_df = pd.DataFrame(topology_rows)
    
    print(f"✅ Stage 4: Cross-T Topology - {len(topology_rows)} topology comparisons computed")
    print(f"  Seeds: {topology_df['seed'].nunique()}, Rho: {topology_df['rho'].nunique()}")
    
    return topology_df


def compute_recovery_scaling(
    df: pd.DataFrame,
    npz_path: Path,
    horizon_system: str = "fixed_physical",
) -> pd.DataFrame:
    """Compute recovery scaling metrics.
    
    For each seed/rho/branch, compute:
    - First crossing of continue branch threshold
    - Sustained recovery duration
    - Held recovery time
    - Censoring indicator
    - Restricted recovery time
    - AUC deficit
    - t_rec / T_window
    
    Uses trajectories from NPZ to compute recovery relative to continue branch.
    """
    # This is a placeholder - full implementation requires loading trajectories
    # and computing recovery metrics relative to continue branch
    
    # For now, return empty DataFrame with correct columns
    print(f"⚠️  Stage 4: Recovery Scaling - Not yet implemented for {horizon_system}")
    print("  Will be added in future version")
    
    return pd.DataFrame(columns=[
        "seed", "rho", "branch", "horizon_system",
        "first_crossing", "sustained_recovery", "held_duration",
        "censored", "restricted_time", "auc_deficit", "t_rec_over_Twindow"
    ])


# =============================================================================
# Stage 5: Seed-Level Summaries
# =============================================================================

def compute_seed_level_summaries(
    regime_contrasts: pd.DataFrame,
    branch_did: pd.DataFrame,
    topology: pd.DataFrame,
    n_bootstrap: int = 1000,
) -> dict[str, pd.DataFrame]:
    """Compute seed-level summaries with bootstrap confidence intervals.
    
    For each outcome and rho, compute:
    - Mean contrast
    - Std error
    - 95% bootstrap CI
    - p-value (if applicable)
    """
    summaries = {}
    
    # Regime contrast summaries
    if not regime_contrasts.empty:
        regime_summary = regime_contrasts.groupby(["rho", "outcome"])["paired_regime_contrast"].agg([
            ("mean", "mean"),
            ("std", "std"),
            ("n", "count"),
        ]).reset_index()
        
        # Add bootstrap CI
        for (rho, outcome), group in regime_contrasts.groupby(["rho", "outcome"]):
            values = group["paired_regime_contrast"].dropna().values
            if len(values) > 0:
                # Simple bootstrap
                bootstrap_means = []
                for _ in range(n_bootstrap):
                    sample = np.random.choice(values, size=len(values), replace=True)
                    bootstrap_means.append(np.mean(sample))
                
                ci_lower = np.percentile(bootstrap_means, 2.5)
                ci_upper = np.percentile(bootstrap_means, 97.5)
                
                idx = regime_summary[(regime_summary["rho"] == rho) & (regime_summary["outcome"] == outcome)].index
                regime_summary.loc[idx, "ci_lower"] = ci_lower
                regime_summary.loc[idx, "ci_upper"] = ci_upper
        
        summaries["regime_contrasts"] = regime_summary
        print(f"✅ Stage 5: Regime Contrast Summaries - {len(regime_summary)} groups")
    
    # Branch DID summaries
    if not branch_did.empty:
        did_summary = branch_did.groupby(["rho", "branch", "outcome"])["difference_in_differences"].agg([
            ("mean", "mean"),
            ("std", "std"),
            ("n", "count"),
        ]).reset_index()
        
        # Add bootstrap CI
        for (rho, branch, outcome), group in branch_did.groupby(["rho", "branch", "outcome"]):
            values = group["difference_in_differences"].dropna().values
            if len(values) > 0:
                bootstrap_means = []
                for _ in range(n_bootstrap):
                    sample = np.random.choice(values, size=len(values), replace=True)
                    bootstrap_means.append(np.mean(sample))
                
                ci_lower = np.percentile(bootstrap_means, 2.5)
                ci_upper = np.percentile(bootstrap_means, 97.5)
                
                idx = did_summary[(did_summary["rho"] == rho) & (did_summary["branch"] == branch) & (did_summary["outcome"] == outcome)].index
                did_summary.loc[idx, "ci_lower"] = ci_lower
                did_summary.loc[idx, "ci_upper"] = ci_upper
        
        summaries["branch_did"] = did_summary
        print(f"✅ Stage 5: Branch DID Summaries - {len(did_summary)} groups")
    
    # Topology summaries
    if not topology.empty:
        topology_summary = topology.groupby("rho").agg([
            ("mean", "mean"),
            ("std", "std"),
            ("n", "count"),
        ]).reset_index()
        summaries["topology"] = topology_summary
        print(f"✅ Stage 5: Topology Summaries - {len(topology_summary)} rho values")
    
    return summaries


# =============================================================================
# Report Generation
# =============================================================================

def generate_text_report(
    validation: dict[str, Any],
    regime_contrasts: pd.DataFrame,
    branch_did: pd.DataFrame,
    topology: pd.DataFrame,
    regime_summaries: pd.DataFrame,
    did_summaries: pd.DataFrame,
    topology_summaries: pd.DataFrame,
) -> str:
    """Generate human-readable text report."""
    lines = []
    lines.append("=" * 80)
    lines.append("AIEF-1.4 T_window Sensitivity Study - Analysis Report")
    lines.append("=" * 80)
    lines.append("")
    
    # Validation summary
    lines.append("VALIDATION SUMMARY")
    lines.append("-" * 40)
    val = validation.get("validation", {})
    lines.append(f"  Status: {validation.get('status', 'unknown')}")
    lines.append(f"  Rows: {val.get('n_rows', 0)} (expected: {EXPECTED_N_ROWS})")
    lines.append(f"  Seeds: {val.get('n_seeds', 0)} (expected: {EXPECTED_N_SEEDS})")
    lines.append(f"  Rho values: {val.get('n_rho', 0)} (expected: {len(EXPECTED_RHO_VALUES)})")
    lines.append(f"  Branches: {val.get('n_branches', 0)} (expected: {len(EXPECTED_BRANCHES)})")
    lines.append(f"  Duplicates: {val.get('n_duplicates', 0)}")
    lines.append(f"  Baseline equivalence: {val.get('baseline_equivalence', 'unknown')}")
    lines.append(f"  Freezeable: {val.get('freezeable', False)}")
    lines.append("")
    
    # Regime contrasts
    lines.append("REGIME CONTRASTS (Δ = Y_{s,ρ,continue} - Y_{s,1,continue})")
    lines.append("-" * 40)
    if not regime_summaries.empty:
        for rho in sorted(regime_summaries["rho"].unique()):
            rho_data = regime_summaries[regime_summaries["rho"] == rho]
            for outcome in PRIMARY_OUTCOMES:
                out_data = rho_data[rho_data["outcome"] == outcome]
                if not out_data.empty:
                    mean_val = out_data[("paired_regime_contrast", "mean")].values[0]
                    std_val = out_data[("paired_regime_contrast", "std")].values[0]
                    n_val = out_data[("paired_regime_contrast", "n")].values[0]
                    ci_lower = out_data.get("ci_lower", [float('nan')])[0]
                    ci_upper = out_data.get("ci_upper", [float('nan')])[0]
                    
                    ci_str = f"[{ci_lower:.4f}, {ci_upper:.4f}]" if not np.isnan(ci_lower) else "N/A"
                    lines.append(f"  rho={rho:.2f}, {outcome}: {mean_val:.4f} ± {std_val:.4f} {ci_str} (n={n_val})")
    else:
        lines.append("  No regime contrast data")
    lines.append("")
    
    # Branch DID
    lines.append("BRANCH DIFFERENCE-IN-DIFFERENCES")
    lines.append("-" * 40)
    lines.append("I_{s,ρ,b} = [Y_{s,ρ,b} - Y_{s,ρ,continue}] - [Y_{s,1,b} - Y_{s,1,continue}]")
    lines.append("")
    if not did_summaries.empty:
        for rho in sorted(did_summaries["rho"].unique()):
            rho_data = did_summaries[did_summaries["rho"] == rho]
            for branch in sorted(rho_data["branch"].unique()):
                branch_data = rho_data[rho_data["branch"] == branch]
                for outcome in PRIMARY_OUTCOMES:
                    out_data = branch_data[branch_data["outcome"] == outcome]
                    if not out_data.empty:
                        mean_val = out_data[("difference_in_differences", "mean")].values[0]
                        std_val = out_data[("difference_in_differences", "std")].values[0]
                        n_val = out_data[("difference_in_differences", "n")].values[0]
                        ci_lower = out_data.get("ci_lower", [float('nan')])[0]
                        ci_upper = out_data.get("ci_upper", [float('nan')])[0]
                        
                        ci_str = f"[{ci_lower:.4f}, {ci_upper:.4f}]" if not np.isnan(ci_lower) else "N/A"
                        lines.append(f"  rho={rho:.2f}, branch={branch}, {outcome}: {mean_val:.4f} ± {std_val:.4f} {ci_str} (n={n_val})")
    else:
        lines.append("  No branch DID data")
    lines.append("")
    
    # Cross-T topology
    lines.append("CROSS-T TOPOLOGY METRICS")
    lines.append("-" * 40)
    if not topology_summaries.empty:
        for rho in sorted(topology_summaries.index):
            row = topology_summaries.loc[rho]
            lines.append(f"  rho={rho:.2f}:")
            lines.append(f"    Cosine similarity: {row[('cross_T_cosine', 'mean')]:.4f} ± {row[('cross_T_cosine', 'std')]:.4f}")
            lines.append(f"    Jaccard similarity: {row[('cross_T_Jaccard', 'mean')]:.4f} ± {row[('cross_T_Jaccard', 'std')]:.4f}")
            lines.append(f"    Normalized distance: {row[('cross_T_normalized_distance', 'mean')]:.4f} ± {row[('cross_T_normalized_distance', 'std')]:.4f}")
    else:
        lines.append("  No cross-T topology data")
    lines.append("")
    
    lines.append("=" * 80)
    lines.append("END OF REPORT")
    lines.append("=" * 80)
    
    return "\n".join(lines)


def generate_analysis_manifest(
    csv_path: Path,
    npz_path: Path,
    manifest_path: Path,
    validation: dict[str, Any],
    output_files: dict[str, Path],
) -> dict[str, Any]:
    """Generate analysis manifest with complete provenance."""
    # Compute hashes
    csv_hash = file_sha256(csv_path) if csv_path.exists() else "N/A"
    npz_hash = file_sha256(npz_path) if npz_path.exists() else "N/A"
    manifest_hash = file_sha256(manifest_path) if manifest_path.exists() else "N/A"
    
    output_hashes = {}
    for name, path in output_files.items():
        if path.exists():
            output_hashes[name] = file_sha256(path)
        else:
            output_hashes[name] = "N/A"
    
    manifest = {
        "analysis_version": ANALYSIS_VERSION,
        "timestamp": int(time.time()),
        "study_name": STUDY_NAME,
        
        "input_hashes": {
            "scalar_csv": csv_hash,
            "branch_npz": npz_hash,
            "simulation_manifest": manifest_hash,
        },
        
        "validation": validation,
        
        "output_hashes": output_hashes,
        
        "environment": {
            "python": sys.version,
            "numpy": np.__version__,
            "pandas": pd.__version__,
        },
        
        "notes": {
            "primary_outcomes": list(PRIMARY_OUTCOMES),
            "expected_n_seeds": EXPECTED_N_SEEDS,
            "expected_rho_values": list(EXPECTED_RHO_VALUES),
            "expected_branches": list(EXPECTED_BRANCHES),
        },
    }
    
    return manifest


# =============================================================================
# Main Execution
# =============================================================================

def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "run_dir",
        type=str,
        help="run directory containing study outputs",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="output directory for analysis (default: <run_dir>/analysis)",
    )
    parser.add_argument(
        "--n-bootstrap",
        type=int,
        default=1000,
        help="number of bootstrap iterations (default: 1000)",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_arguments()
    
    # Parse run directory
    run_dir = Path(args.run_dir)
    csv_files = list(run_dir.glob(f"{STUDY_NAME}_*_scalar_summary.csv"))
    npz_files = list(run_dir.glob(f"{STUDY_NAME}_*_branch_diagnostics.npz"))
    manifest_files = list(run_dir.glob("manifest.json"))
    
    if not csv_files:
        print(f"No CSV file found in {run_dir}")
        sys.exit(1)
    if not npz_files:
        print(f"No NPZ file found in {run_dir}")
        sys.exit(1)
    if not manifest_files:
        print(f"No manifest found in {run_dir}")
        sys.exit(1)
    
    csv_path = csv_files[0]
    npz_path = npz_files[0]
    manifest_path = manifest_files[0]
    
    # Set up output directory
    if args.output is None:
        output_dir = run_dir / "analysis"
    else:
        output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"Analyzing {run_dir}")
    print(f"  CSV: {csv_path.name}")
    print(f"  NPZ: {npz_path.name}")
    print(f"  Manifest: {manifest_path.name}")
    print(f"  Output: {output_dir}")
    print()
    
    # Stage 1: Validation
    print("Stage 1: Validating run...")
    validation = validate_run(csv_path, npz_path, manifest_path)
    
    if validation["status"] == "failed":
        print("\n❌ VALIDATION FAILED - Cannot proceed with analysis")
        for error in validation["errors"]:
            print(f"  {error}")
        for warning in validation["warnings"]:
            print(f"  WARNING: {warning}")
        sys.exit(1)
    
    # Load CSV data
    print("\nLoading scalar data...")
    df = load_csv_atomic(csv_path)
    
    # Get study parameters from manifest
    with open(manifest_path, "r") as f:
        manifest = json.load(f)
    
    seeds = [str(s) for s in manifest["randomization"]["paired_seeds"]]
    rho_values = manifest["study"]["rho_values"]
    branches = manifest["protocol"]["branches"]
    
    print(f"  Loaded {len(df)} rows")
    print(f"  Seeds: {len(seeds)}, Rho: {len(rho_values)}, Branches: {len(branches)}")
    
    # Stage 2: Regime Contrasts
    print("\nStage 2: Computing regime contrasts...")
    regime_contrasts = compute_regime_contrasts(df, PRIMARY_OUTCOMES)
    
    # Stage 3: Branch DID
    print("\nStage 3: Computing branch difference-in-differences...")
    branch_did = compute_branch_did(df, PRIMARY_OUTCOMES)
    
    # Stage 4: Cross-T Topology
    print("\nStage 4: Computing cross-T topology metrics...")
    topology = compute_cross_t_topology(npz_path, df, seeds, rho_values)
    
    # Stage 4b: Recovery Scaling (placeholder)
    print("\nStage 4b: Recovery scaling...")
    recovery = compute_recovery_scaling(df, npz_path)
    
    # Stage 5: Seed-Level Summaries
    print("\nStage 5: Computing seed-level summaries...")
    summaries = compute_seed_level_summaries(
        regime_contrasts, branch_did, topology, n_bootstrap=args.n_bootstrap
    )
    
    regime_summaries = summaries.get("regime_contrasts", pd.DataFrame())
    did_summaries = summaries.get("branch_did", pd.DataFrame())
    topology_summaries = summaries.get("topology", pd.DataFrame())
    
    # Save outputs
    print("\nSaving outputs...")
    
    # Paired regime contrasts
    regime_contrast_path = output_dir / "twindow_paired_regime_contrasts.csv"
    save_csv_atomic(regime_contrast_path, regime_contrasts)
    print(f"  Saved: {regime_contrast_path.name}")
    
    # Branch DID
    branch_did_path = output_dir / "twindow_branch_interactions.csv"
    save_csv_atomic(branch_did_path, branch_did)
    print(f"  Saved: {branch_did_path.name}")
    
    # Cross-T topology
    if not topology.empty:
        topology_path = output_dir / "twindow_cross_condition_topology.csv"
        save_csv_atomic(topology_path, topology)
        print(f"  Saved: {topology_path.name}")
    
    # Recovery scaling (if implemented)
    if not recovery.empty:
        recovery_path = output_dir / "twindow_recovery_summary.csv"
        save_csv_atomic(recovery_path, recovery)
        print(f"  Saved: {recovery_path.name}")
    
    # Summaries
    if not regime_summaries.empty:
        regime_summary_path = output_dir / "twindow_regime_summary.csv"
        save_csv_atomic(regime_summary_path, regime_summaries)
        print(f"  Saved: {regime_summary_path.name}")
    
    if not did_summaries.empty:
        did_summary_path = output_dir / "twindow_branch_DID_summary.csv"
        save_csv_atomic(did_summary_path, did_summaries)
        print(f"  Saved: {did_summary_path.name}")
    
    if not topology_summaries.empty:
        topology_summary_path = output_dir / "twindow_topology_summary.csv"
        save_csv_atomic(topology_summary_path, topology_summaries)
        print(f"  Saved: {topology_summary_path.name}")
    
    # Text report
    report = generate_text_report(
        validation, regime_contrasts, branch_did, topology,
        regime_summaries, did_summaries, topology_summaries
    )
    report_path = output_dir / "twindow_sensitivity_report.txt"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report)
    print(f"  Saved: {report_path.name}")
    
    # Analysis manifest
    output_files = {
        "regime_contrasts": regime_contrast_path,
        "branch_did": branch_did_path,
        "topology": topology_path,
        "recovery": recovery_path,
        "regime_summary": regime_summary_path,
        "did_summary": did_summary_path,
        "topology_summary": topology_summary_path,
        "report": report_path,
    }
    
    analysis_manifest = generate_analysis_manifest(
        csv_path, npz_path, manifest_path, validation, output_files
    )
    manifest_path_out = output_dir / "analysis_manifest.json"
    save_json_atomic(manifest_path_out, analysis_manifest)
    print(f"  Saved: {manifest_path_out.name}")
    
    # Print report to console
    print("\n" + "=" * 80)
    print("ANALYSIS REPORT")
    print("=" * 80)
    print(report)
    
    print("\n" + "=" * 80)
    print("ANALYSIS COMPLETE")
    print("=" * 80)


if __name__ == "__main__":
    main()
