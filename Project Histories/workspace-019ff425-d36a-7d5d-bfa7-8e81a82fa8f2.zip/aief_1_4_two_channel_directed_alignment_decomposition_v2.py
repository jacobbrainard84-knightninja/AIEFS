#!/usr/bin/env python3
"""Two-channel directed alignment decomposition for K3 resonance ordering.

This script audits the positivity and decay of the directed magnitude differences:

    D_L^->   = |C^+_{2,7}|  - |C^+_{7,11}|   (fixed-left, forward)
    D_L^<-   = |C^+_{7,2}|  - |C^+_{11,7}|   (fixed-left, reverse)
    
    D_R^->   = |C^+_{7,11}| - |C^+_{2,11}|   (right-mode, forward)
    D_R^<-   = |C^+_{11,7}| - |C^+_{11,2}|   (right-mode, reverse)

For each channel and orientation, it computes:
1. Directed magnitude-difference signs
2. Symmetrization index I_sym = |D^-> + D^<-| / (|D^->| + |D^<-|)
3. Radial forcing reinforcement: sign(alpha * DeltaM_n) vs sign(alpha * (1-alpha) * e_n)
4. Exact residual e_n = 2*DeltaA_n - DeltaM_n
5. Exact decomposition e_n = T_1,n + T_2,n (verified identity)
6. Exact radial identity: DeltaM_{n+1} = alpha * DeltaM_n + alpha * (1-alpha) * e_n
7. Decay rates and signs of T_1, T_2, e, D
8. Cancellation index |T_1 + T_2| / (|T_1| + |T_2|)
9. Delayed phase-balance contributions (domega, dG, dh decomposition)
10. T_1/T_2 -> -1 mechanism verification

Edge definitions (K3 subgraph):
    Edge 25: directed edges (2,7) and (7,2)
    Edge 29: directed edges (2,11) and (11,2)
    Edge 59: directed edges (7,11) and (11,7)

Resonance ordering target: R_25,n > R_59,n > R_29,n at every saved step.

Unwrapping convention: np.unwrap with discont=pi (radians).

Reference: AIEF_1_4_FORWARD_PLAN.md, Section 3
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

# Local imports - SHA-256 hashes recorded in manifest
import AIEF_1_4_stationarity_perturbation_analysis_updated as base
import AIEF_1_4_component_controller_audit as component_audit
import AIEF_1_4_augmented_tangent_cocycle_analysis as augmented

# === Constants ===
DEFAULT_RUN_HASH = "5a9f093a2fe0"
DEFAULT_NPZ = (
    f"runs/{DEFAULT_RUN_HASH}/AIEF_1_4_{DEFAULT_RUN_HASH}_branch_diagnostics.npz"
)
DEFAULT_MANIFEST = f"runs/{DEFAULT_RUN_HASH}/manifest.json"
DEFAULT_OUTPUT_DIR = "aief_1_4_two_channel_alignment_v2"
DEFAULT_SEED = "4619122171158768524"
DEFAULT_DT = 0.01
DEFAULT_SCALE_EPSILON = 1e-12
DEFAULT_INTERVALS = "0,50,100,150,200,250,300,320"
DEFAULT_SIGNAL_FLOOR = 1e-14
ZERO_TOL = 1e-300
UNWRAP_DISCONT = np.pi

# === K3 Configuration ===
K3_NODES = (2, 7, 11)

# Edge index -> (node_i, node_j) for undirected edges
K3_EDGES = {
    25: (2, 7),
    29: (2, 11),
    59: (7, 11),
}

# === Channel Definitions ===
# Each channel has forward and reverse directed orientations
# Each orientation uses specific directed edge pairs
CHANNELS = {
    "fixed_left": {
        "description": "Edge 25 vs Edge 59",
        "forward": {
            "edge_a": (2, 7),   # C^+_{2,7}
            "edge_b": (7, 11),  # C^+_{7,11}
        },
        "reverse": {
            "edge_a": (7, 2),   # C^+_{7,2}
            "edge_b": (11, 7),  # C^+_{11,7}
        },
    },
    "right_mode": {
        "description": "Edge 59 vs Edge 29",
        "forward": {
            "edge_a": (7, 11),  # C^+_{7,11}
            "edge_b": (2, 11),  # C^+_{2,11}
        },
        "reverse": {
            "edge_a": (11, 7),  # C^+_{11,7}
            "edge_b": (11, 2),  # C^+_{11,2}
        },
    },
}

ORIENTATIONS = ["forward", "reverse"]


# =============================================================================
# Utility Functions
# =============================================================================

def file_sha256(path: str | os.PathLike[str]) -> str:
    """Compute SHA-256 hash of a file."""
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def compute_module_sha256(module: Any) -> str:
    """Compute SHA-256 hash of a module's source file."""
    path = Path(module.__file__).resolve()
    return file_sha256(path)


def parse_nonnegative_float_list(value: str) -> list[float]:
    """Parse comma-separated nonnegative floats."""
    try:
        values = [float(x.strip()) for x in value.split(",") if x.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("expected comma-separated floats") from exc
    if not values or any(v < 0.0 for v in values):
        raise argparse.ArgumentTypeError("values must be nonnegative")
    result = sorted(set(values))
    if not result:
        raise argparse.ArgumentTypeError(
            "at least one unique nonnegative value required"
        )
    return result


def fit_log_rate(times: np.ndarray, values: np.ndarray, floor: float) -> dict[str, float]:
    """Fit exponential decay rate from log magnitudes."""
    magnitudes = np.abs(np.asarray(values, dtype=float))
    valid = np.isfinite(magnitudes) & (magnitudes > floor)
    if np.sum(valid) < 3:
        return {"rate": np.nan, "R_squared": np.nan, "count": int(np.sum(valid))}
    x = np.asarray(times, dtype=float)[valid]
    y = np.log(magnitudes[valid])
    slope, intercept = np.polyfit(x, y, 1)
    prediction = slope * x + intercept
    residual = float(np.sum((y - prediction) ** 2))
    total = float(np.sum((y - np.mean(y)) ** 2))
    return {
        "rate": float(-slope),
        "R_squared": float(1.0 - residual / total) if total > 0.0 else np.nan,
        "count": int(len(x)),
    }


def channel_quantities(
    C_a: complex,
    C_b: complex,
    Z_a: complex,
    Z_b: complex,
) -> dict[str, Any]:
    """Compute channel quantities for a directed edge pair (a, b).
    
    Uses OLD coherence (C_a, C_b) for alignment quantities.
    
    Returns:
        DeltaC: C_a - C_b
        DeltaZ: Z_a - Z_b
        E: DeltaZ - DeltaC
        DeltaM: |C_a|^2 - |C_b|^2
        DeltaA: Re(conj(C_a)*Z_a) - Re(conj(C_b)*Z_b)
        T1: 2 * Re(conj(Cbar) * E) where Cbar = 0.5*(C_a + C_b)
        T2: 2 * Re(conj(DeltaC) * Zbar) where Zbar = 0.5*(Z_a + Z_b)
        alignment_residual: 2*DeltaA - DeltaM (= T1 + T2, exact identity)
    """
    Cbar = 0.5 * (C_a + C_b)
    Zbar = 0.5 * (Z_a + Z_b)
    DeltaC = C_a - C_b
    DeltaZ = Z_a - Z_b
    E = DeltaZ - DeltaC
    
    DeltaM = float(abs(C_a) ** 2 - abs(C_b) ** 2)
    DeltaA = float(
        np.real(np.conj(C_a) * Z_a) - np.real(np.conj(C_b) * Z_b)
    )
    
    T1 = float(2.0 * np.real(np.conj(Cbar) * E))
    T2 = float(2.0 * np.real(np.conj(DeltaC) * Zbar))
    
    return {
        "DeltaC": DeltaC,
        "DeltaZ": DeltaZ,
        "E": E,
        "DeltaM": DeltaM,
        "DeltaA": DeltaA,
        "T1": T1,
        "T2": T2,
        "alignment_residual": 2.0 * DeltaA - DeltaM,
    }


def count_sign_changes(arr: np.ndarray, tol: float = 1e-12) -> tuple[int, int, int]:
    """Count sign changes in array.
    
    Returns (positive_count, negative_count, change_count).
    Only counts values with |arr| > tol.
    """
    valid = np.abs(arr) > tol
    signs = np.sign(arr)
    
    positive_count = int(np.sum((signs > 0) & valid))
    negative_count = int(np.sum((signs < 0) & valid))
    
    # Count transitions between positive and negative
    changes = 0
    prev_sign = signs[0] if valid[0] else 0
    for i in range(1, len(arr)):
        if valid[i] and valid[i-1]:
            if (signs[i] > 0 and prev_sign < 0) or (signs[i] < 0 and prev_sign > 0):
                changes += 1
        if valid[i]:
            prev_sign = signs[i]
    
    return positive_count, negative_count, changes


# =============================================================================
# Validation Functions
# =============================================================================

def validate_manifest_structure(manifest: dict[str, Any]) -> None:
    """Validate manifest has required keys."""
    required_model_keys = {"dt", "T_window", "a", "delta", "q", "N", "omega"}
    if "model" not in manifest:
        raise ValueError("manifest missing 'model' key")
    if not required_model_keys.issubset(manifest["model"].keys()):
        missing = required_model_keys - set(manifest["model"].keys())
        raise ValueError(f"model missing keys: {missing}")
    if "protocol" not in manifest or "future_steps" not in manifest.get("protocol", {}):
        raise ValueError("manifest missing protocol.future_steps")


def validate_npz_keys(data: Any, seed: str) -> None:
    """Validate NPZ file has required keys."""
    required_keys = {base.branch_key("continue", seed, "B_final")}
    available = set(data.files)
    missing = required_keys - available
    if missing:
        raise ValueError(f"NPZ missing keys: {missing}")


def validate_state(state: Any, N: int) -> None:
    """Validate state object has required attributes and shapes."""
    if not hasattr(state, "coherence_acc"):
        raise ValueError("state missing coherence_acc")
    if not hasattr(state, "B"):
        raise ValueError("state missing B")
    if not hasattr(state, "history"):
        raise ValueError("state missing history")
    
    # coherence_acc is N x N matrix
    if state.coherence_acc.shape != (N, N):
        raise ValueError(
            f"state.coherence_acc shape {state.coherence_acc.shape} != (N, N) = ({N}, {N})"
        )
    if state.B.shape != (N, N):
        raise ValueError(f"state.B shape {state.B.shape} != (N, N)")


def validate_intermediate(intermediate: dict[str, Any], N: int) -> None:
    """Validate intermediate dict has required keys and shapes."""
    required_keys = {"phase_factor", "updated_coherence", "R", "coupling"}
    if not required_keys.issubset(intermediate.keys()):
        missing = required_keys - set(intermediate.keys())
        raise ValueError(f"intermediate missing keys: {missing}")
    
    if intermediate["phase_factor"].shape != (N, N):
        raise ValueError(
            f"phase_factor shape {intermediate['phase_factor'].shape} != (N, N)"
        )
    if intermediate["updated_coherence"].shape != (N, N):
        raise ValueError(
            f"updated_coherence shape {intermediate['updated_coherence'].shape} != (N, N)"
        )
    if intermediate["R"].shape != (N, N):
        raise ValueError(f"R shape {intermediate['R'].shape} != (N, N)")
    if intermediate["coupling"].shape != (N,):
        raise ValueError(f"coupling shape {intermediate['coupling'].shape} != (N,)")


def validate_edge_indexing(edges: list[tuple[int, int]]) -> None:
    """Validate that edge indices match expected K3 edges."""
    edge_map = {e_idx: (i, j) for e_idx, (i, j) in enumerate(edges)}
    
    for e_idx, expected_nodes in K3_EDGES.items():
        if e_idx not in edge_map:
            raise ValueError(f"Edge {e_idx} not found in edge list")
        actual_nodes = edge_map[e_idx]
        if actual_nodes != expected_nodes:
            raise ValueError(
                f"Edge {e_idx}: expected {expected_nodes}, got {actual_nodes}"
            )


def validate_fixed_branch(
    state: Any,
    model: dict[str, Any],
    capacities: np.ndarray,
    scale_epsilon: float,
) -> dict[str, Any]:
    """Validate fixed branch conditions. Returns dict of branch metrics."""
    N = len(capacities)
    B = state.B
    
    # Check B is nonnegative
    b_nonnegative = bool(np.all(B >= -1e-14))
    
    # Check symmetry
    b_symmetric = bool(np.max(np.abs(B - B.T)) < 1e-14)
    
    # Check zero diagonal
    b_diagonal_zero = bool(np.max(np.abs(np.diag(B))) < 1e-14)
    
    # Compute row sums
    row_sums = np.sum(B, axis=1)
    
    # Check capacities
    capacity_violations = row_sums > capacities + scale_epsilon
    
    # K3 node rows
    k3_row_sums = row_sums[list(K3_NODES)].tolist()
    
    # Winner map for K3: for each edge, which node wins
    # Since B is symmetric, B[i,j] = B[j,i], so we need to check the proposal
    # But we don't have proposal here, so just report B values
    k3_B_values = {
        "B_2_7": float(B[2, 7]),
        "B_2_11": float(B[2, 11]),
        "B_7_11": float(B[7, 11]),
    }
    
    return {
        "b_nonnegative": b_nonnegative,
        "b_symmetric": b_symmetric,
        "b_diagonal_zero": b_diagonal_zero,
        "row_sums": row_sums.tolist(),
        "capacity_violations": capacity_violations.tolist(),
        "k3_row_sums": k3_row_sums,
        "k3_B_values": k3_B_values,
    }


def test_alignment_identity(
    e_values: np.ndarray,
    T1_values: np.ndarray,
    T2_values: np.ndarray,
    tol: float = 1e-14,
) -> dict[str, float]:
    """Test the exact identity e_n = T_1,n + T_2,n."""
    e = np.asarray(e_values, dtype=float)
    T1 = np.asarray(T1_values, dtype=float)
    T2 = np.asarray(T2_values, dtype=float)
    
    if len(e) != len(T1) or len(e) != len(T2):
        raise ValueError(f"Length mismatch: e={len(e)}, T1={len(T1)}, T2={len(T2)}")
    
    errors = np.abs(e - (T1 + T2))
    return {
        "max_abs_error": float(np.max(errors)),
        "median_abs_error": float(np.median(errors)),
        "identity_passes": float(np.max(errors)) < tol,
    }


def test_radial_identity(
    DeltaM_old: np.ndarray,
    DeltaM_new: np.ndarray,
    e_values: np.ndarray,
    alpha: float,
    tol: float = 1e-14,
) -> dict[str, float]:
    """Test the exact radial identity: DeltaM_{n+1} = alpha * DeltaM_n + alpha * (1-alpha) * e_n."""
    DeltaM_old = np.asarray(DeltaM_old, dtype=float)
    DeltaM_new = np.asarray(DeltaM_new, dtype=float)
    e = np.asarray(e_values, dtype=float)
    
    if len(DeltaM_old) != len(DeltaM_new) or len(DeltaM_old) != len(e):
        raise ValueError(
            f"Length mismatch: DeltaM_old={len(DeltaM_old)}, "
            f"DeltaM_new={len(DeltaM_new)}, e={len(e)}"
        )
    
    prediction = alpha * DeltaM_old + alpha * (1.0 - alpha) * e
    errors = np.abs(DeltaM_new - prediction)
    
    return {
        "max_abs_error": float(np.max(errors)),
        "median_abs_error": float(np.median(errors)),
        "identity_passes": float(np.max(errors)) < tol,
    }


# =============================================================================
# Report Generation
# =============================================================================

def make_report(
    channel_summary: pd.DataFrame,
    identity_checks: pd.DataFrame,
    trajectory: pd.DataFrame,
    branch_metrics: dict[str, Any],
    *,
    alpha: float,
    dt: float,
    final_replay_exact: bool,
) -> str:
    """Generate human-readable report."""
    lines = [
        "=" * 70,
        "AIEF-1.4 Two-Channel Directed Alignment Decomposition",
        "=" * 70,
        "",
        f"alpha_EMA: {alpha:.12g}",
        f"dt: {dt:.12g}",
        f"Final replay exact: {final_replay_exact}",
        "",
    ]

    # Final values from trajectory
    if len(trajectory) > 0:
        final_row = trajectory.iloc[-1]
        lines.extend([
            "-" * 70,
            "Final Directed Magnitude Differences",
            "-" * 70,
            "",
            "Fixed-left channel (Edge 25 vs Edge 59):",
            f"  D^-> = |C^+_{2,7}| - |C^+_{7,11}|  = {final_row['D_fixed_left_forward']:.12g}",
            f"  D^<- = |C^+_{7,2}| - |C^+_{11,7}| = {final_row['D_fixed_left_reverse']:.12g}",
            f"  D_sym = 0.5*(D^-> + D^<-)    = {final_row['D_fixed_left_sym']:.12g}",
            f"  I_sym  = |D^-> + D^<-| / (|D^->| + |D^<-|) = {final_row['I_sym_fixed_left']:.12g}",
            "",
            "Right-mode channel (Edge 59 vs Edge 29):",
            f"  D^-> = |C^+_{7,11}| - |C^+_{2,11}| = {final_row['D_right_mode_forward']:.12g}",
            f"  D^<- = |C^+_{11,7}| - |C^+_{11,2}| = {final_row['D_right_mode_reverse']:.12g}",
            f"  D_sym = 0.5*(D^-> + D^<-)    = {final_row['D_right_mode_sym']:.12g}",
            f"  I_sym  = |D^-> + D^<-| / (|D^->| + |D^<-|) = {final_row['I_sym_right_mode']:.12g}",
            "",
        ])

        # Resonance ordering check
        R_25_final = final_row['R_25']
        R_59_final = final_row['R_59']
        R_29_final = final_row['R_29']
        ordering_ok = (R_25_final > R_59_final) and (R_59_final > R_29_final)
        lines.extend([
            "-" * 70,
            "Resonance Ordering Check",
            "-" * 70,
            "",
            f"  R_25 = {R_25_final:.12g}",
            f"  R_59 = {R_59_final:.12g}",
            f"  R_29 = {R_29_final:.12g}",
            f"  Ordering R_25 > R_59 > R_29: {'PASS' if ordering_ok else 'FAIL'}",
            "",
        ])

    # Symmetrization indices
    lines.extend([
        "-" * 70,
        "Symmetrization Indices (I_sym = |D^-> + D^<-| / (|D^->| + |D^<-|))",
        "-" * 70,
        "",
    ])
    
    sym_summary = channel_summary[channel_summary["orientation"] == "symmetrized"]
    for _, row in sym_summary.iterrows():
        ch = row["channel"]
        I_sym_final = row["symmetrization_index_final"]
        if not np.isnan(I_sym_final):
            mech = (
                "REINFORCEMENT" if I_sym_final > 0.9
                else "CANCELLATION" if I_sym_final < 0.1
                else "PARTIAL"
            )
            lines.append(
                f"  {ch} I_sym (final): {I_sym_final:.6g} [{mech}]"
            )

    # Channel summaries
    lines.extend([
        "",
        "-" * 70,
        "Channel Audit Summary (Full Trajectory)",
        "-" * 70,
        "",
    ])

    full_summary = channel_summary[channel_summary["scope"] == "full"]
    full_summary = full_summary[full_summary["orientation"] != "symmetrized"]
    
    for _, row in full_summary.iterrows():
        ch = row["channel"]
        orient = row["orientation"]
        lines.extend([
            f"[{ch}:{orient}]",
            f"  Min D: {row['min_D']:.6g}, Max D: {row['max_D']:.6g}, Final D: {row['final_D']:.6g}",
            f"  All positive: {row['all_positive']}, All negative: {row['all_negative']}",
            f"  Sign changes: {row['sign_change_count']}",
            f"  e decay rate: {row['e_rate']:.6g} (R²={row['e_R_squared']:.6g})",
            f"  T1 decay rate: {row['T1_rate']:.6g} (R²={row['T1_R_squared']:.6g})",
            f"  T2 decay rate: {row['T2_rate']:.6g} (R²={row['T2_R_squared']:.6g})",
            f"  Cancellation index (final): {row['cancellation_index_final']:.6g}",
            f"  T1/T2 ratio (final): {row['T1_T2_ratio_final']:.6g}",
            f"  |T1/T2 + 1| (final): {row['T1_T2_plus_one_final']:.6g}",
            f"  T2 above floor count: {row['T2_above_floor_count']}",
            f"  Radial reinforcement: {row['radial_reinforcement']}",
            f"  T1/T2 -> -1: {'CONVERGED' if row['T1_T2_converged'] else 'NOT CONVERGED'}",
            "",
        ])

    # Identity checks
    lines.extend([
        "-" * 70,
        "Exact Identity Verification",
        "-" * 70,
        "",
    ])
    
    for identity_type in ["alignment", "radial"]:
        type_checks = identity_checks[identity_checks["identity_type"] == identity_type]
        if len(type_checks) > 0:
            lines.append(f"  {identity_type.capitalize()} identity:")
            for _, row in type_checks.iterrows():
                status = "PASS" if row["passes"] else "FAIL"
                lines.append(
                    f"    {row['channel']}:{row['orientation']}: "
                    f"max_err={row['maximum_absolute_error']:.2e}, "
                    f"med_err={row['median_absolute_error']:.2e} [{status}]"
                )
            lines.append("")

    # Branch metrics
    lines.extend([
        "-" * 70,
        "Fixed Branch Validation",
        "-" * 70,
        "",
        f"  B nonnegative: {branch_metrics['b_nonnegative']}",
        f"  B symmetric: {branch_metrics['b_symmetric']}",
        f"  B diagonal zero: {branch_metrics['b_diagonal_zero']}",
        f"  K3 row sums: {branch_metrics['k3_row_sums']}",
        f"  K3 B values: {branch_metrics['k3_B_values']}",
        "",
    ])

    lines.extend([
        "-" * 70,
        "Interpretation Constraints",
        "-" * 70,
        "* Directed magnitude differences use C^+ (updated coherence) entries.",
        "* Forward: |C^+_{i_a,j_a}| - |C^+_{i_b,j_b}|, Reverse: |C^+_{j_a,i_a}| - |C^+_{j_b,i_b}|",
        "* Symmetrized: D_sym = 0.5*(D^-> + D^<-), I_sym = |D^-> + D^<-| / (|D^->| + |D^<-|).",
        "* Radial forcing: sign(alpha*DeltaM_n) vs sign(alpha*(1-alpha)*e_n).",
        "* Cancellation index: |T1+T2|/(|T1|+|T2|); 0=cancellation, 1=reinforcement.",
        "* T1/T2 -> -1: converged if |T1/T2 + 1| < 0.01 AND |T2| > floor for final samples.",
        "* Exact identities: e_n = T1_n + T2_n and DeltaM_{n+1} = alpha*DeltaM_n + alpha*(1-alpha)*e_n.",
        "* Phase-balance: decomposed into domega (intrinsic), dG (coupling), dh (history).",
        "* Results conditional on seed 4619122171158768524 and fixed branch.",
        "* Unwrapped phases use discont=pi convention.",
        "* Loop runs over future_steps transitions (not future_steps+1 states).",
        "",
    ])

    return "\n".join(lines)


# =============================================================================
# Argument Parsing
# =============================================================================

def parse_arguments() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--npz", default=DEFAULT_NPZ)
    parser.add_argument("--manifest", default=DEFAULT_MANIFEST)
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--seed", default=DEFAULT_SEED)
    parser.add_argument("--dt", type=float, default=DEFAULT_DT)
    parser.add_argument("--scale-epsilon", type=float, default=DEFAULT_SCALE_EPSILON)
    parser.add_argument(
        "--intervals",
        type=parse_nonnegative_float_list,
        default=parse_nonnegative_float_list(DEFAULT_INTERVALS),
    )
    parser.add_argument("--signal-floor", type=float, default=DEFAULT_SIGNAL_FLOOR)
    return parser.parse_args()


# =============================================================================
# Main Analysis Routine
# =============================================================================

def main() -> None:
    """Main analysis routine."""
    args = parse_arguments()

    # --- Validate inputs exist ---
    for path in (args.npz, args.manifest):
        if not os.path.isfile(path):
            raise FileNotFoundError(path)

    # --- Validate numeric arguments ---
    if min(args.dt, args.scale_epsilon, args.signal_floor) <= 0.0:
        raise ValueError("dt and tolerances must be positive")

    if args.scale_epsilon != 1e-12:
        raise ValueError("implemented actual_step uses fixed scale epsilon=1e-12")

    # --- Create output directory ---
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # --- Load and validate manifest ---
    with open(args.manifest, "r", encoding="utf-8") as handle:
        manifest = json.load(handle)

    validate_manifest_structure(manifest)

    model = manifest["model"]
    dt = float(model["dt"])
    if abs(dt - args.dt) > 1e-15:
        raise ValueError("command dt does not match manifest dt")

    alpha = math.exp(-dt / float(model["T_window"]))
    omega = np.asarray(model["omega"], dtype=float)
    capacity = (float(model["a"]) - float(model["delta"])) / float(model["q"])
    capacities = np.full(int(model["N"]), capacity)
    N = int(model["N"])

    # --- Build incidence matrix and validate edge indexing ---
    A, edges = base.incidence_matrix(N)
    validate_edge_indexing(edges)

    future_steps = int(manifest["protocol"]["future_steps"])
    if future_steps <= 0:
        raise ValueError(f"future_steps must be positive, got {future_steps}")

    # --- Load and validate NPZ data ---
    with np.load(args.npz, allow_pickle=False) as data:
        validate_npz_keys(data, args.seed)
        state = base.load_split_state(data, args.seed)
        expected_final = np.asarray(
            data[base.branch_key("continue", args.seed, "B_final")], dtype=float
        ).copy()

    validate_state(state, N)

    # --- Validate K3 node indices ---
    if max(K3_NODES) >= N:
        raise ValueError(f"K3 node index >= N={N}: {K3_NODES}")

    # --- Validate fixed branch at start ---
    branch_metrics = validate_fixed_branch(state, model, capacities, args.scale_epsilon)

    # --- Collect trajectory data ---
    # Loop over TRANSITIONS (future_steps), not states (future_steps + 1)
    step_count = future_steps
    
    # Storage: channel -> orientation -> step -> quantity
    channel_data = {}
    for ch_name in CHANNELS:
        channel_data[ch_name] = {}
        for orientation in ORIENTATIONS:
            channel_data[ch_name][orientation] = {
                "DeltaM_old": np.zeros(step_count),
                "DeltaM_new": np.zeros(step_count),
                "DeltaA": np.zeros(step_count),
                "e": np.zeros(step_count),
                "T1": np.zeros(step_count),
                "T2": np.zeros(step_count),
                "D": np.zeros(step_count),
                "memory_phase_raw": np.zeros(step_count),
                "source_phase_raw": np.zeros(step_count),
                "domega": np.zeros(step_count),
                "dG": np.zeros(step_count),
                "dh": np.zeros(step_count),
            }
    
    # Store R matrix values for reference
    R_values = {e_idx: np.zeros(step_count) for e_idx in K3_EDGES}
    
    # Store symmetrized differences
    sym_data = {}
    for ch_name in CHANNELS:
        sym_data[ch_name] = {
            "D_sym": np.zeros(step_count),
            "I_sym": np.zeros(step_count),
        }

    # --- Simulate forward and collect data ---
    for step in range(step_count):
        intermediate = augmented.base_intermediates(
            state,
            model,
            capacities,
            A,
            edges,
            args.scale_epsilon,
        )
        validate_intermediate(intermediate, N)

        C_old = state.coherence_acc
        C_new = intermediate["updated_coherence"]
        phase_factor = intermediate["phase_factor"]
        R_matrix = intermediate["R"]
        coupling = intermediate["coupling"]
        
        # Store R values for K3 edges (symmetrized magnitudes)
        for e_idx, (i, j) in K3_EDGES.items():
            R_values[e_idx][step] = float(R_matrix[i, j])
        
        # Process each channel and orientation
        for ch_name, orientations in CHANNELS.items():
            for orientation in ORIENTATIONS:
                edge_pair = orientations[orientation]
                (ia, ja) = edge_pair["edge_a"]
                (ib, jb) = edge_pair["edge_b"]
                
                # Get DIRECTED coherence entries (scalars) for OLD state (alignment)
                C_a_old = C_old[ia, ja]
                C_b_old = C_old[ib, jb]
                
                # Get phase factors (scalars)
                Z_a = phase_factor[ia, ja]
                Z_b = phase_factor[ib, jb]
                
                # Get UPDATED coherence entries (scalars) for magnitude
                C_a_new = C_new[ia, ja]
                C_b_new = C_new[ib, jb]
                
                # Compute channel quantities using OLD coherence
                q = channel_quantities(C_a_old, C_b_old, Z_a, Z_b)
                
                # Directed magnitude difference using NEW coherence
                D = float(abs(C_a_new) - abs(C_b_new))
                
                # Phase differences (raw, for later batch unwrapping)
                mem_phase_raw = float(np.angle(C_a_new * np.conj(C_b_new)))
                src_phase_raw = float(np.angle(Z_a * np.conj(Z_b)))
                
                # Phase-balance decomposition
                # Δφ_a - Δφ_b = dt(ω_ia - ω_ib) + dt(G_ia - G_ib) - (h_ja - h_jb)
                dt_domega = dt * (omega[ia] - omega[ib])
                dt_dG = dt * (coupling[ia] - coupling[ib])
                
                # History increment: approximate from state.history
                # state.history is a deque; we need the delayed phase difference
                # For simplicity, use 0 if history not available
                dh_val = 0.0
                if hasattr(state, 'history') and len(state.history) >= 2:
                    # This is a placeholder; exact implementation depends on base module
                    # In practice, delayed phase is stored in intermediate
                    try:
                        # Try to get delayed coherence from intermediate
                        if "delayed_coherence" in intermediate:
                            C_delayed = intermediate["delayed_coherence"]
                            dh_val = float(
                                np.angle(C_delayed[ja, ja] * np.conj(C_delayed[jb, jb]))
                            )
                    except (KeyError, AttributeError):
                        dh_val = 0.0
                
                # Store all quantities
                channel_data[ch_name][orientation]["DeltaM_old"][step] = q["DeltaM"]
                channel_data[ch_name][orientation]["DeltaM_new"][step] = float(
                    abs(C_a_new) ** 2 - abs(C_b_new) ** 2
                )
                channel_data[ch_name][orientation]["DeltaA"][step] = q["DeltaA"]
                channel_data[ch_name][orientation]["e"][step] = q["alignment_residual"]
                channel_data[ch_name][orientation]["T1"][step] = q["T1"]
                channel_data[ch_name][orientation]["T2"][step] = q["T2"]
                channel_data[ch_name][orientation]["D"][step] = D
                channel_data[ch_name][orientation]["memory_phase_raw"][step] = mem_phase_raw
                channel_data[ch_name][orientation]["source_phase_raw"][step] = src_phase_raw
                channel_data[ch_name][orientation]["domega"][step] = dt_domega
                channel_data[ch_name][orientation]["dG"][step] = dt_dG
                channel_data[ch_name][orientation]["dh"][step] = dh_val
        
        # Compute symmetrized differences
        for ch_name in CHANNELS:
            D_forward = channel_data[ch_name]["forward"]["D"][step]
            D_reverse = channel_data[ch_name]["reverse"]["D"][step]
            sym_data[ch_name]["D_sym"][step] = 0.5 * (D_forward + D_reverse)
            
            denom = abs(D_forward) + abs(D_reverse)
            if denom > ZERO_TOL:
                sym_data[ch_name]["I_sym"][step] = abs(D_forward + D_reverse) / denom
            else:
                sym_data[ch_name]["I_sym"][step] = np.nan
        
        # Advance state
        augmented.advance_base_state(state, intermediate)

    # --- Verify final state ---
    final_replay_exact = bool(np.array_equal(state.B, expected_final))

    # --- Batch unwrap phases ---
    for ch_name in CHANNELS:
        for orientation in ORIENTATIONS:
            raw_mem = channel_data[ch_name][orientation]["memory_phase_raw"]
            raw_src = channel_data[ch_name][orientation]["source_phase_raw"]
            
            channel_data[ch_name][orientation]["memory_phase"] = np.unwrap(
                raw_mem, discont=UNWRAP_DISCONT
            )
            channel_data[ch_name][orientation]["source_phase"] = np.unwrap(
                raw_src, discont=UNWRAP_DISCONT
            )

    # --- Process intervals ---
    boundaries = np.asarray(args.intervals, dtype=float)
    T_end = step_count * dt

    if boundaries.size == 0:
        boundaries = np.array([0.0, T_end])
    else:
        if boundaries[0] > 0.0:
            boundaries = np.concatenate(([0.0], boundaries))
        if boundaries[-1] < T_end:
            boundaries = np.concatenate((boundaries, [T_end]))
    boundaries = np.unique(boundaries)

    # --- Build trajectory DataFrame ---
    trajectory_rows = []
    
    for step in range(step_count):
        row = {"step": step, "time": step * dt}
        
        # Add R values
        for e_idx in K3_EDGES:
            row[f"R_{e_idx}"] = float(R_values[e_idx][step])
        
        # Add directed and symmetrized differences
        for ch_name in CHANNELS:
            row[f"D_{ch_name}_forward"] = float(
                channel_data[ch_name]["forward"]["D"][step]
            )
            row[f"D_{ch_name}_reverse"] = float(
                channel_data[ch_name]["reverse"]["D"][step]
            )
            row[f"D_{ch_name}_sym"] = float(sym_data[ch_name]["D_sym"][step])
            row[f"I_sym_{ch_name}"] = float(sym_data[ch_name]["I_sym"][step])
        
        trajectory_rows.append(row)
    
    trajectory = pd.DataFrame(trajectory_rows)

    # --- Audit each channel and orientation ---
    channel_summary_rows = []
    identity_check_rows = []

    times = trajectory["time"].values

    for ch_name in CHANNELS:
        for orientation in ORIENTATIONS:
            data = channel_data[ch_name][orientation]
            
            D = data["D"]
            e = data["e"]
            T1 = data["T1"]
            T2 = data["T2"]
            DeltaM_old = data["DeltaM_old"]
            DeltaM_new = data["DeltaM_new"]
            
            # --- Sign analysis ---
            pos_count, neg_count, sign_changes = count_sign_changes(
                D, args.signal_floor
            )
            all_positive = (pos_count == len(D)) and (neg_count == 0)
            all_negative = (neg_count == len(D)) and (pos_count == 0)
            
            # --- Cancellation index ---
            denom = np.abs(T1) + np.abs(T2)
            cancellation_idx = np.where(
                denom > args.signal_floor,
                np.abs(T1 + T2) / denom,
                np.nan
            )
            
            # --- T1/T2 ratio and convergence ---
            T1_T2_ratio = np.where(
                np.abs(T2) > args.signal_floor,
                T1 / T2,
                np.nan
            )
            T1_T2_plus_one = np.where(
                np.abs(T2) > args.signal_floor,
                np.abs(T1_T2_ratio + 1.0),
                np.nan
            )
            T2_above_floor_count = int(np.sum(np.abs(T2) > args.signal_floor))
            
            # Convergence: |T1/T2 + 1| < 0.01 for final samples where |T2| > floor
            converged = False
            if T2_above_floor_count > 0:
                valid_idx = np.abs(T2) > args.signal_floor
                if np.sum(valid_idx) >= 3:
                    final_valid = T1_T2_plus_one[valid_idx][-3:]
                    converged = bool(np.all(final_valid < 0.01))
            
            # --- Radial forcing reinforcement ---
            # Compare sign(alpha * DeltaM_old) vs sign(alpha * (1-alpha) * e)
            radial_term1 = alpha * DeltaM_old
            radial_term2 = alpha * (1.0 - alpha) * e
            
            valid_radial = (
                (np.abs(radial_term1) > args.signal_floor) &
                (np.abs(radial_term2) > args.signal_floor)
            )
            if np.sum(valid_radial) > 0:
                signs_agree = np.sign(radial_term1[valid_radial]) == np.sign(
                    radial_term2[valid_radial]
                )
                if np.all(signs_agree):
                    radial_reinforcement = "REINFORCEMENT"
                elif not np.any(signs_agree):
                    radial_reinforcement = "CANCELLATION"
                else:
                    radial_reinforcement = "MIXED"
            else:
                radial_reinforcement = "UNDEFINED"
            
            # --- Fit rates ---
            e_rate_fit = fit_log_rate(times, e, args.signal_floor)
            T1_rate_fit = fit_log_rate(times, T1, args.signal_floor)
            T2_rate_fit = fit_log_rate(times, T2, args.signal_floor)
            
            # --- Identity checks ---
            align_test = test_alignment_identity(e, T1, T2, tol=args.signal_floor)
            radial_test = test_radial_identity(
                DeltaM_old, DeltaM_new, e, alpha, tol=args.signal_floor
            )
            
            # --- Per-interval summaries ---
            for interval_idx in range(len(boundaries) - 1):
                start_idx = max(0, int(round(boundaries[interval_idx] / dt)))
                end_idx = min(step_count, int(round(boundaries[interval_idx + 1] / dt)))
                
                if end_idx <= start_idx + 2:
                    continue
                
                scope = "interval"
                interval_D = D[start_idx:end_idx]
                interval_e = e[start_idx:end_idx]
                interval_T1 = T1[start_idx:end_idx]
                interval_T2 = T2[start_idx:end_idx]
                interval_cancel = cancellation_idx[start_idx:end_idx]
                interval_T1_T2 = T1_T2_ratio[start_idx:end_idx]
                interval_T1_T2_plus_one = T1_T2_plus_one[start_idx:end_idx]
                
                # Sign analysis for interval
                p, n, sc = count_sign_changes(interval_D, args.signal_floor)
                all_pos = (p == len(interval_D)) and (n == 0)
                all_neg = (n == len(interval_D)) and (p == 0)
                
                # Interval-specific fits
                interval_times = times[start_idx:end_idx]
                e_fit = fit_log_rate(interval_times, interval_e, args.signal_floor)
                T1_fit = fit_log_rate(interval_times, interval_T1, args.signal_floor)
                T2_fit = fit_log_rate(interval_times, interval_T2, args.signal_floor)
                
                channel_summary_rows.append({
                    "scope": scope,
                    "channel": ch_name,
                    "orientation": orientation,
                    "start_time": boundaries[interval_idx],
                    "end_time": boundaries[interval_idx + 1],
                    "sample_count": end_idx - start_idx,
                    "min_D": float(np.min(interval_D)),
                    "max_D": float(np.max(interval_D)),
                    "final_D": float(interval_D[-1]),
                    "all_positive": all_pos,
                    "all_negative": all_neg,
                    "sign_change_count": sc,
                    "e_rate": e_fit["rate"],
                    "e_R_squared": e_fit["R_squared"],
                    "T1_rate": T1_fit["rate"],
                    "T1_R_squared": T1_fit["R_squared"],
                    "T2_rate": T2_fit["rate"],
                    "T2_R_squared": T2_fit["R_squared"],
                    "cancellation_index_final": float(interval_cancel[-1]) if len(interval_cancel) > 0 else np.nan,
                    "T1_T2_ratio_final": float(interval_T1_T2[-1]) if len(interval_T1_T2) > 0 else np.nan,
                    "T1_T2_plus_one_final": float(interval_T1_T2_plus_one[-1]) if len(interval_T1_T2_plus_one) > 0 else np.nan,
                    "T2_above_floor_count": int(np.sum(np.abs(interval_T2) > args.signal_floor)),
                    "radial_reinforcement": radial_reinforcement,
                    "T1_T2_converged": converged,
                    "max_alignment_identity_error": align_test["max_abs_error"],
                    "max_radial_identity_error": radial_test["max_abs_error"],
                })
            
            # --- Full trajectory summary ---
            channel_summary_rows.append({
                "scope": "full",
                "channel": ch_name,
                "orientation": orientation,
                "start_time": 0.0,
                "end_time": T_end,
                "sample_count": step_count,
                "min_D": float(np.min(D)),
                "max_D": float(np.max(D)),
                "final_D": float(D[-1]),
                "all_positive": all_positive,
                "all_negative": all_negative,
                "sign_change_count": sign_changes,
                "e_rate": e_rate_fit["rate"],
                "e_R_squared": e_rate_fit["R_squared"],
                "T1_rate": T1_rate_fit["rate"],
                "T1_R_squared": T1_rate_fit["R_squared"],
                "T2_rate": T2_rate_fit["rate"],
                "T2_R_squared": T2_rate_fit["R_squared"],
                "cancellation_index_final": float(cancellation_idx[-1]) if len(cancellation_idx) > 0 else np.nan,
                "T1_T2_ratio_final": float(T1_T2_ratio[-1]) if len(T1_T2_ratio) > 0 else np.nan,
                "T1_T2_plus_one_final": float(T1_T2_plus_one[-1]) if len(T1_T2_plus_one) > 0 else np.nan,
                "T2_above_floor_count": T2_above_floor_count,
                "radial_reinforcement": radial_reinforcement,
                "T1_T2_converged": converged,
                "max_alignment_identity_error": align_test["max_abs_error"],
                "max_radial_identity_error": radial_test["max_abs_error"],
            })
            
            # Identity check rows
            identity_check_rows.append({
                "identity_type": "alignment",
                "identity": f"{ch_name}_{orientation}_alignment",
                "channel": ch_name,
                "orientation": orientation,
                "maximum_absolute_error": align_test["max_abs_error"],
                "median_absolute_error": align_test["median_absolute_error"],
                "passes": align_test["identity_passes"],
            })
            
            identity_check_rows.append({
                "identity_type": "radial",
                "identity": f"{ch_name}_{orientation}_radial",
                "channel": ch_name,
                "orientation": orientation,
                "maximum_absolute_error": radial_test["max_abs_error"],
                "median_absolute_error": radial_test["median_absolute_error"],
                "passes": radial_test["identity_passes"],
            })
        
        # Symmetrized summary (not per-orientation)
        I_sym = sym_data[ch_name]["I_sym"]
        D_sym = sym_data[ch_name]["D_sym"]
        
        # Fit I_sym
        I_sym_fit = fit_log_rate(times, I_sym, args.signal_floor)
        
        # Sign analysis for symmetrized
        p_sym, n_sym, sc_sym = count_sign_changes(D_sym, args.signal_floor)
        all_pos_sym = (p_sym == len(D_sym)) and (n_sym == 0)
        all_neg_sym = (n_sym == len(D_sym)) and (p_sym == 0)
        
        channel_summary_rows.append({
            "scope": "full",
            "channel": ch_name,
            "orientation": "symmetrized",
            "start_time": 0.0,
            "end_time": T_end,
            "sample_count": step_count,
            "min_D": float(np.min(D_sym)),
            "max_D": float(np.max(D_sym)),
            "final_D": float(D_sym[-1]),
            "all_positive": all_pos_sym,
            "all_negative": all_neg_sym,
            "sign_change_count": sc_sym,
            "e_rate": np.nan,
            "e_R_squared": np.nan,
            "T1_rate": np.nan,
            "T1_R_squared": np.nan,
            "T2_rate": np.nan,
            "T2_R_squared": np.nan,
            "cancellation_index_final": np.nan,
            "T1_T2_ratio_final": np.nan,
            "T1_T2_plus_one_final": np.nan,
            "T2_above_floor_count": np.nan,
            "radial_reinforcement": "N/A",
            "T1_T2_converged": False,
            "max_alignment_identity_error": np.nan,
            "max_radial_identity_error": np.nan,
            "symmetrization_index": float(np.mean(I_sym)),
            "symmetrization_index_final": float(I_sym[-1]) if step_count > 0 else np.nan,
            "I_sym_rate": I_sym_fit["rate"],
            "I_sym_R_squared": I_sym_fit["R_squared"],
        })

    # --- Build DataFrames ---
    channel_summary = pd.DataFrame(channel_summary_rows)
    identity_checks = pd.DataFrame(identity_check_rows)

    # --- Write outputs ---
    component_audit.atomic_write_csv(
        output_dir / "two_channel_trajectory.csv", trajectory
    )
    component_audit.atomic_write_csv(
        output_dir / "two_channel_summary.csv", channel_summary
    )
    component_audit.atomic_write_csv(
        output_dir / "two_channel_identity_checks.csv", identity_checks
    )

    report = make_report(
        channel_summary,
        identity_checks,
        trajectory,
        branch_metrics,
        alpha=alpha,
        dt=dt,
        final_replay_exact=final_replay_exact,
    )
    component_audit.atomic_write_text(
        output_dir / "two_channel_decomposition_report.txt", report
    )

    # --- Compute dependency hashes ---
    dep_hashes = {
        "AIEF_1_4_stationarity_perturbation_analysis_updated": compute_module_sha256(base),
        "AIEF_1_4_component_controller_audit": compute_module_sha256(component_audit),
        "AIEF_1_4_augmented_tangent_cocycle_analysis": compute_module_sha256(augmented),
    }

    # --- Build manifest ---
    manifest_output = {
        "analysis": "AIEF-1.4 two-channel directed alignment decomposition",
        "source": {
            "path": str(Path(__file__).resolve()),
            "sha256": file_sha256(Path(__file__).resolve()),
        },
        "command": sys.argv,
        "inputs": {
            "npz": {
                "path": str(Path(args.npz).resolve()),
                "sha256": file_sha256(args.npz),
            },
            "manifest": {
                "path": str(Path(args.manifest).resolve()),
                "sha256": file_sha256(args.manifest),
            },
        },
        "dependencies": {
            name: {"path": str(Path(module.__file__).resolve()), "sha256": h}
            for name, (module, h) in [
                ("base", base, dep_hashes["AIEF_1_4_stationarity_perturbation_analysis_updated"]),
                ("component_audit", component_audit, dep_hashes["AIEF_1_4_component_controller_audit"]),
                ("augmented", augmented, dep_hashes["AIEF_1_4_augmented_tangent_cocycle_analysis"]),
            ]
        },
        "seed": args.seed,
        "dt": dt,
        "alpha_EMA": alpha,
        "scale_epsilon": args.scale_epsilon,
        "intervals": boundaries.tolist(),
        "signal_floor": args.signal_floor,
        "unwrapping_convention": {"discont": UNWRAP_DISCONT},
        "final_replay_exact": final_replay_exact,
        "K3_configuration": {
            "nodes": list(K3_NODES),
            "edges": {str(e): list(nodes) for e, nodes in K3_EDGES.items()},
        },
        "channels": {
            name: {
                "description": defn["description"],
                "forward": {"edge_a": list(defn["forward"]["edge_a"]), "edge_b": list(defn["forward"]["edge_b"])},
                "reverse": {"edge_a": list(defn["reverse"]["edge_a"]), "edge_b": list(defn["reverse"]["edge_b"])},
            }
            for name, defn in CHANNELS.items()
        },
        "outputs": [
            "two_channel_trajectory.csv",
            "two_channel_summary.csv",
            "two_channel_identity_checks.csv",
            "two_channel_decomposition_report.txt",
            "analysis_manifest.json",
        ],
        "interpretation_constraints": [
            "Directed magnitude differences use C^+ (updated coherence) entries: D^-> = |C^+_{i_a,j_a}| - |C^+_{i_b,j_b}|, D^<- = |C^+_{j_a,i_a}| - |C^+_{j_b,i_b}|",
            "Symmetrized: D_sym = 0.5*(D^-> + D^<-), I_sym = |D^-> + D^<-| / (|D^->| + |D^<-|).",
            "Radial forcing: sign(alpha*DeltaM_n) vs sign(alpha*(1-alpha)*e_n) where DeltaM_n = |C_{a,n}|^2 - |C_{b,n}|^2 (OLD coherence).",
            "Alignment identity: e_n = T1_n + T2_n verified numerically.",
            "Radial identity: DeltaM_{n+1} = alpha*DeltaM_n + alpha*(1-alpha)*e_n verified numerically.",
            "Cancellation index: |T1+T2|/(|T1|+|T2|); 0=cancellation, 1=reinforcement.",
            "T1/T2 -> -1: converged if |T1/T2 + 1| < 0.01 AND |T2| > floor for final samples.",
            "Phase-balance: decomposed into domega (intrinsic), dG (coupling), dh (history).",
            "Results conditional on seed 4619122171158768524 and fixed branch.",
            "Unwrapped phases use discont=pi convention.",
            "Loop runs over future_steps transitions (not future_steps+1 states).",
        ],
    }

    component_audit.atomic_write_text(
        output_dir / "analysis_manifest.json",
        json.dumps(manifest_output, indent=2, sort_keys=True) + "\n",
    )

    print(report)
    print(f"\nSaved analysis to {output_dir.resolve()}")


if __name__ == "__main__":
    main()
