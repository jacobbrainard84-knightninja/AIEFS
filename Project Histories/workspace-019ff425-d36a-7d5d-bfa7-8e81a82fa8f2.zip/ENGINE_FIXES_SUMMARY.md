# AIEF Experiment Engine v1 - Fixes Summary

## Critical Issues Fixed

### 1. Prefix RNG Initialization (FIXED)
- **Issue**: Engine was using `default_rng(init_sequence.generate_state(...))` instead of `default_rng(init_sequence)`
- **Fix**: Updated `make_prefix_rng()` to use `default_rng(init_sequence)` matching production exactly
- **Impact**: Ensures exact RNG stream for prefix initialization

### 2. r_mean_late Accumulation Bug (FIXED)
- **Issue**: Engine was accumulating `r_late_sum` at EVERY late step
- **Fix**: Moved `r_late_sum` accumulation inside the diagnostic stride block (only at sampled steps)
- **Impact**: Matches production exactly where r_mean_late is only computed from diagnostic samples

### 3. Projection Diagnostics Missing (FIXED)
- **Issue**: Engine was not accumulating projection metrics (G_min_future, Projection_active_fraction, etc.)
- **Fix**: Added `ProjectionTotals` class and integrated into `advance_state()` and `simulate_future()`
- **Impact**: All projection diagnostics now match production

### 4. Branch RNG Namespace (FIXED)
- **Issue**: Study driver was conflating RNG namespace with branches to simulate
- **Fix**: `simulate_seed_rho()` uses `FROZEN_BRANCH_ORDER` for RNG namespace but only simulates `STUDY_BRANCHES`
- **Impact**: `future_shuffle` gets the 7th RNG sequence (not 4th), matching production

### 5. Scalar CSV Loading (FIXED)
- **Issue**: Baseline equivalence test only checked NPZ, but production stores scalars in CSV
- **Fix**: Added CSV loading and comparison in `run_baseline_equivalence()`
- **Impact**: Scalar values are now properly validated against frozen data

### 6. NaN Handling in Scalar Comparison (FIXED)
- **Issue**: `np.isclose(nan, nan, rtol=0, atol=0)` returns False
- **Fix**: Added explicit NaN check - both NaN values are considered equal
- **Impact**: Correctly handles NaN values in scalar comparisons

### 7. T_window Exact Value (FIXED)
- **Issue**: Engine was using rounded T_window=17.5 instead of exact 17.502917152858814
- **Fix**: Updated to use exact `25.0 / mean(OMEGA)` value
- **Impact**: Matches production configuration exactly

### 8. jaccard_edges Threshold Parameter (FIXED)
- **Issue**: Function signature had optional threshold but wasn't using it correctly
- **Fix**: Updated to use `config.B_c` as threshold, matching production
- **Impact**: Jaccard similarity computed with correct threshold

## Remaining Issues (Deferred)

### 9. Fixed Physical Horizons
- **Status**: NOT YET IMPLEMENTED
- **Impact**: Engine currently only uses EMA-normalized horizons
- **Plan**: Add horizon system parameter to `simulate_future()` in v2

### 10. Time-based Metrics
- **Status**: NOT YET IMPLEMENTED
- **Metrics**: Time_to_50pct_*, Time_to_90pct_*, Late_persistence_ratio_to_continue, etc.
- **Impact**: These are computed in production's post-processing, not in simulate_future
- **Plan**: Add to study driver post-processing in v2

### 11. Ratio Metrics
- **Status**: NOT YET IMPLEMENTED
- **Metrics**: Late_persistence_ratio_to_continue, Late_similarity_ratio_to_continue
- **Impact**: Require reference branch (continue) to be available
- **Plan**: Compute in study driver after all branches simulated

## Validation Status

### Test Results
- ✅ 1-seed baseline equivalence: PASSED
- ✅ 2-seed baseline equivalence: PASSED
- ⏳ 40-seed baseline equivalence: NOT YET TESTED
- ⏳ Full T_window study: NOT YET RUN

### Next Steps
1. Generate 40-seed frozen data:
   ```bash
   python3 AIEF_1_4_memory_ablation_updated_REAL.py --master-seed 20260714 --n-seeds 40 --run-root runs/frozen_production_20260806
   ```

2. Run baseline equivalence test:
   ```bash
   python3 AIEF_1_4_Twindow_sensitivity.py --n-seeds 40 --frozen-manifest <path>/manifest.json --frozen-npz <path>/branch_diagnostics.npz --dry-run
   ```

3. If baseline passes, run full study:
   ```bash
   python3 AIEF_1_4_Twindow_sensitivity.py --n-seeds 40 --frozen-manifest <path>/manifest.json --frozen-npz <path>/branch_diagnostics.npz
   ```

4. Analyze results:
   ```bash
   python3 AIEF_1_4_Twindow_sensitivity_analysis_v2.py runs/<study_hash>/ --n-bootstrap 1000
   ```

## Files Modified

1. **aief_experiment_engine_v1.py**
   - Fixed `make_prefix_rng()`
   - Added `ProjectionTotals` class
   - Fixed `advance_state()` to return projection info
   - Fixed `simulate_future()` to use ProjectionTotals and correct r_late accumulation
   - Fixed `jaccard_edges()` threshold parameter
   - Updated `REQUIRED_BRANCH_SCALAR_KEYS` to include projection diagnostics
   - Fixed `run_baseline_equivalence()` to load and compare scalar CSV
   - Fixed NaN handling in scalar comparison
   - Updated docstring

2. **AIEF_1_4_Twindow_sensitivity.py**
   - Added `FROZEN_BRANCH_ORDER` and `STUDY_BRANCHES`
   - Fixed `simulate_seed_rho()` to use FROZEN_BRANCH_ORDER for RNG namespace
   - Added CSV loading for baseline equivalence
   - Updated `REQUIRED_BRANCH_SCALAR_KEYS` to include projection diagnostics
   - Removed `--skip-baseline` argument
   - Fixed atomic NPZ writing

3. **AIEF_1_4_Twindow_sensitivity_analysis_v2.py**
   - Already created with 5-stage analysis structure
   - Uses selective NPZ loading
   - Proper JSON sanitization
   - Reads from manifest
