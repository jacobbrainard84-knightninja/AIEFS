# Baseline Test Status - 2026-08-09

## Summary

All P0 and P1 fixes have been successfully implemented across the three files:
- `aief_experiment_engine_v1.py` - 10 P0 fixes
- `AIEF_1_4_Twindow_sensitivity.py` - 4 P0 + 17 P1 fixes  
- `AIEF_1_4_Twindow_sensitivity_analysis_v3.py` - 12 P0 fixes

## Completed Steps

### 1. Syntax Check ✅
All three files pass Python syntax validation:
```bash
python3 -m py_compile aief_experiment_engine_v1.py AIEF_1_4_Twindow_sensitivity.py AIEF_1_4_Twindow_sensitivity_analysis_v3.py
```

### 2. Dry-Run Validation ✅
Successfully validated configuration with:
```bash
python3 AIEF_1_4_Twindow_sensitivity.py --dry-run \
  --frozen-manifest ./runs/frozen_production_20260806/b2a95dfbfbe3/manifest.json \
  --frozen-npz ./runs/frozen_production_20260806/b2a95dfbfbe3/AIEF_1_4_b2a95dfbfbe3_branch_diagnostics.npz \
  --frozen-scalar ./runs/frozen_production_20260806/b2a95dfbfbe3/AIEF_1_4_b2a95dfbfbe3_scalar_summary.csv
```
Output:
```
Dry run: configuration validated successfully.
  Validated 5 rho values: (0.5, 0.75, 1.0, 1.5, 2.0)
  Validated 4 study branches: ('continue', 'reset_ema', 'reset_B', 'future_shuffle')
  Validated 40 seeds from master seed 20260714
Configuration hash: e13aef47c528
To execute, run without --dry-run
Expected run directory: runs/e13aef47c528
```

### 3. Baseline-Only Test ⚠️ (In Progress)

The baseline equivalence test is computationally intensive:
- 40 seeds × 7 branches = 280 simulations
- Each simulation runs for 80,000 time steps
- Each seed requires prefix simulation (48,000 steps) + future simulation (32,000 steps)

**Issue Encountered:**
The first attempt to run `--baseline-only` with 40 seeds timed out after 10 minutes. This is expected behavior for a full baseline test.

**Command used:**
```bash
python3 AIEF_1_4_Twindow_sensitivity.py --baseline-only \
  --n-seeds 40 --master-seed 20260714 \
  --frozen-manifest ./runs/frozen_production_20260806/b2a95dfbfbe3/manifest.json \
  --frozen-npz ./runs/frozen_production_20260806/b2a95dfbfbe3/AIEF_1_4_b2a95dfbfbe3_branch_diagnostics.npz \
  --frozen-scalar ./runs/frozen_production_20260806/b2a95dfbfbe3/AIEF_1_4_b2a95dfbfbe3_scalar_summary.csv \
  --overwrite
```

**Note:** Attempting with `--n-seeds 2` failed with "Seed count mismatch: generated=2, frozen=40" because the frozen manifest contains exactly 40 seeds and the baseline test requires matching seed counts.

## Critical Fixes Applied

### 1. Engine File Fix (aief_experiment_engine_v1.py)

**Problem:** Forward reference error - `EXTENDED_MATRIX_EQUIVALENCE_MAP` was referenced at line 1600 but defined at line 1734.

**Solution:** Moved the definition of `EXTENDED_MATRIX_EQUIVALENCE_MAP` to immediately after `EXTENDED_BRANCH_MATRIX_KEYS` (around line 1588) and removed the duplicate definition at line 1734.

**Lines changed:**
- Added `EXTENDED_MATRIX_EQUIVALENCE_MAP` definition after line 1588
- Removed duplicate definition at lines 1748-1759

This fix ensures that the matrix schema-map integrity validation (P0 #7) can access the map when it's needed.

### 2. Analysis Script Fix (AIEF_1_4_Twindow_sensitivity_analysis_v3.py)

**Problem:** Forward reference error - `NON_CONTINUE_BRANCHES` was referenced at lines 72 and 78 but defined at line 95.

**Solution:** Moved the definition of `NON_CONTINUE_BRANCHES` to before line 72 (right after the PRIMARY_OUTCOMES definition) and removed the duplicate definition at line 95.

**Lines changed:**
- Added `NON_CONTINUE_BRANCHES` definition before line 72
- Removed duplicate definition at line 95

This fix ensures that the expected count calculations can access the constant when it's needed.

## Next Steps

### Immediate (Recommended)
1. **Run baseline test with sufficient time:** The baseline test requires significant computation time. Run with a longer timeout:
   ```bash
   timeout 1800 python3 AIEF_1_4_Twindow_sensitivity.py --baseline-only \
     --n-seeds 40 --master-seed 20260714 \
     --frozen-manifest ./runs/frozen_production_20260806/b2a95dfbfbe3/manifest.json \
     --frozen-npz ./runs/frozen_production_20260806/b2a95dfbfbe3/AIEF_1_4_b2a95dfbfbe3_branch_diagnostics.npz \
     --frozen-scalar ./runs/frozen_production_20260806/b2a95dfbfbe3/AIEF_1_4_b2a95dfbfbe3_scalar_summary.csv \
     --overwrite
   ```
   Expected runtime: 30-60 minutes depending on hardware.

### After Baseline Passes
2. **Inspect the baseline certificate:** Check `runs/<hash>/baseline_certificate.json`
3. **Launch the five-level grid:** Run without `--baseline-only` to execute the full study
4. **Run analysis:** Use `AIEF_1_4_Twindow_sensitivity_analysis_v3.py` with the generated outputs

## Files Modified

- `/home/user/aief_experiment_engine_v1.py` - Fixed forward reference issue with `EXTENDED_MATRIX_EQUIVALENCE_MAP`

## Validation Results

✅ All syntax checks pass (all three files)
✅ All modules import successfully
✅ Configuration validation passes (dry-run)
✅ Engine loads without errors
✅ Driver loads without errors
✅ Analysis script loads without errors
⚠️ Baseline equivalence test: Not yet completed (requires extended runtime)

## Known Issues

None identified. The forward reference issue was the only blocking problem preventing the code from running.

## Recommendations

1. **For quick validation:** Test with a smaller subset if possible, but note that the frozen manifest requires exactly 40 seeds.

2. **For production runs:** Ensure sufficient compute resources are available. The baseline test is CPU-intensive.

3. **Monitor progress:** The baseline test prints progress for each seed. Monitor the output to ensure it's making progress.

---

*Status: 2026-08-09 06:20 UTC*
*Last updated: After fixing forward reference issue in engine*
