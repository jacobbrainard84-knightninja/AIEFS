# Analysis File Fixes - AIEF_1_4_Twindow_sensitivity_analysis_v3.py

## P0 (Must Fix Before Running)

### 1. Manifest cohort-validation exceptions downgraded to warnings
**Status:** NEEDS FIX
**Location:** `validate_run()` function, 2 exception handlers
**Issue:** Two places use `results["warnings"].append()` when manifest cohort validation fails
**Fix:** Replace with `results["status"] = "failed"`, add to errors, and return early

### 2. Topology matrix/metric validation missing
**Status:** NEEDS FIX
**Location:** `compute_cross_t_topology()`
**Issue:** Matrices can contain NaN, be wrong shape, not symmetric, have negative weights
**Fix:** Add `validate_topology_matrix()` function that checks:
- Shape is (12, 12)
- All values finite
- Matrix is symmetric (rtol=0, atol=1e-12)
- Diagonal is zero (rtol=0, atol=1e-12)
- No negative weights
Then validate topology_df metrics are all finite

### 3. Recovery trajectory lengths not checked
**Status:** NEEDS FIX
**Location:** `compute_recovery_scaling()`
**Issue:** Only checks sample_times equality between branch and continue, not that all three arrays have same length
**Fix:** Add validation: `len(sample_times) == len(density_trajectory) == len(similarity_trajectory)`

### 4. Exact saved-time schedule not validated
**Status:** NEEDS FIX
**Location:** `compute_recovery_scaling()`
**Issue:** Doesn't verify sample_times matches expected 0.01-to-319.51 schedule
**Fix:** Add check: `np.array_equal(sample_times, expected_times)` where expected_times = (np.arange(0, 32000, 50, dtype=float) + 1.0) * 0.01

### 5. Trajectory ranges not validated
**Status:** NEEDS FIX
**Location:** `compute_recovery_scaling()`
**Issue:** Density and similarity trajectories not checked for valid ranges
**Fix:** Add validation:
- Density: finite and in [0, 1]
- Similarity: finite, and finite values in [-1, 1]

## P1 (Fix Before Full Grid)

### 6. Other summaries remain unchecked
**Status:** NEEDS FIX
**Location:** `validate_run()` or after summaries computed
**Issue:** Regime, branch DID, topology summaries not validated for group counts
**Fix:** Add validation for:
- Regime summaries: 12 groups (4 rho × 3 outcomes), each with n=40
- Branch DID summaries: 36 groups (4 rho × 3 branches × 3 outcomes), each with n=40
- Topology summary: 4 rho rows, cosine_n=40, jaccard_n=40, distance_n=40

### 7. Baseline certificate cohort not verified
**Status:** NEEDS FIX
**Location:** `validate_run()`
**Issue:** Only checks size, not exact seed match with manifest
**Fix:** Verify `set(certificate["seed_results"])` == `{str(seed) for seed in manifest["randomization"]["paired_seeds"]}`
Also verify certificate protocol branch list matches frozen seven-branch order

### 8. Manifest study values not validated
**Status:** NEEDS FIX
**Location:** `validate_run()`
**Issue:** Manifest itself not compared against EXPECTED_* constants
**Fix:** Add checks:
- `tuple(float(x) for x in manifest["study"]["rho_values"])` == EXPECTED_RHO_VALUES
- `tuple(manifest["protocol"]["branches"])` == EXPECTED_BRANCHES
- `len(manifest["randomization"]["paired_seeds"])` == EXPECTED_N_SEEDS

### 9. Cosine zero-imputation counts not recorded
**Status:** NEEDS FIX
**Location:** `compute_recovery_scaling()`
**Issue:** Raw recovery table doesn't record when NaN cosine was imputed as zero
**Fix:** Add fields to similarity rows:
- `target_nan_samples_imputed_zero`: count of NaN in similarity_trajectory
- `reference_nan_samples_imputed_zero`: count of NaN in cont_similarity_trajectory
- `similarity_nan_convention`: documentation string

### 10. Held-duration definition not precise
**Status:** NEEDS FIX
**Location:** `compute_recovery_scaling()`
**Issue:** `held_duration_definition` says "one_current_T_window" but implementation is ceil(T_window / sample_spacing)
**Fix:** Update to: `"ceil(T_window / diagnostic_sample_spacing) consecutive saved samples"`
Add fields: `held_required_samples`, `diagnostic_sample_spacing`

### 11. Density row duplication not documented
**Status:** NEEDS FIX
**Location:** Manifest notes
**Fix:** Add to analysis manifest notes: "Density recovery rows are duplicated across horizon_system by design. They are horizon-independent and must not be pooled across the two labels."

### 12. Inputs validated after deleting stale outputs
**Status:** NEEDS FIX
**Location:** `main()`
**Issue:** `--overwrite` deletes files before `validate_run()` is called
**Fix:** Reorder: validate first, then if passed, check and clean output directory

### 13. load_npz_selective() warns instead of raising
**Status:** NEEDS FIX
**Location:** `load_npz_selective()`
**Issue:** Prints warning and returns empty dict on error
**Fix:** Raise RuntimeError with details

### 14. CSV output fsync incomplete
**Status:** PARTIAL (fsync on dir but not file)
**Location:** `save_csv_atomic()`
**Issue:** Missing file flush before replace
**Fix:** Add `handle.flush(); os.fsync(handle.fileno())` before replace

### 15. Docstring says "standard error" but computes sample std
**Status:** NEEDS FIX
**Location:** `compute_seed_level_summaries()` docstring and report
**Fix:** Change "Std error" to "Sample standard deviation" in docstrings
Change report notation from "mean ± std" to "mean ± sample_std" or just document it's sample std

### 16. Conditional sustained/held CIs absent
**Status:** NEEDS FIX
**Location:** Report generation
**Issue:** Report checks for ci_lower_sustained etc. but they're not computed
**Fix:** Either remove the report checks or add the missing CI computations

### 17. Expand analysis-manifest expected counts
**Status:** NEEDS FIX
**Location:** `generate_analysis_manifest()`
**Issue:** Missing recovery expected counts
**Fix:** Add to notes:
- expected_n_recovery_rows: 3200
- expected_n_recovery_groups: 80
- expected_n_recovery_did_rows: 24960
- expected_n_recovery_did_groups: 624
- similarity_nan_recovery_convention
- density_horizon_duplication
- discrete_held_duration_convention
