#!/usr/bin/env python3

"""
AIEF-1.4 Matched-Phase Memory Correction

Fixes the confound in the original memory-ablation experiment:
  B_carrier_only and full_reset used DIFFERENT randomized phase resets.

This driver:
  1. For each seed, generates ONE shared randomized reset (theta, H, C=0)
  2. Clones into two branches differing ONLY in initial B:
       B_carrier:  B = mature B_split,  C=0,  theta/H = shared reset
       full_reset: B = 0,               C=0,  theta/H = shared reset
  3. Runs both branches forward under production dynamics
  4. Compares paired seed-level recovery metrics

Estimand: effect of preserving mature B, conditional on identical
          phase/history/EMA reset and unchanged future dynamics.

Evidence class: controlled intervention experiment.
"""

from __future__ import annotations

import argparse, copy, hashlib, json, math, os, re, sys, tempfile, time
from pathlib import Path

import numpy as np
import pandas as pd

DEFAULT_RUN_HASH = "5a9f093a2fe0"
DEFAULT_NPZ = f"runs/{DEFAULT_RUN_HASH}/AIEF_1_4_{DEFAULT_RUN_HASH}_branch_diagnostics.npz"
DEFAULT_MANIFEST = f"runs/{DEFAULT_RUN_HASH}/manifest.json"
DEFAULT_OUTPUT_DIR = "aief_1_4_matched_phase_memory"
DEFAULT_DT = 0.01
DEFAULT_SCALE_EPSILON = 1e-12
DEFAULT_MAX_SEEDS = 40
DEFAULT_RNG_SEED = 20260803

# ── utilities ──────────────────────────────────────────────────────
def file_sha256(path):
    d = hashlib.sha256()
    with open(path, "rb") as h:
        while b := h.read(1024*1024): d.update(b)
    return d.hexdigest()

def compute_module_sha256(m):
    if m is None or not hasattr(m, "__file__") or m.__file__ is None:
        return "not_available"
    return file_sha256(Path(m.__file__).resolve())

def load_production_modules():
    import AIEF_1_4_stationarity_perturbation_analysis_updated as base
    import AIEF_1_4_component_controller_audit as ca
    import AIEF_1_4_augmented_tangent_cocycle_analysis as aug
    return base, ca, aug

# ── atomic writes (FIXED: fsync inside with block) ─────────────────
def safe_atomic_write_text(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tp = tempfile.mkstemp(dir=path.parent, prefix=f"{path.name}_", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tp, path)
    except Exception:
        if os.path.exists(tp): os.remove(tp)
        raise

def safe_atomic_write_csv(path, df):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tp = tempfile.mkstemp(dir=path.parent, prefix=f"{path.name}_", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            df.to_csv(f, index=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tp, path)
    except Exception:
        if os.path.exists(tp): os.remove(tp)
        raise

def safe_atomic_write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tp = tempfile.mkstemp(dir=path.parent, prefix=f"{path.name}_", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, sort_keys=True)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(tp, path)
    except Exception:
        if os.path.exists(tp): os.remove(tp)
        raise

# ── Seed RNG derivation ────────────────────────────────────────────
def make_seed_rng(master_seed, seed_id):
    digest = hashlib.sha256(f"{master_seed}|{seed_id}".encode()).digest()
    child_seed = int.from_bytes(digest[:8], "little", signed=False)
    return np.random.default_rng(child_seed)

def generate_shared_reset(state, rng):
    N = len(state.B)
    theta_reset = rng.uniform(0, 2*np.pi, size=N).astype(float)
    depth = state.history_depth if hasattr(state, 'history_depth') else len(state.history)
    history_reset = []
    for _ in range(depth):
        history_reset.append(rng.uniform(0, 2*np.pi, size=N).astype(float))
    coherence_reset = np.zeros((N, N), dtype=complex)
    return {"theta": theta_reset, "history": history_reset, "coherence_acc": coherence_reset}

# ── Forward simulation ─────────────────────────────────────────────
def run_branch(state, model, caps, A, edges_mat, eps_sc, future_steps, aug):
    snapshots = {}
    sample_steps = {0, future_steps} | set(range(50, future_steps, 50))
    for step in range(future_steps):
        inter = aug.base_intermediates(state, model, caps, A, edges_mat, eps_sc)
        if step in sample_steps:
            snapshots[step] = {
                "B": state.B.copy(),
                "D_B": _compute_DB(state.B),
                "effective_edges": _count_effective(state.B, model),
                "total_edge_weight": float(np.sum(state.B)) * 0.5,
            }
        aug.advance_base_state(state, inter)
    snapshots[future_steps] = {
        "B": state.B.copy(),
        "D_B": _compute_DB(state.B),
        "effective_edges": _count_effective(state.B, model),
        "total_edge_weight": float(np.sum(state.B)) * 0.5,
    }
    return state, snapshots

def _compute_DB(B):
    N = len(B)
    s = 0.0
    for i in range(N):
        for j in range(i+1, N):
            s += B[i,j]
    return s

def _count_effective(B, model):
    try: B_c = float(model["B_c"])
    except: B_c = 0.12
    return int(np.sum(B > B_c)) // 2

# ── Recovery metrics ───────────────────────────────────────────────
def compute_recovery_metrics(snap_carrier, snap_reset, B_target, model):
    fs = max(snap_carrier.keys())
    B_carrier_final = snap_carrier[fs]["B"]
    B_reset_final = snap_reset[fs]["B"]

    def frob_sim(B_a, B_b):
        na = np.linalg.norm(B_a, 'fro')
        nb = np.linalg.norm(B_b, 'fro')
        if na < 1e-30 and nb < 1e-30: return 1.0
        return 1.0 - np.linalg.norm(B_a - B_b, 'fro') / (na + nb + 1e-30)

    sim_carrier = frob_sim(B_carrier_final, B_target)
    sim_reset   = frob_sim(B_reset_final, B_target)
    DB_carrier  = snap_carrier[fs]["D_B"]
    DB_reset    = snap_reset[fs]["D_B"]
    DB_target   = _compute_DB(B_target)

    return {
        "similarity_carrier": float(sim_carrier),
        "similarity_reset": float(sim_reset),
        "similarity_delta": float(sim_carrier - sim_reset),
        "DB_carrier": float(DB_carrier),
        "DB_reset": float(DB_reset),
        "DB_target": float(DB_target),
        "DB_ratio_carrier": float(DB_carrier / max(DB_target, 1e-30)),
        "DB_ratio_reset": float(DB_reset / max(DB_target, 1e-30)),
        "ee_carrier": int(snap_carrier[fs]["effective_edges"]),
        "ee_reset": int(snap_reset[fs]["effective_edges"]),
        "ee_target": _count_effective(B_target, model),
        "total_weight_carrier": float(snap_carrier[fs]["total_edge_weight"]),
        "total_weight_reset": float(snap_reset[fs]["total_edge_weight"]),
    }

# ── CLI ────────────────────────────────────────────────────────────
def parse_args():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--npz", default=DEFAULT_NPZ)
    p.add_argument("--manifest", default=DEFAULT_MANIFEST)
    p.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--dt", type=float, default=DEFAULT_DT)
    p.add_argument("--scale-epsilon", type=float, default=DEFAULT_SCALE_EPSILON)
    p.add_argument("--max-seeds", type=int, default=DEFAULT_MAX_SEEDS)
    p.add_argument("--rng-seed", type=int, default=DEFAULT_RNG_SEED)
    return p.parse_args()

# ── Seed discovery ─────────────────────────────────────────────────
def discover_seeds(npz_path):
    with np.load(npz_path, allow_pickle=False) as data:
        all_keys = list(data.keys())
    pattern = re.compile(r"^continue_seed_(\d+)_B_final$")
    return sorted({m.group(1) for k in all_keys if (m := pattern.match(k))}, key=int)

# ── Model constant validation (FIXED: compares frozen manifest to production) ──
def validate_model_constants(frozen_model, prod_module):
    mismatches = []
    checks = {
        "N": (int(frozen_model["N"]), int(prod_module.N)),
        "dt": (float(frozen_model["dt"]), float(prod_module.DT)),
        "T_window": (float(frozen_model["T_window"]), float(prod_module.T_WINDOW)),
    }
    for name, (frozen_val, prod_val) in checks.items():
        if frozen_val != prod_val:
            mismatches.append(f"{name}: frozen={frozen_val}, prod={prod_val}")
    # omega array
    frozen_omega = np.asarray(frozen_model["omega"], dtype=float)
    prod_omega = np.asarray(prod_module.OMEGA, dtype=float)
    if not np.array_equal(frozen_omega, prod_omega):
        mismatches.append("omega arrays differ")
    if mismatches:
        raise RuntimeError("Model constant mismatch: " + "; ".join(mismatches))

# ── main ───────────────────────────────────────────────────────────
def main():
    args = parse_args()
    for p in (args.npz, args.manifest):
        if not os.path.isfile(p): raise FileNotFoundError(f"Missing: {p}")

    base, ca, aug = load_production_modules()
    with open(args.manifest) as h: manifest = json.load(h)
    model = manifest["model"]
    dt = float(model["dt"])
    cap = (float(model["a"])-float(model["delta"]))/float(model["q"])
    caps = np.full(int(model["N"]), cap)
    N = int(model["N"])
    A, edges_mat = base.incidence_matrix(N)
    fs = int(manifest["protocol"]["future_steps"])
    eps_sc = args.scale_epsilon

    # FIXED: validate model constants against actual production module
    validate_model_constants(model, base)

    seed_keys = discover_seeds(args.npz)
    n_available = len(seed_keys)
    n_seeds = min(n_available, args.max_seeds)
    print(f"Found {n_available} seeds.  Running {n_seeds} pairs.", flush=True)

    results = []
    seed_status = {}
    immutability_by_seed = {}

    for si, seed_id in enumerate(seed_keys[:n_seeds]):
        t0 = time.time()
        try:
            with np.load(args.npz, allow_pickle=False) as data:
                split_state = base.load_split_state(data, seed_id)
            B_target = split_state.B.copy()
            split_snapshot = {
                "theta": split_state.theta.copy(),
                "B": split_state.B.copy(),
                "coherence": split_state.coherence_acc.copy(),
                "history": [h.copy() for h in split_state.history],
            }

            # Shared reset
            rng = make_seed_rng(args.rng_seed, seed_id)
            reset = generate_shared_reset(split_state, rng)

            # B_carrier branch
            state_carrier = copy.deepcopy(split_state)
            state_carrier.theta[:] = reset["theta"]
            state_carrier.coherence_acc[:] = reset["coherence_acc"]
            state_carrier.history.clear()
            for entry in reset["history"]:
                state_carrier.history.append(entry.copy())

            # full_reset branch
            state_reset = copy.deepcopy(split_state)
            state_reset.theta[:] = reset["theta"]
            state_reset.coherence_acc[:] = reset["coherence_acc"]
            state_reset.B[:] = 0.0
            np.fill_diagonal(state_reset.B, 0.0)
            state_reset.history.clear()
            for entry in reset["history"]:
                state_reset.history.append(entry.copy())

            # Run branches
            state_carrier, snap_c = run_branch(state_carrier, model, caps, A,
                                                edges_mat, eps_sc, fs, aug)
            state_reset, snap_r   = run_branch(state_reset, model, caps, A,
                                                edges_mat, eps_sc, fs, aug)

            # FIXED: check split state immutability and store per-seed
            immut_ok = (
                np.array_equal(split_state.theta, split_snapshot["theta"])
                and np.array_equal(split_state.B, split_snapshot["B"])
                and np.array_equal(split_state.coherence_acc, split_snapshot["coherence"])
                and len(split_state.history) == len(split_snapshot["history"])
                and all(np.array_equal(h, sh)
                        for h, sh in zip(split_state.history, split_snapshot["history"]))
            )
            immutability_by_seed[seed_id] = immut_ok

            metrics = compute_recovery_metrics(snap_c, snap_r, B_target, model)
            metrics["seed"] = seed_id
            metrics["elapsed_s"] = time.time() - t0
            metrics["immutable"] = immut_ok
            results.append(metrics)
            seed_status[seed_id] = "success"

            print(f"  [{si+1:>2}/{n_seeds}] {seed_id}: "
                  f"sim_c={metrics['similarity_carrier']:.4f} "
                  f"sim_r={metrics['similarity_reset']:.4f} "
                  f"Δ={metrics['similarity_delta']:+.4f} "
                  f"immut={'OK' if immut_ok else 'FAIL'} "
                  f"({metrics['elapsed_s']:.0f}s)", flush=True)

        except Exception as e:
            seed_status[seed_id] = f"failed: {type(e).__name__}: {e}"
            print(f"  [{si+1:>2}/{n_seeds}] {seed_id}: FAILED — "
                  f"{type(e).__name__}: {e}", flush=True)

    # ── Output ──
    od = Path(args.output_dir); od.mkdir(parents=True, exist_ok=True)
    results_df = pd.DataFrame(results)

    # Seed status CSV
    status_rows = [{"seed": s, "status": st} for s, st in seed_status.items()]
    if status_rows:
        safe_atomic_write_csv(od/"matched_phase_seed_status.csv", pd.DataFrame(status_rows))

    if len(results_df) > 0:
        safe_atomic_write_csv(od/"matched_phase_recovery.csv", results_df)

    # ── Report ──
    n = len(results_df)
    n_immut = int(results_df["immutable"].sum()) if n > 0 and "immutable" in results_df.columns else 0
    if n > 0:
        delta_col = results_df["similarity_delta"]
        n_pos = int((delta_col > 0.001).sum())
        n_neg = int((delta_col < -0.001).sum())
        n_tie = n - n_pos - n_neg
        mean_delta = float(delta_col.mean())
        median_delta = float(delta_col.median())

    lines = [
        "="*70,
        "AIEF-1.4 Matched-Phase Memory Correction",
        "="*70,
        f"Seeds run: {n}",
        f"Split-state immutability: {n_immut}/{n}",
        "",
        "Branches share identical randomized phase/history/EMA reset.",
        "They differ ONLY in initial B:",
        "  B_carrier:  B = mature split-state weights",
        "  full_reset: B = 0",
        "",
        "─"*70,
        "Similarity to Mature Target (final step):",
        "─"*70,
    ]
    if n > 0:
        lines.extend([
            f"  B_carrier mean: {float(results_df['similarity_carrier'].mean()):.4f}",
            f"  full_reset mean: {float(results_df['similarity_reset'].mean()):.4f}",
            f"  Δ (carrier − reset) mean:   {mean_delta:+.4f}",
            f"  Δ median:                    {median_delta:+.4f}",
            f"  Δ > 0: {n_pos}   Δ ≈ 0: {n_tie}   Δ < 0: {n_neg}",
            "",
        ])
        if n_pos > n * 0.75:
            lines.append("  → Mature B provides a robust conditional recovery advantage.")
        elif n_pos > n * 0.5:
            lines.append("  → Mature B provides a modest conditional advantage.")
        elif n_tie > n * 0.75:
            lines.append("  → Preserving mature B has negligible effect under this")
            lines.append("    matched-reset protocol.")
        else:
            lines.append("  → Mixed results.  B effect varies across seeds.")

        lines.extend([
            "",
            "─"*70,
            "Capacity Density (D_B) Relative to Target:",
            "─"*70,
            f"  B_carrier mean ratio: {float(results_df['DB_ratio_carrier'].mean()):.3f}",
            f"  full_reset mean ratio: {float(results_df['DB_ratio_reset'].mean()):.3f}",
            "",
            "─"*70,
            "Effective Edges Relative to Target:",
            "─"*70,
            f"  target:    {int(results_df['ee_target'].iloc[0]) if n>0 else 'N/A'}",
            f"  carrier:   {int(results_df['ee_carrier'].mean()) if n>0 else 'N/A'} (mean)",
            f"  reset:     {int(results_df['ee_reset'].mean()) if n>0 else 'N/A'} (mean)",
            "",
        ])

    lines.extend([
        "─"*70,
        "Interpretation:",
        "─"*70,
        "If B_carrier outperforms full_reset:",
        "  Mature B provides a conditional recovery advantage when phase",
        "  and EMA are matched-reset.  This does NOT imply B is the unique",
        "  memory carrier — only that it contributes under these conditions.",
        "",
        "If branches are comparable:",
        "  Preserving mature B alone is not sufficient to materially alter",
        "  recovery under this protocol.  Other state variables (phase",
        "  alignment, EMA coherence) dominate the reconstruction dynamics.",
        "",
        "Evidence class: controlled intervention experiment.",
        "Paired seed-level design.  Components within seeds are not independent.",
    ])

    report = "\n".join(lines)
    safe_atomic_write_text(od/"matched_phase_report.txt", report)

    # FIXED: manifest with correctly-stored immutability
    mf = {
        "analysis": "AIEF-1.4 matched-phase memory correction",
        "evidence_class": "controlled intervention experiment",
        "design": "paired seed-level, shared randomized reset, B-only difference",
        "n_seeds": n,
        "n_immutable": n_immut,
        "rng_seed": args.rng_seed,
        "parameters": {"dt": dt, "scale_epsilon": eps_sc,
                        "future_steps": fs, "T_window": model["T_window"]},
        "source_hashes": {
            Path(__file__).name: file_sha256(Path(__file__).resolve()),
            "base": compute_module_sha256(base),
        },
        "inputs": {
            "npz": {"path": str(Path(args.npz).resolve()),
                     "sha256": file_sha256(args.npz)},
            "manifest": {"path": str(Path(args.manifest).resolve()),
                         "sha256": file_sha256(args.manifest)},
        },
        "split_state_immutability": {
            "all_passed": bool(n_immut == n and n > 0),
            "by_seed": immutability_by_seed,
        },
        "seed_status": seed_status,
        "outputs": ["matched_phase_recovery.csv", "matched_phase_seed_status.csv",
                     "matched_phase_report.txt", "analysis_manifest.json"],
    }
    if n > 0:
        mf["summary"] = {
            "mean_similarity_carrier": float(results_df["similarity_carrier"].mean()),
            "mean_similarity_reset": float(results_df["similarity_reset"].mean()),
            "mean_delta": mean_delta,
            "median_delta": median_delta,
            "n_B_carrier_better": n_pos,
            "n_tie": n_tie,
            "n_full_reset_better": n_neg,
        }

    safe_atomic_write_json(od/"analysis_manifest.json", mf)
    print(report, flush=True)
    print(f"\nDone. → {od.resolve()}", flush=True)

if __name__ == "__main__":
    main()
