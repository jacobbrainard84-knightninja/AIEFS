README

Component Title: 
MFMMS
Component Description: 
MFMMS measurements of samples from 15 meteorites
Scope and Content: 
Contains .txt, .dta, .dsc and .xgf files. Raw data files (.txt) contain the numerical data, presented as tab-separated data. Descriptor files (.dsc) provide details about the settings used to take the associated measurement. The other two file types (.xgf and .dta) are machine output files that are not text readable (but do not contain any relevant information).
Most filenames are presented in the format [Sample Name]_[Temperature or temperature range in K]_[Magnetic field or field range in Oe]_[Measurement number]_[“Up” or “Down” for field sweeps taken in quick succession with the same settings].txt. This is meant to be quick reference information, as the .dsc file will contain this and more information.
Sample 1 from GRA 95205 and sample 3 from Mundrabilla were subdivided and re-measured. In these cases, the measurements of the subsamples is presented within a folder labeled “divide”.
Note that the naming conventions presented here are different from the ones used in the paper associated with this data. MUND-1 from the paper refers to Sample 2 from Mundrabilla, MUND-2 from the paper refers to sample 3 from Mundrabilla, and GRA-1 from the paper refers to sample 1 from GRA 95205. The parent sample in fig. 3 is subsample c from sample 1 (and the subsamples listed in that figure are themselves the subsamples of sample 1, subsample c).